//
//  GroupAdViewController.h
//  OpenX
//
//  Copyright (c) 2013 OpenX Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface GroupAdViewController : UIViewController <UITextFieldDelegate, OXMConsoleDelegate, OXMAdBannerControllerDelegate>

@property (nonatomic, strong) IBOutlet UITextField *my_test_field;
@property (nonatomic, strong) NSString *ad_domain;
@property (nonatomic, strong) NSString *ad_unit_portrait;
@property (nonatomic, strong) NSString *ad_unit_landscape;
@property (nonatomic, strong) IBOutlet UILabel *adUnitLabel;
@property (nonatomic, strong) IBOutlet UILabel *adUrlLabel;

@property (nonatomic, strong) AppDelegate *ad;
@property (nonatomic, strong) IBOutlet OXMAdBanner *adBanner;
@property (nonatomic, strong) IBOutlet OXMAdRequest *adRequest;
@property (nonatomic, strong) OXMAdBannerController* adController;
@property (nonatomic, strong) IBOutlet UILabel *notesView;
@property (nonatomic, strong) IBOutlet UILabel *codeSample;
@property (nonatomic, strong) UITextView *introView;
@property (nonatomic, strong) UITextView *consoleView;
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, strong) IBOutlet UITextField *portrait_field;
@property (nonatomic, strong) IBOutlet UITextField *landscape_field;
@property (nonatomic, strong) IBOutlet UITextField *url_field;
@property (nonatomic, strong) UITableView *theTableView;
@property (nonatomic, assign) NSInteger kMaxNumOfPanels;

@property (nonatomic, strong) IBOutlet UIView *videoView;
@property (nonatomic, strong) IBOutlet UIView *adDetailsView;
@property (nonatomic, strong) IBOutlet UIView *consoleSlideView;
@property (nonatomic, strong) IBOutlet UIView *codeView;
@property (nonatomic, strong) IBOutlet UISegmentedControl *segControl;

@end
