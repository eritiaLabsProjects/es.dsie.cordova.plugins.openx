//
//  OXCustomSegue.m
//  OpenX
//
//  Copyright 2013 OpenX Technologies, Inc.
//

#import "OXCustomSegue.h"

@implementation OXCustomSegue

-(void)perform {
    UIViewController *src = (UIViewController *) self.sourceViewController;
    UIViewController *dst = (UIViewController *) self.destinationViewController;
    
    [UIView transitionWithView:src.view
                      duration:0.2
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [src.navigationController pushViewController:dst animated:NO];
                    }
                    completion:NULL];
}
@end
