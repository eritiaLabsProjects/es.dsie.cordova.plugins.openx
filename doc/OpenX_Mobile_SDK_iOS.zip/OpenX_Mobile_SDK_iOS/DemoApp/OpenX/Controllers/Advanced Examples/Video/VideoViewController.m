//
//  VideoViewController.m
//  OpenXDemoApp
//
//  Created by Lawrence Leach on 3/4/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import "AppDelegate.h"
#import "VideoViewController.h"
#import "VideoInterstitialViewController.h"
#import "VideoPreRollViewController.h"
#import "NativeInFeedVideoViewController.h"

@interface VideoViewController ()
@property (nonatomic, strong) AppDelegate *ad;
@property (nonatomic, weak) VideoInterstitialViewController *videoIntVC;
@property (nonatomic, weak) VideoPreRollViewController *videoPreRollVC;
@property (nonatomic, weak) NativeInFeedVideoViewController *videoInfeedVC;
@end

@implementation VideoViewController


- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:NO];
    self.title = @"Video Examples";
    
    self.ad = [AppDelegate sharedAppDelegate];
    
}

-(void)dealloc
{
    _videoInfeedVC = nil;
    _videoIntVC = nil;
    _videoPreRollVC = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 7;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"VideoCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    if (cell == nil)
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];

    [self configureCell:cell forRowAtIndexPath:indexPath];
    
    return cell;
}

-(void)configureCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger row = indexPath.row;
    [cell.textLabel setFont:[UIFont fontWithName:@"OpenSans" size:14.0]];
    [cell.detailTextLabel setFont:[UIFont fontWithName:@"OpenSans-Light" size:12.0]];
    
    switch (row) {
        case 0:
            cell.tag = 0;
            cell.textLabel.text = @"Video Interstitial Example";
            cell.detailTextLabel.text = @"Shows an example of an interstitial video ad";
            break;
            
        case 1:
            cell.tag = 1;
            cell.textLabel.text = @"Video In-Feed Example";
            cell.detailTextLabel.text = @"Shows an example of a video ad playing in a feed of content";
            break;
            
        case 2:
            cell.tag = 2;
            cell.textLabel.text = @"Video Pre-Roll Example #1";
            cell.detailTextLabel.text = @"Demonstrates using the OpenX Video Player for BOTH ads and content";
            break;
            
        case 3:
            cell.tag = 3;
            cell.textLabel.text = @"Video Pre-Roll Example #2";
            cell.detailTextLabel.text = @"Demonstrates swapping between the OpenX Video Player for ads and a custom AVPlayer object for content";
            break;
            
        case 4:
            cell.tag = 4;
            cell.textLabel.text = @"Video Pre-Roll Example #3";
            cell.detailTextLabel.text = @"Demonstrates swapping between the OpenX Video Player for ads and a custom MPMoviePlayerController object for content";
            break;
            
        case 5:
            cell.tag = 5;
            cell.textLabel.text = @"Video Pre-Roll Example #4";
            cell.detailTextLabel.text = @"Demonstrates using a custom AVPlayer object to handle the playback of BOTH ads and content";
            break;
            
        case 6:
            cell.tag = 6;
            cell.textLabel.text = @"Video Pre-Roll Example #5";
            cell.detailTextLabel.text = @"Demonstrates using a custom MPMoviePlayerController object to handle the playback of BOTH ads and content";
            break;

        default:
            break;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSUInteger row = indexPath.row;
    
    if (!self.ad.haveInternetAccess)
        [self.ad alertWithMessage:@"Internet access is not currently available.\nPlease try again when connectivity has been restored." withTitle:@"OpenX"];
    
    else {
        switch (row) {
            case 0:
                [self performSegueWithIdentifier:@"videoInterstitialSegue" sender:nil];
                break;
            case 1:
                [self performSegueWithIdentifier:@"videoInfeedSegue" sender:nil];
                break;
            case 2:
                [self performSegueWithIdentifier:@"videoPreRollSegue" sender:nil];
                break;
            case 3:
                [self performSegueWithIdentifier:@"avSwapSegue" sender:nil];
                break;
            case 4:
                [self performSegueWithIdentifier:@"videoSwapSegue" sender:nil];
                break;
            case 5:
                [self performSegueWithIdentifier:@"videoPreRollSegue" sender:nil];
                break;
            case 6:
                [self performSegueWithIdentifier:@"videoPreRollSegue" sender:nil];
                break;
            default:
                break;
        }
    }
    [tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
}


#pragma mark - STORYBOARD SEGUES

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
    NSInteger row = indexPath.row;
    NSString* adType;
    
    if ([[segue identifier] isEqualToString:@"videoInterstitialSegue"]){
       // _videoIntVC = [segue destinationViewController];
    }
    else if ([[segue identifier] isEqualToString:@"videoInfeedSegue"]){
        //_videoInfeedVC = [segue destinationViewController];
	}
    else {
        
        if ([[segue identifier] isEqualToString:@"videoPreRollSegue"]) {
            
            if (row == 2)
                adType = @"preRollOpenX";
            else if (row == 5)
                adType = @"preRollCustomAVPlayer";
            else if (row == 6)
                adType = @"preRollCustomMPPlayer";
        
        } else if ([[segue identifier] isEqualToString:@"avSwapSegue"])
            adType = @"preRollSwappingAVPlayer";
        
        else if ([[segue identifier] isEqualToString:@"videoSwapSegue"])
            adType = @"preRollSwappingMPPlayer";
        

        VideoPreRollViewController* videoPreRollVC = [segue destinationViewController];
        videoPreRollVC.adType= adType;
    }
}
@end
