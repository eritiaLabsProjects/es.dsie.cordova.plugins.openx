//
//  TutorialViewController.m
//  OpenXDemoApp
//
//  Copyright (c) 2013 OpenX Technologies, Inc. All rights reserved.
//

#import "TutorialViewController.h"

#define kNumOfTutorialPages 5

@interface TutorialViewController ()
@property (nonatomic, assign) BOOL isLandscape;

@end

@implementation TutorialViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.ad = [AppDelegate sharedAppDelegate];
    
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    _isLandscape = (orientation == UIDeviceOrientationLandscapeLeft || orientation == UIDeviceOrientationLandscapeRight ? YES : NO);
    
    [self setupScrollView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    [self cleanScrollView];
    _isLandscape = (toInterfaceOrientation == UIDeviceOrientationLandscapeLeft || toInterfaceOrientation == UIDeviceOrientationLandscapeRight ? YES : NO);
    //[self setupScrollView];
    //[self.scrollView setNeedsDisplay];
}

- (void) didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    [self setupScrollView];
    [self.scrollView setNeedsDisplay];
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}


#pragma mark - SCROLLVIEW AND PAGE CONTROL

- (void) setViewBounds {
    CGFloat kScrollWindowWidth = _isLandscape ? 528 : 280;
    CGFloat kScrollWindowHeight = _isLandscape ? 280 : 528;
    CGFloat xpoint = _isLandscape ? 24.0f : 20.0f;
    CGFloat ypoint = _isLandscape ? 20.0f : 24.0f;
    self.scrollView.frame = CGRectMake(xpoint, ypoint,kScrollWindowWidth,kScrollWindowHeight);
    self.scrollView.contentSize = CGSizeMake((kScrollWindowWidth * kNumOfTutorialPages), kScrollWindowHeight);
    
    self.scrollView.canCancelContentTouches = YES;
    //self.scrollView.contentSize = CGSizeMake((kScrollWindowWidth * kNumOfTutorialPages), kScrollWindowHeight);
    self.scrollView.indicatorStyle = UIScrollViewIndicatorStyleBlack;
    self.scrollView.clipsToBounds = YES;
    self.scrollView.scrollEnabled = YES;
    self.scrollView.bounces = YES;
    self.scrollView.directionalLockEnabled = YES;
    self.scrollView.alwaysBounceHorizontal = NO;
    self.scrollView.alwaysBounceVertical = NO;
    self.scrollView.delegate = self;
    self.scrollView.pagingEnabled = YES;
    
}

-(void)setupScrollView
{
    [self setViewBounds];
    CGFloat kScrollWindowWidth = _isLandscape ? 528 : 280;
    CGFloat kScrollWindowHeight = _isLandscape ? 280 : 528;
    
    
    for (int i=1; i<=kNumOfTutorialPages; i++) {
        CGFloat xOrigin = i * kScrollWindowWidth;
        UIView *aView = [[UIView alloc] initWithFrame:CGRectMake(xOrigin, 0, kScrollWindowWidth, kScrollWindowHeight)];
        aView = [self setPanelWithView:aView atIndex:i];
        
        aView.tag = i;
        [self.scrollView addSubview:aView];
    }
    
    [self layoutPageViews];
    [self setupPageControl];
}

-(void)layoutPageViews
{
    CGFloat kScrollWindowWidth = _isLandscape ? 528 : 280;
    CGFloat kScrollWindowHeight = _isLandscape ? 280 : 528;
    
    UIView *view = nil;
    NSArray *subviews = [self.scrollView subviews];
    
    CGFloat curXLoc = 0;
    for (view in subviews) {
        if ([view isKindOfClass:[UIView class]] && view.tag > 0) {
            CGRect frame = view.frame;
            frame.origin = CGPointMake(curXLoc, 0);
            view.frame = frame;
            curXLoc += kScrollWindowWidth;
        }
    }
    self.scrollView.contentSize = CGSizeMake((kNumOfTutorialPages * kScrollWindowWidth), kScrollWindowHeight);
    //[self.scrollView]
    [self.scrollView scrollRectToVisible:CGRectMake(0, 0, kScrollWindowWidth, kScrollWindowHeight) animated:YES];
}

-(void)setupPageControl
{
    self.pageControl.hidesForSinglePage = NO;
    self.pageControl.userInteractionEnabled = YES;
    self.pageControl.numberOfPages = kNumOfTutorialPages;
    self.pageControl.currentPage = 0;
    self.pageControl.alpha = 0.6;
    self.pageControl.opaque = NO;
    if ([self.pageControl respondsToSelector:@selector(pageIndicatorTintColor)]) {
        self.pageControl.pageIndicatorTintColor = [UIColor darkGrayColor];
        self.pageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
        self.pageControl.backgroundColor = [UIColor clearColor];
    } else
        self.pageControl.backgroundColor = [UIColor clearColor];
    
    [self.pageControl addTarget:self action:@selector(pageTurn:) forControlEvents:UIControlEventValueChanged];
}

-(void)pageTurn:(UIPageControl *)aPageControl
{
    CGFloat pageWidth = _isLandscape ? 528 : 280;
    //CGFloat pageWidth = self.view.bounds.size.width;
    
    NSInteger whichPage = aPageControl.currentPage;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3f];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    self.scrollView.contentOffset = CGPointMake(pageWidth * whichPage, 0.0f);
    [UIView commitAnimations];
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)theScrollView {
    
    CGFloat pageWidth = _isLandscape ? 528 : 280;
    //CGFloat pageWidth = [self.scrollView bounds].size.width;
    
    //NSLog(@"Page Width: %f.1", pageWidth);
    int currentPage = (theScrollView.contentOffset.x / pageWidth) + 1;
    [self.pageControl setCurrentPage:currentPage-1];
}


-(UIView *)setPanelWithView:(UIView*)aView atIndex:(NSInteger)idx {
    
    
    NSInteger width = aView.bounds.size.width;
    //NSLog(@"Width: %d", width);
    
    NSString *panelTitleText;
    NSString *panelTextStr;
    CGRect titleFrm, textFrm, imgFrm;
    
    //UITextView *textView = [[UITextView alloc] initWithFrame:CGRectMake(0, 235, 280, 75)];
    //UILabel *panelTitle = [[UILabel alloc] initWithFrame:CGRectMake(5, 225, 280, 21)];
    UITextView *panelText = [[UITextView alloc] init];
    UILabel *panelTitle = [[UILabel alloc] init];
    
    UIImage *logoImage = [UIImage imageNamed:@"white_logo"];
    CGFloat imgWidth = logoImage.size.width;
    CGFloat imgHeight = logoImage.size.height;
    
    UIImage *grp2Image = [UIImage imageNamed:@"group2"];
    CGFloat grp2ImgWidth = grp2Image.size.width;
    CGFloat grp2ImgHeight = grp2Image.size.height;
    
    UIImage *grp3Image = [UIImage imageNamed:@"group3"];
    CGFloat grp3ImgWidth = grp3Image.size.width;
    CGFloat grp3ImgHeight = grp3Image.size.height;
    
    UIImage *grp4Image = [UIImage imageNamed:@"group4"];
    CGFloat grp4ImgWidth = grp4Image.size.width;
    CGFloat grp4ImgHeight = grp4Image.size.height;
    
    UIImage *grp5Image = [UIImage imageNamed:@"group5"];
    CGFloat grp5ImgWidth = grp5Image.size.width;
    CGFloat grp5ImgHeight = grp5Image.size.height;
    
    [panelText setFont:[UIFont fontWithName:@"OpenSans" size:14.0f]];
    [panelText setTextColor:[UIColor whiteColor]];
    [panelText setBackgroundColor:[UIColor clearColor]];
    
    [panelTitle setFont:[UIFont fontWithName:@"OpenSans-Bold" size:16.0f]];
    [panelTitle setTextColor:[UIColor whiteColor]];
    [panelTitle setBackgroundColor:[UIColor clearColor]];
    
    // SET IMAGE OBJECTS
    imgFrm = _isLandscape ? CGRectMake((width/2)-(imgWidth/2), 5.0f, imgWidth, imgHeight) : CGRectMake((width/2)-(imgWidth/2), 10.0f, imgWidth, imgHeight);
    UIImageView *groupImage = [[UIImageView alloc] initWithFrame:imgFrm];
    titleFrm = _isLandscape ? CGRectMake(2, (groupImage.bounds.origin.y + logoImage.size.height) + 5.0f, 200.0f, 75.0f) : CGRectMake(2, 280, 280, 21);
    textFrm = _isLandscape ? CGRectMake(0, titleFrm.origin.y + 40, 250, 90) : CGRectMake(0, titleFrm.origin.y + 40, 280, 75);
    
    
    
    if (idx == 1) {
        panelTitleText = @"Welcome!";
        panelTextStr = @"We're pleased to welcome you to OpenX Mobile, your number one solution for mobile advertising.";
        titleFrm = _isLandscape ? CGRectMake(2, (groupImage.bounds.origin.y + logoImage.size.height) + 5.0f, 200.0f, 75.0f) : CGRectMake(2, 225, 280, 21);
        textFrm = _isLandscape ? CGRectMake(0, titleFrm.origin.y + 40, 500, 75) : CGRectMake(0, titleFrm.origin.y + 40, 280, 75);
        imgFrm = _isLandscape ? CGRectMake((width/2)-(imgWidth/2), 5.0f, imgWidth, imgHeight) : CGRectMake((width/2)-(imgWidth/2), 44.0f, imgWidth, imgHeight);
        [groupImage setFrame:imgFrm];
        [groupImage setImage:logoImage];
        
    } else if (idx == 2) {
        panelTitleText = @"Mulitple Ad Formats";
        panelTextStr = @"Support for interstitial ads and standard IAB/MMA banner inventory.";
        imgFrm = _isLandscape ? CGRectMake((width - grp2ImgWidth), 5.0f, grp2ImgWidth-50, grp2ImgHeight-50) : CGRectMake((width/2)-(grp2ImgWidth/2), 10.0f, grp2ImgWidth, grp2ImgHeight);
        [groupImage setFrame:imgFrm];
        [groupImage setImage:grp2Image];
        
        
    } else if (idx == 3) {
        panelTitleText = @"Rich Media Ads";
        panelTextStr = @"Support for click-to-action, Mobile Rich-media Ad Interface (MRAID), Celtra & HTML5 ad units.";
        imgFrm = _isLandscape ? CGRectMake((width - grp3ImgWidth) + 25, 5.0f, grp3ImgWidth, grp3ImgHeight) : CGRectMake((width/2)-(grp3ImgWidth/2), 10.0f, grp3ImgWidth, grp3ImgHeight);
        [groupImage setFrame:imgFrm];
        [groupImage setImage:grp3Image];
        
    } else if (idx == 4) {
        panelTitleText = @"Customization";
        panelTextStr = @"Target multiple screen sizes and display orientations and include custom ad parameters using key-value pairs.";
        imgFrm = _isLandscape ? CGRectMake((width - grp4ImgWidth) + 30, -10, grp2ImgWidth, grp4ImgHeight) : CGRectMake((width/2)-(grp4ImgWidth/2), 10.0f, grp4ImgWidth, grp4ImgHeight);
        [groupImage setFrame:imgFrm];
        [groupImage setImage:grp4Image];
        
    } else if (idx == 5) {
        panelTitleText = @"Developer Tools";
        panelTextStr = @"Configure event listeners and view messages coming back from the ad server in real-time.";
        imgFrm = _isLandscape ? CGRectMake((width - grp5ImgWidth) + 15, -25, grp5ImgWidth, grp5ImgHeight) : CGRectMake((width/2)-(grp5ImgWidth/2), 10.0f, grp5ImgWidth, grp5ImgHeight);
        [groupImage setFrame:imgFrm];
        [groupImage setImage:grp5Image];
        
    }
    
    [panelText setFrame:textFrm];
    [panelTitle setFrame:titleFrm];
    [groupImage setFrame:imgFrm];
    
    
    [panelText setText:panelTextStr];
    [panelTitle setText:panelTitleText];
    
    [aView addSubview:groupImage];
    [aView addSubview:panelText];
    [aView addSubview:panelTitle];
    
    return aView;
}

-(void) cleanScrollView {
    for (UIView *view in self.scrollView.subviews) {
        if ([view isKindOfClass:[UIView class]])
            [view removeFromSuperview];
    }
}

#pragma mark - BUTTON ACTION

-(IBAction)getStartedAction:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
