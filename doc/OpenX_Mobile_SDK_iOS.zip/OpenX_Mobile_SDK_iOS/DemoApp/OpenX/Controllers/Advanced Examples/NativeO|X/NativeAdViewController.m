//
//  NativeAdViewController.m
//  OpenXDemoApp
//
//  Created by Lawrence Leach on 3/19/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import "NativeAdViewController.h"
#import "AppDelegate.h"
#import "OpenXMSDK.h"
#import "OXMNativeAdRequest.h"
#import "OXMAdInterstitialController.h"
#import "OXMConsole.h"


@interface NativeAdViewController () <UITextFieldDelegate, OXMConsoleDelegate, OXMNativeAdDelegate>
@property (nonatomic, strong) AppDelegate *ad;
@property (nonatomic, strong) OXMAdInterstitialController* adController;
@property (nonatomic, strong) IBOutlet UISwitch *useModalSwitch;
@property (nonatomic, strong) NSString *ad_unit;
@property (nonatomic, strong) NSString *ad_domain;
@property (nonatomic, strong) IBOutlet UITextView *notesView;
@property (nonatomic, strong) IBOutlet UITextView *consoleView;
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, strong) IBOutlet UITextField *banner_ad_unit;
@property (nonatomic, strong) IBOutlet UITextField *url_field;

@property (nonatomic, strong) IBOutlet UIButton *intButton;
@property (nonatomic, strong) IBOutlet UIButton* updateParamsButton;
@property (nonatomic, strong) IBOutlet UILabel *adUnitLabel;
@property (nonatomic, strong) IBOutlet UILabel *adUrlLabel;

@property (nonatomic, strong) IBOutlet UILabel* intNoteLabel;
@property (nonatomic, strong) IBOutlet UILabel* intButtonLabel;
@property (nonatomic, strong) IBOutlet UILabel *codeSample;
@property (nonatomic, strong) IBOutlet UIView *videoView;
@property (nonatomic, strong) IBOutlet UIView *adDetailsView;
@property (nonatomic, strong) IBOutlet UIView *consoleSlideView;
@property (nonatomic, strong) IBOutlet UIView *codeView;
@property (nonatomic, strong) IBOutlet UISegmentedControl *segControl;

@property (nonatomic, strong) OXMNativeAds *oxmAdLoader;
@property (nonatomic, strong) IBOutlet UILabel *adTitleLabel;
@property (nonatomic, strong) IBOutlet UILabel *adDescLabel;
@property (nonatomic, strong) IBOutlet UILabel *adAppUrlLabel;
@property (nonatomic, strong) IBOutlet UIImageView *adCreative;
@property (nonatomic, strong) NSString *appURL;
@end

@implementation NativeAdViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:NO];
    self.title = @"Native O|X";
    
    self.ad = [AppDelegate sharedAppDelegate];
    
    
    // SETUP SCREEN
    [self setupPageViews];
    [self layoutPageViews];
    
    
    // SETUP THE CONSOLE
    [[OXMConsole instance] clear];
    [[OXMConsole instance] enableLog];
    [[OXMConsole instance] setConsoleDelegate:self];
    
    
    
}


-(void)setupPageViews {
    
    CGFloat kMaxPanelWidth = self.scrollView.bounds.size.width;
    CGFloat kMaxPanelHeight = self.scrollView.bounds.size.height;
    
    // SET LABELS
    [self.adUnitLabel setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    [self.adUrlLabel setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    
    
    // SET SEGMENT CONTROL
    [self.segControl addTarget:self action:@selector(segmentTapped:) forControlEvents:UIControlEventValueChanged];
    UIFont *font = [UIFont fontWithName:@"OpenSans-Light" size:12.0f];
    NSDictionary *attributes = [NSDictionary dictionaryWithObject:font forKey:UITextAttributeFont];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateDisabled];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateSelected];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateHighlighted];
    
    self.codeView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 58.0f, kMaxPanelWidth, kMaxPanelHeight)];
    [self.codeView setBackgroundColor:[UIColor blackColor]];
    self.codeView.hidden = YES;
    
    
    // SET CODE, CONSOLE AND SCROLL VIEWS
    self.consoleSlideView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 58.0f, kMaxPanelWidth, kMaxPanelHeight)];
    [self.consoleSlideView setBackgroundColor:[UIColor blackColor]];
    self.consoleSlideView.hidden = YES;
    
    self.codeView = [self setupCodeView:self.codeView];
    self.consoleSlideView = [self setupConsoleView:self.consoleSlideView];
    
    [self.scrollView addSubview:self.codeView];
    [self.scrollView addSubview:self.consoleSlideView];
    
    // SET NATIVE FIELDS
    [self clearNativeFields];
    
    // SET TEXT FIELD FORMATTING
    [self.banner_ad_unit setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0]];
    [self.banner_ad_unit setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.banner_ad_unit setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.banner_ad_unit setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.url_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0f]];
    [self.url_field setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.url_field setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.url_field setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    
    // SET BUTTONS
    self.intButton.titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:18.0f];
    [self.intButton setTitleColor:[UIColor colorWithRed:0.000 green:0.600 blue:0.788 alpha:1.000] forState:UIControlStateNormal];
    [self.intButton setTitleColor:[UIColor colorWithRed:0.000 green:0.600 blue:0.788 alpha:1.000] forState:UIControlStateHighlighted];
    [self.intButton setTitleColor:[UIColor colorWithRed:0.000 green:0.600 blue:0.788 alpha:1.000] forState:UIControlStateSelected];
    [self.intButton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateDisabled];
    [self.intButton setBackgroundImage:[UIImage imageNamed:@"disabled_button"] forState:UIControlStateDisabled];
    [self.intButton setBackgroundImage:[UIImage imageNamed:@"active_button"] forState:UIControlStateNormal];
    [self.intButton setBackgroundImage:[UIImage imageNamed:@"active_button"] forState:UIControlStateHighlighted];
    [self.intButton setBackgroundImage:[UIImage imageNamed:@"active_button"] forState:UIControlStateSelected];
    [self.intButton addTarget:self action:@selector(showInterstitialAd) forControlEvents:UIControlEventTouchUpInside];
    [self.intButton setEnabled:YES];
    
    
    [self setFieldDefaults];
}

-(void)segmentTapped:(UISegmentedControl*)sender {
    NSInteger segment = sender.selectedSegmentIndex;
    
    switch (segment) {
        case 0:
            self.codeView.hidden = YES;
            self.consoleSlideView.hidden = YES;
            break;
            
        case 1:
            self.codeView.hidden = YES;
            self.consoleSlideView.hidden = NO;
            break;
            
        case 2:
            self.codeView.hidden = NO;
            self.consoleSlideView.hidden = YES;
            break;
            
        default:
            break;
    }
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getAdDefaults];
    [self.navigationController setNavigationBarHidden:NO];
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [[OXMConsole instance] setConsoleDelegate:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - LAYOUT

-(void)clearNativeFields
{
    _adAppUrlLabel.text = @"";
    _adDescLabel.text = @"";
    _adTitleLabel.text = @"";
    _adCreative.image = nil;
}

-(void)layoutPageViews
{
    [self setupNativeAdView];
    [self setFieldDefaults];
}


#pragma mark - SETUP FIELDS AND AD BANNER VIEW

-(void)setFieldDefaults {
    self.banner_ad_unit.text = _ad_unit;
    self.url_field.text = _ad_domain;
    
}


-(void)setupNativeAdView
{
    [self getAdDefaults];
    
    // INSTANTIATE THE NATIVE AD OBJECT
    _oxmAdLoader = [[OXMNativeAds alloc] initWithDomain:_ad_domain nativeAdUnitID:_ad_unit];
    [self loadNativeAd];
}

-(void)loadNativeAd
{
    // EXAMPLE OF SETTING CUSTOM AD PARAMETERS
    [_oxmAdLoader.nativeRequest setUserAge:32];
    [_oxmAdLoader.nativeRequest setUserEthnicity:OXMEthnicity_African_American];
    [_oxmAdLoader.nativeRequest setCustomParams:@{@"adpos": @"1"}];
    [_oxmAdLoader.nativeRequest setNativeType:OXMNativeTypeInFeed];
    [_oxmAdLoader.nativeRequest setSequenceNumber:1];
    [_oxmAdLoader.nativeRequest setDesiredIconSize:CGSizeMake(50.0f, 50.f)];
    [_oxmAdLoader.nativeRequest setDesiredImageSize:CGSizeMake(320.f, 50.f)];
    [_oxmAdLoader.nativeRequest setMaximumTextLength:128];
    [_oxmAdLoader.nativeRequest setRequiredFields:OXMNativeFieldTitle|OXMNativeFieldClickURL|OXMNativeFieldAppStoreURL|OXMNativeFieldVideoURL];
    [_oxmAdLoader loadAdWithHandler:^(OXMNativeAdData *ad, NSError *error) {
        
        if (error)
            NSLog(@"\n\n-----------\nAn Error Occurred:\n%@\n------------\n\n", [error localizedDescription]);
        
        else {
            NSLog(@"\n\n-----------\nTitle: %@\nDescription: %@\nImage URL: %@\nActor Name: %@\nActor Image URL: %@\nVideo URL: %@\nAudio URL: %@\nImpression URL: %@\nClick URL: %@\nApp URL: %@\n------------\n\n", ad.title, ad.body, ad.imgurl, ad.actorname, ad.actorimage, ad.videourl, ad.audiourl, ad.impr, ad.clickurl, ad.objectstoreurl);
            
            _adCreative.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:ad.imgurl]]];
            _adTitleLabel.text = ad.title;
            _adDescLabel.text = ad.body;
            _adAppUrlLabel.text = ad.objectstoreurl;
            
            NSLog(@"\n\n-----------\nRaw JSON:\n%@\n-----------\n\n",ad.rawJSON);

            // SET THE AD LOADER DELEGATE
            [ad setNativeAdDelegate:self];
            
            // YOU CALL THESE METHODS IN YOUR APP TO RECORD TAP AND IMPRESSION EVENTS
            [ad performSelector:@selector(adWasViewed) withObject:nil afterDelay:2.0];
            [ad performSelector:@selector(adWasTapped) withObject:nil afterDelay:5.0];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(7 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [ad logEventWithKey:@"MYCUSTOMEVENT" andValue:@"MYCUSTOMVALUE"];
            });
            
        }
    }];
}

-(UIView*)setupCodeView:(UIView*)aView
{
    // TITLE
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 0.0f, 200.0, 40.0)];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:14.0];
    titleLabel.text = @"Code Snippet";
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [aView addSubview:titleLabel];
    
    // SAMPLE CODE
    CGRect frame = CGRectMake(20.0f, 40.0f, 305.0f, 100.0f);
    self.codeSample = [[UILabel alloc] initWithFrame:frame];
    [self.codeSample setBackgroundColor:[UIColor clearColor]];
    self.codeSample.numberOfLines = 6;
    [self.codeSample setFont:[UIFont fontWithName:@"CourierNewPSMT" size:11.0]];
    [self.codeSample setTextColor:[UIColor colorWithRed:0.390 green:0.673 blue:0.262 alpha:1.000]];
    self.codeSample.text = @"[self.adBanner setDomain:@\"AD-DELIVERY-URL\"\n\tportraitAdUnitID:@\"160463\"\n\tlandscapeAdUnitID:@\"160463\"];\n[self.adBanner setAdChangeInterval:30.0f];\n[self.adBanner startLoading];";
    [aView addSubview:self.codeSample];
    
    return aView;
}

-(UIView*)setupConsoleView:(UIView*)aView
{
    // TITLE
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 0.0f, 200.0, 40.0)];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:14.0];
    titleLabel.text = @"Console Output";
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [aView addSubview:titleLabel];
    
    // CONSOLE WINDOW
    //CGRect frame = CGRectMake(8, 58, aView.bounds.size.width-10, 350);
    CGRect frame = CGRectMake(20, 40, aView.bounds.size.width-30, 300);
    self.consoleView = [[UITextView alloc] initWithFrame:frame];
    [self.consoleView setEditable:NO];
    [self.consoleView setFont:[UIFont fontWithName:@"CourierNewPSMT" size:11.0]];
    self.consoleView.text = @"";
    [self.consoleView setBackgroundColor:[UIColor clearColor]];
    [self.consoleView setTextColor:[UIColor whiteColor]];
    [aView addSubview:self.consoleView];
    
    return aView;
}


#pragma mark - LAYOUT METHODS

-(void)layoutSubviews:(UIView*)aView

{
    self.intButton.center = CGPointMake(aView.bounds.size.width/2, aView.bounds.size.height/2);
}


#pragma mark - SHOW INTERSTITIAL AD

-(IBAction)showInterstitialAd {
    
    if (!self.adController.isLoaded)
        return; // can't show if not loaded
    
    OXMAdInterstitialController* ic = (OXMAdInterstitialController*)self.adController;
    
    // To change the position of the close button, you can do:
    //[ic setClosePosition:OXMInterstitialClosePositionAdTopLeft];
    
    // Specify whether to use overlay
    ic.useOverlay = self.useModalSwitch.isOn;
    
    // To change the background opacity of an overlay interstitial, you can do:
    // ic.backgroundOpacity = 0.9;
    
    // Show interstitial
    [ic presentLoadedAd];
}


#pragma mark - DEAL WITH ORIENTATION CHANGE

- (void) didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    [self layoutPageViews];
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}


#pragma mark - SETTINGS

-(void)getAdDefaults
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *domain, *aunit;
    domain = [defaults valueForKey:@"native_server_address"];
    if (self.ad.isIphone) {
        aunit = [defaults valueForKey:@"native_ad_unit"];
        if ([aunit isEqualToString:@""] || [aunit isKindOfClass:[NSNull class]] || aunit == nil)
            //aunit = @"548174";
            aunit = @"555727";
        
    } else {
        aunit = [defaults valueForKey:@"native_ad_unit_tablet"];
        if ([aunit isEqualToString:@""] || [aunit isKindOfClass:[NSNull class]] || aunit == nil)
            //aunit = @"548174";
            aunit = @"555727";
    }
    
    if ([domain isEqualToString:@""] || [domain isKindOfClass:[NSNull class]] || domain == nil)
        domain = @"oxcs-d.openxenterprise.com";
    
    
    _ad_domain = domain;
    _ad_unit = aunit;
    
}

- (IBAction)onAppStorePress:(id)sender
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:_appURL]];
}

- (IBAction)onReloadPress:(id)sender
{
    [self clearNativeFields];
    [self loadNativeAd];
}

-(IBAction)reloadAdUnit:(id)sender
{
    [self saveSettings:nil];
    [self setupNativeAdView];
}

-(IBAction)saveSettings:(id)sender
{
    // SAVE FIELD VALUES TO NSUSERDEFAULTS
    NSString *banner_portrait = self.banner_ad_unit.text;
    NSString *ad_server = self.url_field.text;
    NSString *key_portrait = @"";
    
    if (self.ad.isIphone)
        key_portrait = @"native_ad_unit";
    else
        key_portrait = @"native_ad_unit_tablet";
    
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:banner_portrait forKey:key_portrait];
    [defaults setObject:ad_server forKey:@"native_server_address"];
    [defaults synchronize];
    
    [self.view endEditing:YES];
}


#pragma mark - KEYBOARD METHODS

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField == self.url_field) {
        
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 250, 0)];
        [self.scrollView scrollRectToVisible:CGRectMake(0, self.scrollView.frame.size.height-10, 320, 10) animated:YES];
        
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == self.url_field) {
        
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 0, 0)];
        [textField resignFirstResponder];
    }
}

-(void)animateTextField:(UITextField*)textField up:(BOOL)up andDistance:(NSInteger)movementDistance
{
    //const int movementDistance = 115;
    const float movementDuration = 0.5f;
    
    NSInteger movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations:@"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration:movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}


#pragma mark - UITEXTFIELD DELEGATE METHODS

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark - OXMConsoleDelegate methods

- (void) latestMessage:(NSString*) message {
    self.consoleView.text = [self.consoleView.text stringByAppendingFormat:@"\n%@",message];
    NSLog(@"[OpenX SDK] %@", message);
}


#pragma mark - OXMNativeAdDelegate METHODS

-(void)nativeAdWasViewed
{
    NSLog(@"Native Ad Was Viewed!");
}

-(void)nativeAdWasTapped
{
    NSLog(@"Native Ad Was Tapped!");
}

@end
