//
//  SimpleLocationDetectionViewController.m
//  OpenXDemoApp
//
//  Created by Lawrence Leach on 3/4/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import "SimpleLocationDetectionViewController.h"


@interface SimpleLocationDetectionViewController () <OXMAdBannerDelegate>

@end

@implementation SimpleLocationDetectionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:NO];
    self.title = @"Simple (w/Auto-Detect Location)";
    
    
    self.ad = [AppDelegate sharedAppDelegate];
    
    [self setupPageViews];
    [self layoutPageViews];
    
    
    // SETUP THE CONSOLE
    [[OXMConsole instance] clear];
    [[OXMConsole instance] enableLog];
    [[OXMConsole instance] setConsoleDelegate:self];
    
    // TURN ON CORELOCATION
    _locMgr = [[CLLocationManager alloc] init];
    [_locMgr startUpdatingLocation];
}

-(void)setupPageViews {
    
    CGFloat kMaxPanelWidth = self.scrollView.bounds.size.width;
    CGFloat kMaxPanelHeight = self.scrollView.bounds.size.height;
    
    
    // SET LABELS
    [self.adUnitLabel setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    [self.adUrlLabel setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    
    // SET TEXT FIELDS FORMATTING
    [self.portrait_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0]];
    [self.landscape_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0f]];
    [self.url_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0f]];
    
    
    // SET SEGMENT CONTROL
    [self.segControl addTarget:self action:@selector(segmentTapped:) forControlEvents:UIControlEventValueChanged];
    UIFont *font = [UIFont fontWithName:@"OpenSans-Light" size:12.0f];
    NSDictionary *attributes = [NSDictionary dictionaryWithObject:font forKey:UITextAttributeFont];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateDisabled];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateSelected];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateHighlighted];
    
    self.codeView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 58.0f, kMaxPanelWidth, kMaxPanelHeight)];
    [self.codeView setBackgroundColor:[UIColor blackColor]];
    self.codeView.hidden = YES;
    
    self.consoleSlideView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 58.0f, kMaxPanelWidth, kMaxPanelHeight)];
    [self.consoleSlideView setBackgroundColor:[UIColor blackColor]];
    self.consoleSlideView.hidden = YES;
    
    self.codeView = [self setupCodeView:self.codeView];
    self.consoleSlideView = [self setupConsoleView:self.consoleSlideView];
    
    [self.scrollView addSubview:self.codeView];
    [self.scrollView addSubview:self.consoleSlideView];
    
    [self setFieldDefaults];
}

-(void)segmentTapped:(UISegmentedControl*)sender {
    NSInteger segment = sender.selectedSegmentIndex;
    
    switch (segment) {
        case 0:
            self.codeView.hidden = YES;
            self.consoleSlideView.hidden = YES;
            break;
            
        case 1:
            self.codeView.hidden = YES;
            self.consoleSlideView.hidden = NO;
            break;
            
        case 2:
            self.codeView.hidden = NO;
            self.consoleSlideView.hidden = YES;
            break;
            
        default:
            break;
    }
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [self getAdDefaults];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self.adBanner stopLoading];
    [[OXMConsole instance] setConsoleDelegate:nil];
    [_locMgr stopUpdatingLocation];
    _locMgr = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - HANDLE ORIENTATION

- (void) didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    [self layoutPageViews];
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}


#pragma mark - LAYOUT

-(void)layoutPageViews
{
    [self setupAdBannerView];
    [self setFieldDefaults];
}


#pragma mark - SETUP FIELDS AND AD BANNER VIEW

-(void)setFieldDefaults {
    self.portrait_field.text = self.ad_unit_portrait;
    self.landscape_field.text = self.ad_unit_landscape;
    self.url_field.text = self.ad_domain;
    
}

-(void)setupAdBannerView
{
    
    [self getAdDefaults];
    
    // MRAID SUPPORTS FUNCTIONALITY
    // UNCOMMENT THE FOLLOWING LINE TO DISABLE ADS FROM ACCESSING SPECIFIC DEVICE FUNCIONALITY FOR MRAID V2.0 COMPLIANT ADS
    // CHOICES ARE: OXMMRAIDSupportsFeatureCalendar|OXMMRAIDSupportsFeatureInlineVideo|OXMMRAIDSupportsFeatureSavePicture|OXMMRAIDSupportsFeatureSMS|OXMMRAIDSupportsFeaturePhone
    // OXMDisableMRAIDSupportsFeatures(OXMMRAIDSupportsFeatureCalendar|OXMMRAIDSupportsFeatureInlineVideo);
    
    // CHECK IF AD BANNER OBJECT IS LOADED.
    // IF SO, STOP IT.
    //
    if ([self.adBanner isLoaded])
        [self.adBanner stopLoading];
    
    
    // LOAD A NEW BANNER
    [self.adBanner setAdBannerDelegate:self];
    [self.adBanner setDomain:self.ad_domain
            portraitAdUnitID:self.ad_unit_portrait
           landscapeAdUnitID:self.ad_unit_landscape];
    [self.adBanner setAdChangeInterval:DEFAULT_AD_CHANGE_INTERVAL];
    [self.adBanner.request setAutodetectLocation:YES];
    [self.adBanner request];
    [self.adBanner startLoading];
    
}

-(UIView*)setupCodeView:(UIView*)aView
{
    // TITLE
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 0.0f, 200.0, 40.0)];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:14.0];
    titleLabel.text = @"Code Snippet";
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [aView addSubview:titleLabel];
    
    // SAMPLE CODE
    CGRect frame = CGRectMake(20.0f, 40.0f, 305.0f, 100.0f);
    self.codeSample = [[UILabel alloc] initWithFrame:frame];
    [self.codeSample setBackgroundColor:[UIColor clearColor]];
    self.codeSample.numberOfLines = 6;
    [self.codeSample setFont:[UIFont fontWithName:@"CourierNewPSMT" size:11.0]];
    [self.codeSample setTextColor:[UIColor colorWithRed:0.390 green:0.673 blue:0.262 alpha:1.000]];
    self.codeSample.text = @"[self.adBanner setDomain:@\"AD-DELIVERY-URL\"\n\tportraitAdUnitID:@\"160463\"\n\tlandscapeAdUnitID:@\"160463\"];\n[self.adBanner setAdChangeInterval:30.0f];\n[self.adBanner startLoading];";
    [aView addSubview:self.codeSample];
    
    return aView;
}

-(UIView*)setupConsoleView:(UIView*)aView
{
    // TITLE
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 0.0f, 200.0, 40.0)];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:14.0];
    titleLabel.text = @"Console Output";
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [aView addSubview:titleLabel];
    
    // CONSOLE WINDOW
    //CGRect frame = CGRectMake(8, 58, aView.bounds.size.width-10, 350);
    CGRect frame = CGRectMake(20, 40, aView.bounds.size.width-30, 300);
    self.consoleView = [[UITextView alloc] initWithFrame:frame];
    [self.consoleView setEditable:NO];
    [self.consoleView setFont:[UIFont fontWithName:@"CourierNewPSMT" size:11.0]];
    self.consoleView.text = @"";
    [self.consoleView setBackgroundColor:[UIColor clearColor]];
    [self.consoleView setTextColor:[UIColor whiteColor]];
    [aView addSubview:self.consoleView];
    
    return aView;
}


#pragma mark - SETTINGS

-(void)getAdDefaults {
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *domain, *adunit_portrait, *adunit_landscape;
    domain = [defaults valueForKey:@"simple_ad_server_address"];
    if (self.ad.isIphone) {
        adunit_portrait = [defaults valueForKey:@"simple_banner_portrait"];
        adunit_landscape = [defaults valueForKey:@"simple_banner_landscape"];
    } else {
        adunit_portrait = [defaults valueForKey:@"simple_banner_tablet_portrait"];
        adunit_landscape = [defaults valueForKey:@"simple_banner_tablet_landscape"];
    }
    
    if ([domain isEqualToString:@""] || [domain isKindOfClass:[NSNull class]] || domain == nil)
        domain = @"oxcs-d.openxenterprise.com";
    
    if ([adunit_portrait isEqualToString:@""] || [adunit_portrait isKindOfClass:[NSNull class]] || adunit_portrait == nil) {
        if (self.ad.isIphone) {
            adunit_portrait = @"458439";
            adunit_landscape = @"458439";
        } else {
            adunit_portrait = @"458439";
            adunit_landscape = @"458439";
        }
    }
    
    self.ad_domain = domain;
    self.ad_unit_portrait = adunit_portrait;
    self.ad_unit_landscape = adunit_landscape;
}

-(IBAction)reloadAdUnit:(id)sender
{
    [self saveSettings:nil];
    [self setupAdBannerView];
}

-(IBAction)saveSettings:(id)sender
{
    // SAVE FIELD VALUES TO NSUSERDEFAULTS
    NSString *portrait_banner = self.portrait_field.text;
    NSString *landscape_banner = self.landscape_field.text;
    NSString *ad_server = self.url_field.text;
    NSString *portrait_key = @"";
    NSString *landscape_key = @"";
    if (self.ad.isIphone) {
        portrait_key = @"simple_banner_portrait";
        landscape_key = @"simple_banner_landscape";
    } else {
        portrait_key = @"simple_banner_tablet_portrait";
        landscape_key = @"simple_banner_tablet_landscape";
    }
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:portrait_banner forKey:portrait_key];
    [defaults setObject:landscape_banner forKey:landscape_key];
    [defaults setObject:ad_server forKey:@"simple_ad_server_address"];
    [defaults synchronize];
    
    [self.view endEditing:YES];
    
    //[self.navigationController popToRootViewControllerAnimated:YES];
}


#pragma mark - OXMConsoleDelegate methods

- (void) latestMessage:(NSString*) message {
    NSLog(@"[OpenX SDK] %@", message);
    self.consoleView.text = [self.consoleView.text stringByAppendingFormat:@"\n%@",message];
}


#pragma mark - KEYBOARD METHODS

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField == self.url_field) {
        
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 250, 0)];
        [self.scrollView scrollRectToVisible:CGRectMake(0, self.scrollView.frame.size.height-10, 320, 10) animated:YES];
        
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
    if (textField == self.url_field) {
        
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 0, 0)];
        [textField resignFirstResponder];
    }
}


-(void)animateTextField:(UITextField*)textField up:(BOOL)up andDistance:(NSInteger)movementDistance
{
    //const int movementDistance = 115;
    const float movementDuration = 0.5f;
    
    NSInteger movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations:@"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration:movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}


#pragma mark - UITEXTFIELD DELEGATE METHODS

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - OXMAdBannerDelegate methods

-(void)adBannerActionDidBegin:(OXMAdBanner *)adBanner {
    NSLog(@"\nadBannerActionDidBegin fired");
}

-(void)adBannerActionDidFinish:(OXMAdBanner *)adBanner{
    NSLog(@"\nadBannerActionDidFinish fired");
}

-(void)adBannerActionUnableToBegin:(OXMAdBanner *)adBanner {
    NSLog(@"\nadBannerActionUnableToBegin fired");
}

-(void)adBanner:(OXMAdBanner *)banner didFailToReceiveAdWithError:(NSError *)error {
    NSLog(@"\nError:\n%@", error.description);
}

- (void) adBannerDidLoadAd:(OXMAdBanner*)banner {
    
    NSLog(@"\nadBannerDidLoadAd fired");
    CGFloat width = banner.bounds.size.width;
    CGFloat height = banner.bounds.size.height;
    [self.adBanner setFrame:CGRectMake(0.0f, 0.0f, width, height)];
    
}

-(void)adBannerActionWillBegin:(OXMAdBanner *)adBanner willLeaveApplication:(BOOL)willLeave {
    NSLog(@"\nadBannerActionShouldBegin fired");
}

@end
