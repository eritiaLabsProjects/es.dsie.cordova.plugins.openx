package com.openx.openx_appstore_demo;

import android.app.Activity;
import android.content.res.Configuration;
import android.view.Display;
import android.view.WindowManager;


// TODO: Auto-generated Javadoc
/**
 * Utilities.
 */
public final class Utils {

	private static int[][] mPreDefinedSizes = new int[][] {
		new int[] { 480, 800, 347262, 3 },
		new int[] { 720, 1280, 347263, 4 },
		new int[] { 800, 1280, 347264, 5 },
		new int[] { 800, 480, 347264, 0 },
		new int[] { 1280, 720, 347261, 1 },
		new int[] { 1280, 800, 347261, 2 }
	};
	
	private static int[][] mPreDefinedInterstitialSizes = new int[][] {
		new int[] { 480, 800, 347257, 3 },
		new int[] { 720, 1280, 347256, 4 },
		new int[] { 800, 1280, 347260, 5 },
		new int[] { 800, 480, 347258, 0 },
		new int[] { 1280, 720, 347255, 1 },
		new int[] { 1280, 800, 347259, 2 }
	};

	private static int getUid(int[][] source, WindowManager windowManager, boolean otherOrientation) {
    	int width = getScreenWidth(windowManager);
    	int height = getScreenHeight(windowManager);
    	float spwidth;
    	float spheight;
    	float lspwidth = 0f;
    	float lspheight = 0f;
    	int bi = 0;
    	int ci = 0;
    	
    	for (int[] set : source) {
    		spwidth = 100f - Math.abs((width - set[0]) / ((width + set[0]) / 2f) * 100f);
    		spheight = 100f - Math.abs((height - set[1]) / ((height + set[1]) / 2f) * 100f);
    		
    		if (spwidth + spheight > lspwidth + lspheight) {
    			lspwidth = spwidth;
    			lspheight = spheight;
    			bi = ci;
    		}
    		++ci;
    	}
    	
    	int selectedId = !otherOrientation ? source[bi][2] : source[source[bi][3]][2];
    	return selectedId;
	}
	
    public static int getUidFor(Activity activity) {
    	int orientation = getDeviceOrientation(activity);
    	switch (orientation) {
			case Configuration.ORIENTATION_PORTRAIT:
				return getUid(mPreDefinedSizes, activity.getWindowManager(), false);
			case Configuration.ORIENTATION_LANDSCAPE:
				return getUid(mPreDefinedSizes, activity.getWindowManager(), true);
			default:
				return 0;
		}
	}

    public static int getRotatedUidFor(Activity activity) {
    	int orientation = getDeviceOrientation(activity);
    	switch (orientation) {
			case Configuration.ORIENTATION_PORTRAIT:
				return getUid(mPreDefinedSizes, activity.getWindowManager(), true);
			case Configuration.ORIENTATION_LANDSCAPE:
				return getUid(mPreDefinedSizes, activity.getWindowManager(), false);
			default:
				return 0;
		}
	}
    
    public static int getInterstitialUidFor(Activity activity) {
    	int orientation = getDeviceOrientation(activity);
    	switch (orientation) {
			case Configuration.ORIENTATION_PORTRAIT:
				return getUid(mPreDefinedInterstitialSizes, activity.getWindowManager(), false);
			case Configuration.ORIENTATION_LANDSCAPE:
				return getUid(mPreDefinedInterstitialSizes, activity.getWindowManager(), true);
			default:
				return 0;
		}	
	}

    public static int getRotatedInterstitialUidFor(Activity activity) {
    	int orientation = getDeviceOrientation(activity);
    	switch (orientation) {
			case Configuration.ORIENTATION_PORTRAIT:
				return getUid(mPreDefinedInterstitialSizes, activity.getWindowManager(), true);
			case Configuration.ORIENTATION_LANDSCAPE:
				return getUid(mPreDefinedInterstitialSizes, activity.getWindowManager(), false);
			default:
				return 0;
		}	
	}

    private static int getDeviceOrientation(Activity context) {
    	if (context != null) {
			Configuration config = context.getResources().getConfiguration();
			return config != null ? config.orientation
					: Configuration.ORIENTATION_UNDEFINED;
    	} else {
    		return Configuration.ORIENTATION_UNDEFINED;
    	}
	}
    
	private static int getScreenWidth(WindowManager windowManager) {
        if (windowManager != null) {
            Display display = windowManager.getDefaultDisplay();
            return display.getWidth();
        }
        return 0;
	}

	private static int getScreenHeight(WindowManager windowManager) {
        if (windowManager != null) {
            Display display = windowManager.getDefaultDisplay();
            return display.getHeight();
        }
        return 0;
	}
}
