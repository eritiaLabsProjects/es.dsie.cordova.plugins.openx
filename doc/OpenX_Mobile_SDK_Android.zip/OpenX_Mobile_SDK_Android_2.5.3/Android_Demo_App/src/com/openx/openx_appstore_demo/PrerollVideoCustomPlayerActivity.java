package com.openx.openx_appstore_demo;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import com.openx.model.AdCallParams;
import com.openx.model.AdCallParams.OXMGender;
import com.openx.model.Offset;
import com.openx.model.VideoAdEvent.Event;
import com.openx.model.VideoAdEventListener;
import com.openx.model.VideoAdManager;
import com.openx.model.VideoAdManager.ContentCompletionListener;
import com.openx.widgets.CustomVideoView;

public class PrerollVideoCustomPlayerActivity extends Activity implements VideoAdEventListener {


	private RelativeLayout videoContainer;
	private CustomVideoView customVideoView;
	private VideoAdManager videoAdManager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		// Remove title bar
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_video_preroll);

		createPrerollAd();

	}
	
	private void createPrerollAd(){
		
		//Required: get a reference to the RelativeLayout container for the video in which your custom content video player already sits
	    videoContainer = (RelativeLayout) findViewById(R.id.videoContainer);
	 
	    //Required: get a reference to the custom VideoView instance that is available from your custom video player
	    //This object must extend from the VideoView class.  See the instructions on how to implement your custom video player
	    customVideoView = (CustomVideoView) findViewById(R.id.customvideoview);
	 
	    //Required: instantiate the VideoAdManager
	    videoAdManager = new VideoAdManager(this);
	 
	    //Required: set the VideoContainer by passing in the reference
	    videoAdManager.setVideoContainer(videoContainer);
	 
	    //Required: set the Custom VideoView
	    videoAdManager.setVideoView(customVideoView);
	 
	    //Required: set the Url of the main video content that will be played. 
	    //Note, you can alternatively set a video playlist of multiple content videos by using the setVideoContentPlaylist(..) method.
	    videoAdManager.setVideoContentUrl("http://i.cdn.openx.com/videos/mobile/OpenX_NYC_Tim3_2_Audio.mp4");
	     
	    //Optionally set the Skip Offset time for the video ad.  This will force a user to watch an ad for a set duration of time.
	    //Not setting this will allow the user to fast forward through the ad.  Setting the value to -1 dissallows skipping.
	    videoAdManager.setSkipOffset("00:00:05.000");
	     
	    //Required: set the Url of the assigned VAST tag from the OpenX Ad Server
	    videoAdManager.setVASTTag("http://oxv4support-d3.openxenterprise.com/v/1.0/av?auid=537074373");   
	     
	    //Optionally set the boolean for allowing or disallowing fullscreen (default is true)
	    videoAdManager.setAllowFullscreen(true);
	 
	    //Required: set the pre-roll ad break (start of the content video)
	    videoAdManager.addTimeOffset(Offset.start());
	 
	    //Below are examples of other ad break types for mid-rolls and post-rolls to the content video.
	    //See the OpenX SDK documentation for the full JavaDoc description of these Time Offsets in the Offset class.
	     
	    //videoAdManager.addTimeOffset(Offset.time("00:02:20.000"));
	    //videoAdManager.addTimeOffset(Offset.percentage(20));
	    //videoAdManager.addTimeOffset(Offset.firstQuartile());
	    //videoAdManager.addTimeOffset(Offset.midpoint());
	    //videoAdManager.addTimeOffset(Offset.thirdQuartile());
	    //videoAdManager.addTimeOffset(Offset.end());
	 
	    //optionally set a callback for the notification for the completion of the content video
	    videoAdManager.setContentCompletionListener(new ContentCompletionListener(){
	 
	        @Override
	        public void onContentCompletion(String url, boolean isEndOfPlaylist) {
	             
	            Log.i("COMPLETION", url + "isEndOfPlaylist 1: " + isEndOfPlaylist);
	 
	            //videoAdManager.addTimeOffset(Offset.percentage(5));
	 
	        }   
	    });
	    
	    //Optionally set custom target parameters, see developer integration documentation for more detail:
	    //http://docs.openx.com/sdk/#android_sdk_advanced_banner_integration.html
	    AdCallParams params = new AdCallParams();
	    params.setUserGender(OXMGender.MALE); 
	    params.setUserAge(30);
	    params.setUserAnnualIncomeInUs(60000);     
	    videoAdManager.setAdCallParams(params);
	    
	    //Required: create a helper method (see below) that defines an overlay view that serves as a user-clickable view for the clickthrough to the ad's destination.
	    //Note that the example provides a TextView, but it can be any complex View deriving from the View class
	    createVisitAdvertiserLink();
	    
	    videoAdManager.addVideoAdEventListener(this);
	 
	    //Required: finally, start the video sequence  
	    videoAdManager.start();

	}
	
	private void createVisitAdvertiserLink(){
		
		//Note that the example provides a TextView, but it can be any complex View deriving from the View class
		TextView textVisitAdvertiserLink = new TextView(this);	
		
		textVisitAdvertiserLink.setText("Custom Visit Advertiser");
		textVisitAdvertiserLink.setTextColor(Color.WHITE);
		textVisitAdvertiserLink.setShadowLayer(1.0f, 1.0f, 1.0f, Color.BLACK);

		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.addRule(RelativeLayout.ALIGN_PARENT_TOP);
		params.addRule(RelativeLayout.CENTER_HORIZONTAL);
		textVisitAdvertiserLink.setLayoutParams(params);
		
		//Required: set the View that will serve as the clickthrough to the ad's destination.  This can be any object deriving from View that cues the user to click. 
		videoAdManager.setVisitAdvertiserLink(textVisitAdvertiserLink);
	} 
	
	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		// TODO Auto-generated method stub
		super.onWindowFocusChanged(hasFocus);
		
		if(!hasFocus){
			videoAdManager.threadStop();
		}else{
			videoAdManager.threadResume();
		}
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		
		setContainerOrientation(newConfig);
	}
	
	private void setContainerOrientation(Configuration newConfig){
		if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE){
			
			RelativeLayout.LayoutParams relParams = new RelativeLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);//(RelativeLayout.LayoutParams)container.getLayoutParams();

			
			relParams.addRule(RelativeLayout.CENTER_IN_PARENT);
			videoContainer.setLayoutParams(relParams);
		
		}else if(newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
		
			RelativeLayout.LayoutParams relParams = new RelativeLayout.LayoutParams(getScreenWidth(), 400);//(RelativeLayout.LayoutParams)container.getLayoutParams();

			videoContainer.setLayoutParams(relParams);
			customVideoView.invalidate();
		
		}
	}

	
	private int getScreenWidth(){

		int width = getWindowManager().getDefaultDisplay().getWidth();
		int height = getWindowManager().getDefaultDisplay().getHeight();
		
		if(width > height){
			return height;
		}else{
			return width;
		}
	}

	@Override
	public void onVideoAdEvent(Event event) {
		
		switch(event){
			case AD_START:
			case AD_RESUME:
				customVideoView.getMediaController().setVisibility(View.GONE);
				break;
			case CONTENT_START:
			case CONTENT_RESUME:
				customVideoView.getMediaController().setVisibility(View.VISIBLE);
				break;
		}
		
	}

}
