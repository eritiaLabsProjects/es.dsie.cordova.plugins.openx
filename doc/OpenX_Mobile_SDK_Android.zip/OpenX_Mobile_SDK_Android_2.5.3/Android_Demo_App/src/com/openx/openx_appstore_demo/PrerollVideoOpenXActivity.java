package com.openx.openx_appstore_demo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.RelativeLayout;

import com.openx.model.AdCallParams;
import com.openx.model.AdCallParams.OXMEthnicity;
import com.openx.model.AdCallParams.OXMGender;
import com.openx.model.AdCallParams.OXMMaritalStatus;
import com.openx.model.Offset;
import com.openx.model.VideoAdEvent;
import com.openx.model.VideoAdEventListener;
import com.openx.model.VideoAdManager;
import com.openx.model.VideoAdManager.ContentCompletionListener;

public class PrerollVideoOpenXActivity extends Activity implements VideoAdEventListener {
	

	private VideoAdManager videoAdManager;
	private RelativeLayout videoContainer; 

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		// Remove title bar
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_video_preroll_openx);
		
		createPrerollAd();
		
	}

	private void createPrerollAd(){

		//Required: get a reference to the RelativeLayout container for the video
	    videoContainer = (RelativeLayout) findViewById(R.id.videoContainer);
	 
	    //Required: instantiate the VideoAdManager
	    videoAdManager = new VideoAdManager(this);
	 
	    //Required: set the videoContainer by passing in the reference
	    videoAdManager.setVideoContainer(videoContainer);
	 
	    //Required: set the Url of the main video content that will be played. 
	    //Note, you can alternatively set a video playlist of multiple content videos by using the setVideoContentPlaylist(..) method.
	    videoAdManager.setVideoContentUrl("http://i.cdn.openx.com/videos/mobile/OpenX_NYC_Tim3_2_Audio.mp4");
   
	    //Optionally set the Skip Offset time for the video ad.  This will force a user to watch an ad for a set duration of time.
	    //Not setting this will allow the user to fast forward through the ad.  Setting the value to -1 disallows skipping.
	    videoAdManager.setSkipOffset("00:00:05.000");
	     
	    //Required: set the Url of the assigned VAST tag from the OpenX Ad Server
	    videoAdManager.setVASTTag("http://oxv4support-d3.openxenterprise.com/v/1.0/av?auid=537074373");	     
	     
	    //Optionally set the boolean for allowing or disallowing fullscreen (default is true)
	    videoAdManager.setAllowFullscreen(true);
	 
	    //Required: set the pre-roll ad break (start of the content video)
	    videoAdManager.addTimeOffset(Offset.start());
	 
	    //Below are examples of other ad break types for mid-rolls and post-rolls to the content video.
	    //See the OpenX SDK documentation for the full JavaDoc description of these Time Offsets in the Offset class.
	 
	    //videoAdManager.addTimeOffset(Offset.time("00:02:20.000"));
	    //videoAdManager.addTimeOffset(Offset.percentage(10));
	    //videoAdManager.addTimeOffset(Offset.percentage(20));
		//videoAdManager.addTimeOffset(Offset.firstQuartile());
		//videoAdManager.addTimeOffset(Offset.midpoint());
		//videoAdManager.addTimeOffset(Offset.thirdQuartile());
		videoAdManager.addTimeOffset(Offset.end());
	    
	    //Optionally set custom target parameters, see developer integration documentation for more detail:
	    //http://docs.openx.com/sdk/#android_sdk_advanced_banner_integration.html
//	    AdCallParams params = new AdCallParams(); 
//		params.setUserGender(OXMGender.MALE);  
//		params.setUserAge(30); 
//		params.setUserAnnualIncomeInUs(60000);      
//		videoAdManager.setAdCallParams(params);

	    //optionally set a callback for the notification for the completion of the content video
	    videoAdManager.setContentCompletionListener(new ContentCompletionListener(){
	 
	        @Override
	        public void onContentCompletion(String url, boolean isEndOfPlaylist) {
	    
	            //videoAdManager.addTimeOffset(Offset.percentage(5));
	 
	        }   
	    });
	    
	    //Optional to receive ad related event callbacks for any video, or content related callbacks for content video
	    videoAdManager.addVideoAdEventListener(this);
	 
	    //Required: finally, start the video sequence  
	    videoAdManager.start();
	
	}
	
	//Required:  This will managed the state of the VideoAdManager thread in the case the Activity is minimized due to a phone call or other event.
	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		// TODO Auto-generated method stub
		super.onWindowFocusChanged(hasFocus);
		
		if(!hasFocus){
			videoAdManager.threadStop();
		}else{
			videoAdManager.threadResume();
		}
	}

	//Required:  If the Video is in Full Screen mode we want to allow the back press to simply minimize the video and not finish the Activity entirely
	@Override
	public void onBackPressed() {
		
		if(!videoAdManager.getIsFullScreen()){

			super.onBackPressed();
		}else{
			videoAdManager.makeCollapsedScreen();
		}
	}

	@Override
	public void onVideoAdEvent(VideoAdEvent.Event event) {
		
		Log.i("VIDEO_AD_EVENT", "Event: " + event);
		
		switch(event){
		
				

				case AD_IMPRESSION :
					break;					
				case AD_CREATIVEVIEW :
					break;
				case AD_START :
					break;
				case AD_FIRSTQUARTILE :
					break;
				case AD_MIDPOINT :
					break;
				case AD_THIRDQUARTILE :
					break;
				case AD_COMPLETE :
					break;
				case AD_MUTE :
					break;
				case AD_UNMUTE :
					break;
				case AD_PAUSE :
					break;
				case AD_REWIND :
					break;
				case AD_RESUME :
					break;
				case AD_FULLSCREEN :
					break;
				case AD_EXITFULLSCREEN :
					break;
				case AD_EXPAND :
					break;
				case AD_COLLAPSE :
					break;
				case AD_ACCEPTINVITATION :
					break;
				case AD_ACCEPTINVITATIONLINEAR :
					break;
				case AD_CLOSELINEAR :
					break;
				case AD_CLOSE :
					break;
				case AD_SKIP :
					break;
				case AD_PROGRESS :
					break;
		
		}
		
	}

}
