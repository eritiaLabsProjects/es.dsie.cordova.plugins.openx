//
//  InfeedVideoCollectionView.m
//  OpenXDemoApp
//
//  Created by Jon Flanders on 5/27/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import "InfeedVideoCollectionViewCell.h"
@interface InfeedVideoCollectionViewCell()
@property (nonatomic,strong) OXMVideoAdManager* videoAdManager;
@property (nonatomic,strong) IBOutlet UIView* playerContainer;
@property (nonatomic,strong) IBOutlet OXMMediaPlaybackView* openXPlayer;
@end
@implementation InfeedVideoCollectionViewCell
-(void)prepareForReuse{
    self.openXPlayer = [[OXMMediaPlaybackView alloc] initWithFrame:self.playerContainer.frame];
    
    
}
-(void)setVastTag:(NSString *)vastTag{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(globalHawk:)
                                                 name:@"UITextSelectionDidScroll"
                                               object:nil];
    _vastTag = vastTag;
    self.videoAdManager = [[OXMVideoAdManager alloc] initWithVASTTag:vastTag];
    self.videoAdManager.fullScreenOnOrientationChange = NO;
   // self.videoAdManager.adManagerDelegate = self;
    [self.openXPlayer setBackgroundColor:[UIColor clearColor]];
    [self.videoAdManager setVideoPlayerView:self.openXPlayer];
    [self.playerContainer setBackgroundColor:[UIColor clearColor]];
    [self.videoAdManager setVideoContainer:self.playerContainer];
    [self.videoAdManager startAdManager];
    
}
@end
