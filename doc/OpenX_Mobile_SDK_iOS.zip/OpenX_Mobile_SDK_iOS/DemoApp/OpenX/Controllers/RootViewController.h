//
//  RootViewController.h
//  OpenX
//
//  Copyright (c) 2013 OpenX Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TutorialViewController;

@interface RootViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) IBOutlet UITableView *theTableView;
@property (nonatomic, strong) IBOutlet UIToolbar *toolBar;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *settingsButton;

@property (nonatomic, assign) BOOL tutorial_run;

@property (nonatomic, strong) TutorialViewController *tutorialViewController;

@end
