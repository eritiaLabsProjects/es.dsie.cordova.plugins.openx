package com.openx.widgets;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.openx.openx_appstore_demo.R;

/**
 * Gallery Image Adapter Class
 * 
 * Image Adapter for the main screen
 * */
public class GalleryImageAdapter extends PagerAdapter {

	private Context context;
	int height;

	int[] res = { R.drawable.img1, R.drawable.img2, R.drawable.img3,
			R.drawable.img4, R.drawable.img5, R.drawable.img6 };

	String[] titles = { "Welcome!", "Multiple ad formats", "Rich Media Ads",
			"Customization", "Developer Tools", "3rd Party Plug-ins" };

	String[] body = {
			"The OpenX mobile SDKs provide you with tools for integrating the OpenX Ad Server with your Android & iOS apps to increase revenue through mobile Advertising.",
			"Support for the interstitial ads and standard IAB/MMA banner inventory.",
			"Support for click-to-action, Mobile Rich-media Ad Interface (MRAID), Celtra & HTML5 ad units.",
			"Target multiple screen sizes and display orientations and include custom ad parameters using key-value pairs.",
			"Configure event listeners and view messages coming back from the ad server in real time.",
			"An optional Unity plugin allows you to incorporate OpenX ad inventory into your Unoty 3D app." };

	/**
	 * array to hold all views this is to deal with the gallery widget always
	 * returning null for convertView.
	 */
	private LinearLayout[] viewCache = new LinearLayout[res.length];

	public GalleryImageAdapter(Context context, int height) {

		this.context = context;
		this.height = height;
	}

	public int getCount() {
		return res.length;
	}

	public Object getItem(int position) {
		return null;
	}

	public long getItemId(int position) {
		return position;
	}

	@Override
	public Object instantiateItem(ViewGroup container, int position) {

		if (null == viewCache)
			viewCache = new LinearLayout[res.length];

		if (null == viewCache[position]) {

			if (null == context)
				return null;

			final LinearLayout layout = new LinearLayout(context);

			layout.setOrientation(LinearLayout.VERTICAL);

			ImageView img = new ImageView(context);
			img.setImageResource(res[position]);
			img.setScaleType(ScaleType.CENTER_INSIDE);

			TextView txtTitle = new TextView(context);
			txtTitle.setText(titles[position]);
			txtTitle.setTextColor(0xFFFFFFFF);
			txtTitle.setTypeface(null, Typeface.BOLD);

			TextView txtBody = new TextView(context);
			txtBody.setText(body[position]);
			txtBody.setTextColor(0xFFFFFFFF);

			layout.addView(img);
			layout.addView(txtTitle);
			layout.addView(txtBody);

			viewCache[(position)] = layout;

		}

		((ViewPager) container).addView(viewCache[position], 0);
		return viewCache[position];
	}

	@Override
	public void destroyItem(ViewGroup collection, int position, Object view) {
		((ViewPager) collection).removeView((LinearLayout) view);
	}

	@Override
	public void destroyItem(View collection, int position, Object view) {
		((ViewPager) collection).removeView((LinearLayout) view);
	}

	@Override
	public boolean isViewFromObject(View view, Object object) {
		return view == ((LinearLayout) object);
	}
}
