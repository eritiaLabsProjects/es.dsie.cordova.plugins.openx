//
//  NativeInFeedVideoViewController.m
//  OpenXDemoApp
//
//  Created by Jon Flanders on 5/13/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import "NativeInFeedVideoViewController.h"
#import "InfeedVideoTableViewCell.h"
#import "InfeedFeedTableViewCell.h"

@interface NativeInFeedVideoViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) NSArray *feedData;
@end

@implementation NativeInFeedVideoViewController
static CGFloat videoHeight  = 180;
static CGFloat imageHeight = 160;
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if([self isVideoCell:indexPath]){
        return videoHeight;
    }
    return imageHeight;
}


#pragma mark Table View Data Source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.feedData.count;
}

-(BOOL)isVideoCell:(NSIndexPath*)indexPath{
    BOOL isVideo = NO;
    NSInteger rowOffset = indexPath.row%videoCellOffset;
    isVideo = (rowOffset==0);
    return isVideo;
}

static NSUInteger videoCellOffset = 15;
static NSString* cellID = @"FeedCell";
static NSString* videoCellID = @"VideoCell";

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if([self isVideoCell:indexPath]){
        cell =[tableView dequeueReusableCellWithIdentifier:videoCellID];
        InfeedVideoTableViewCell* videoCell = (InfeedVideoTableViewCell*)cell;
        videoCell.vastTag =  @"http://oxv4support-d3.openxenterprise.com/v/1.0/av?auid=536875736";
    }else{
        InfeedFeedTableViewCell* imageCell = (InfeedFeedTableViewCell*)cell;
        imageCell.rowIndex = indexPath.row;
    }
    return cell;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    // Do any additional setup after loading the view.
    NSUInteger count = 500;
    NSMutableArray *dummyData = [[NSMutableArray alloc] initWithCapacity:count];
    for (NSInteger i = 0; i<count; i++) {
        [dummyData addObject:[NSNumber numberWithInteger:i]];
    }
    self.feedData = dummyData;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
