//
//  TutorialViewController.h
//  OpenXDemoApp
//
//  Copyright (c) 2013 OpenX Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface TutorialViewController : UIViewController <UIScrollViewDelegate>

@property (strong, nonatomic) AppDelegate *ad;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UILabel *welcomeLabel;
@property (strong, nonatomic) IBOutlet UITextView *welcomeTextView;
@property (strong, nonatomic) IBOutlet UIPageControl *pageControl;
@property (strong, nonatomic) IBOutlet UIButton *getStartedButton;

-(IBAction)getStartedAction:(id)sender;

@end
