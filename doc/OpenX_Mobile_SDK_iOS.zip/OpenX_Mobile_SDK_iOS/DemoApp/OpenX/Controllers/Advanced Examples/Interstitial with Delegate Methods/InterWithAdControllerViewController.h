//
//  InterWithAdControllerViewController.h
//  OpenX
//
//  Copyright (c) 2013 OpenX Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface InterWithAdControllerViewController : UIViewController

@end
