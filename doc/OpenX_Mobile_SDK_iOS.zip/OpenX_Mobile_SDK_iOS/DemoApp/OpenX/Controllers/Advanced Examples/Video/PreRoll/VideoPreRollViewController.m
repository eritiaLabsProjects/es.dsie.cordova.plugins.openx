//
//  VideoPreRollViewController.m
//  OpenXDemoApp
//
//  Created by Lawrence Leach on 3/4/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>
#import "AppDelegate.h"
#import "VideoPreRollViewController.h"
#import "CustomPlayerView.h"


@interface VideoPreRollViewController () <OXMVideoAdManagerDelegate>
@property (nonatomic, strong) AppDelegate *ad;
@property (nonatomic, strong) OXMVideoAdManager *adManager;
@property (nonatomic, strong) IBOutlet OXMMediaPlaybackView *playerView; // For content playback using the OpenX player
@property (nonatomic, strong) IBOutlet UIView *contentContainerView;     // UIView for holding video content

@property (nonatomic, strong) IBOutlet MPMoviePlayerController *mp_movie_player;
@property (nonatomic, strong) AVPlayer *av_movie_player;

@property (nonatomic, strong) MPMoviePlayerController *mp_ad_player;
@property (nonatomic, strong) AVQueuePlayer *av_ad_player;

@property (nonatomic, strong) UIView *customAdView;                      // UIView for holding a custom ad player
@property (nonatomic, strong) IBOutlet CustomPlayerView *customPlayerView;

@property (nonatomic, strong) NSString *vast_tag;
@property (nonatomic, strong) NSString *video_one;
@property (nonatomic, strong) NSString *video_two;
@property (nonatomic, strong) NSString *video_three;
@property (nonatomic, strong) NSString *video_four;
@property (nonatomic, strong) NSString *video_five;
@property (nonatomic, strong) NSString *video_six;

@end


@implementation VideoPreRollViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:NO];
    
    // VAST TAG
    _vast_tag = @"http://oxv4support-d3.openxenterprise.com/v/1.0/av?auid=536875736";
    
    
    // VIDEO CONTENT
    _video_one = @"http://i.cdn.openx.com/videos/mobile/OpenX_NYC_Tim3_2_Audio.mp4";
    _video_two = @"http://i.cdn.openx.com/videos/mobile/Tim_Miami_Edit_1.mp4";
    _video_three = @"http://i.cdn.openx.com/videos/mobile/Sell_Side_Discussion_Tim3.mp4";
    _video_four = @"http://cf.shacknews.com/video/robot/73b457a7524b822f5364905756cd9344_480p.mp4";
    _video_five = @"http://clips.vorwaerts-gmbh.de/VfE_html5.mp4";

    // HLS (M3U8) EXAMPLE
    // NOTE: Uncomment the next line if you wish to test the delivery of HLS content video.
    //_video_six = @"https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8";
    
    
    // SET PAGE TITLE
    NSString *title;
    if ([_adType isEqualToString:@"preRollOpenX"])
        title = @"Video: OpenX Player";
    else if ([_adType isEqualToString:@"preRollCustomAVPlayer"])
        title = @"Video: Custom AVPlayer";
    else if ([_adType isEqualToString:@"preRollCustomMPPlayer"])
        title = @"Video: Custom MPMoviePlayer";
    else if ([_adType isEqualToString:@"preRollSwappingAVPlayer"])
        title = @"Video: Swapping AVPlayer";
    else if ([_adType isEqualToString:@"preRollSwappingMPPlayer"])
        title = @"Video: Swapping MPMoviePlayer";
    self.title = title;
    
    _ad = [AppDelegate sharedAppDelegate];
    
    
    // CREATE A NEW AD MANAGER OBJECT
    [self loadAdManager];
}

-(void)viewWillDisappear:(BOOL)animated
{
    _adManager = nil;
    
    [_mp_ad_player pause];
    [_mp_movie_player pause];

    _mp_movie_player = nil;
    _mp_ad_player = nil;
    
    _av_movie_player = nil;
}

-(void)dealloc
{
    _adManager.videoPlayerView = nil;
    _adManager = nil;
    
    [_mp_ad_player pause];
    [_mp_movie_player pause];
    
    _mp_movie_player = nil;
    _mp_ad_player = nil;
    
    _av_movie_player = nil;

}

#pragma mark - AD MANAGER

-(void)loadAdManager
{
    // INIT AD MANAGER

    _adManager = [[OXMVideoAdManager alloc] initWithVASTTag:_vast_tag];
    

    // SET YOURSELF AS THE AD MANAGER DELEGATE
    [_adManager setAdManagerDelegate:self];
    
    
    // CONTENT PLAYLIST AND AD BREAKS
    NSArray *playlist = @[_video_one, _video_two, _video_three, _video_four, _video_five];
    NSArray *adBreaks = @[@[@"00:00:00.000",@"00:00:10.000",@"00:00:30.000",@"00:01:00.000",@"00:02:00.000"],
                          @[@"00:00:00.000",@"00:00:30.000",@"00:01:00.000",@"00:02:00.000",@"00:02:30.000"],
                          @[@"00:00:00.000",@"00:00:30.000",@"00:01:00.000",@"00:02:00.000",@"00:02:30.000"],
                          @[@"00:00:10.000",@"00:00:30.000",@"00:01:00.000",@"00:02:00.000",@"00:02:30.000"],
                          @[@"00:00:00.000",@"00:00:40.000",@"00:01:00.000",@"00:03:00.000",@"00:04:00.000"]];

     [_adManager setContentPlaylist:playlist];
     [_adManager setContentAdBreaks:adBreaks];

    
    
    // SET AD SKIP OFFSET
    [_adManager setSkipOffSet:@"00:00:05.000"];
    
    // SET CUSTOM AD PARAMETERS
    [_adManager.adRequest setUserAge:32];
    [_adManager.adRequest setUserGender:OXMGender_Other];
    [_adManager.adRequest setUserMaritalStatus:OXMMaritalStatus_Single];
    [_adManager.adRequest setUserEthnicity:OXMEthnicity_Hispanic];
    
    // ORIENTATION PARAMETERS
    _adManager.fullScreenOnOrientationChange = NO;
    _adManager.fullScreenOnStart = YES;
    
    UIInterfaceOrientation interfaceOrientation = [[UIApplication sharedApplication] statusBarOrientation];
    CGRect frame;

    if (UIInterfaceOrientationIsPortrait(interfaceOrientation))
        frame = CGRectMake(0.f, 0.f, 320.f, 180.f);
    else
        frame = CGRectMake(0.f, 0.f, [[self view] bounds].size.width, [[self view] bounds].size.height);

    
    // SET A CUSTOM MPMOVIEPLAYERCONTROLLER FOR CONTENT
    if ([_adType isEqualToString:@"preRollSwappingMPPlayer"]) {

        
        // MPMOVIEPLAYERCONTROLLER
        // STEP 1. - INSTANTIATE THE PLAYER & SET THE FRAME SIZE
        _mp_movie_player = [[MPMoviePlayerController alloc] init];
        _mp_movie_player.view.frame = frame;
        
        
        // STEP 2. - CREATE A VIDEO CONTAINER VIEW AND ADD PLAYER VIEW TO IT
        UIView *movieView = [[UIView alloc] initWithFrame:frame];
        [movieView insertSubview:_mp_movie_player.view atIndex:0];
        
        
        // STEP 3. ADD VIDEO CONTAINER TO CONTENT CONTAINER VIEW
        [_contentContainerView addSubview:movieView];

        
        // STEP 4. ADD MOVIE PLAYER TO VIDEO AD MANAGER
        [_adManager setCustomContentPlayer:_mp_movie_player];

        
    } else if ([_adType isEqualToString:@"preRollSwappingAVPlayer"]) {
        
        
        // AVPLAYER
        // STEP 1. - INSTANTIATE THE PLAYER AND PLAYER LAYER FOR DISPLAY
        _av_movie_player = [[AVPlayer alloc]init];

        
        // STEP 2. - ADD VIDEO PLAYER LAYER TO CONTENT CONTAINER VIEW
        _customPlayerView = [[CustomPlayerView alloc] initWithFrame:frame];
        _customPlayerView.frame = frame;
        AVPlayerLayer *thePlayerlayer = (AVPlayerLayer*)_customPlayerView.layer;
        [thePlayerlayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
        [_customPlayerView setBackgroundColor:[UIColor clearColor]];
        
        
        // STEP 3. ADD VIDEO CONTAINER TO CONTENT CONTAINER VIEW
        [_contentContainerView setBackgroundColor:[UIColor clearColor]];
        [_contentContainerView addSubview:_customPlayerView];
        [_customPlayerView setPlayer:_av_movie_player];
        

        // STEP 4. - ADD MOVIE PLAYER TO VIDEO AD MANAGER
        [_adManager setCustomContentPlaybackView:_customPlayerView];
        [_adManager setCustomContentPlayer:_av_movie_player];
        
        
    } else if ([_adType isEqualToString:@"preRollCustomMPPlayer"]) {
        
        // MPMOVIEPLAYERCONTROLLER
        // STEP 1. - INSTANTIATE THE PLAYER & SET THE FRAME SIZE
        _mp_movie_player = [[MPMoviePlayerController alloc] init];
        _mp_movie_player.view.frame = frame;
        
        
        // STEP 2. - CREATE A VIDEO CONTAINER VIEW AND ADD PLAYER VIEW TO IT
        UIView *movieView = [[UIView alloc] initWithFrame:frame];
        [movieView insertSubview:_mp_movie_player.view atIndex:0];
        
        
        // STEP 3. ADD VIDEO CONTAINER TO CONTENT CONTAINER VIEW
        [_contentContainerView addSubview:movieView];
        
        
        // STEP 4. ADD MOVIE PLAYER TO VIDEO AD MANAGER
        [_adManager setCustomContentPlayer:_mp_movie_player];
        
        
        
        // AD PLAYER (MPMOVIEPLAYERCONTROLLER)
        _mp_ad_player = [[MPMoviePlayerController alloc]init];
        _mp_ad_player.view.frame = frame;
        
        [_adManager setCustomAdPlayer:_mp_ad_player];

        
    } else if ([_adType isEqualToString:@"preRollCustomAVPlayer"]) {
        
        // CONTENT PLAYER (AVPLAYER)
        // STEP 1. - INSTANTIATE THE PLAYER AND PLAYER LAYER FOR DISPLAY
        _av_movie_player = [[AVPlayer alloc]init];
        
        
        // STEP 2. - ADD VIDEO PLAYER LAYER TO CONTENT CONTAINER VIEW
        _customPlayerView = [[CustomPlayerView alloc] initWithFrame:frame];
        _customPlayerView.frame = frame;
        AVPlayerLayer *thePlayerlayer = (AVPlayerLayer*)_customPlayerView.layer;
        [thePlayerlayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
        [_customPlayerView setBackgroundColor:[UIColor clearColor]];
        
        
        // STEP 3. ADD VIDEO CONTAINER TO CONTENT CONTAINER VIEW
        [_contentContainerView setBackgroundColor:[UIColor clearColor]];
        [_contentContainerView addSubview:_customPlayerView];
        [_customPlayerView setPlayer:_av_movie_player];
        
        
        // STEP 4. - ADD MOVIE PLAYER TO VIDEO AD MANAGER
        [_adManager setCustomContentPlaybackView:_customPlayerView];
        [_adManager setCustomContentPlayer:_av_movie_player];
        
        
        // AD PLAYER (AVPLAYER)
        _av_ad_player = [[AVQueuePlayer alloc]init];
        
        [_adManager setCustomAdPlayer:_av_ad_player];
        
        
    } else {

        // PASS CONTAINER AND PLAYER VIEWS (OpenX PLAYER)
        [_playerView setBackgroundColor:[UIColor clearColor]];
        [_adManager setVideoPlayerView:_playerView];
        
    }
    
    // PASS PLAYER CONTAINER TO VIDEO AD MANAGER
    [_contentContainerView setBackgroundColor:[UIColor clearColor]];
    [_adManager setVideoContainer:_contentContainerView];
    
    
    // START THE AD MANAGER
    [_adManager startAdManager];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - DELEGATE METHODS

-(void)videoAdManagerDidLoad:(OXMVideoAdManager *)adManager
{
    
    if ([_adManager isLoaded])
        NSLog(@"\n\n-----------\nVideo Ad Manager loaded successful\n-----------\n\n");
    
}

-(void)videoAdManager:(OXMVideoAdManager *)adManager didFailToReceiveAdWithError:(NSError *)error
{
    NSLog(@"\n\n-----------\nVideo Ad Manager FAILED to load with the following error:\n%@\n-----------\n\n", error);
}


@end
