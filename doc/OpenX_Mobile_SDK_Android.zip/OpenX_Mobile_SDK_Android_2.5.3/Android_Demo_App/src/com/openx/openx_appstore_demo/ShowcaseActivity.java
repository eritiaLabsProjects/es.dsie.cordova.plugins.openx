package com.openx.openx_appstore_demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.RelativeLayout;

public class ShowcaseActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Remove title bar
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.activity_showcase);

		init();

	}

	private void init() {

		setBannerClick(View.VISIBLE);
		setBannerEventsClick(View.VISIBLE);
		setManualBannerEventsClick(View.VISIBLE);
		setMultipleBannerEventsClick(View.VISIBLE);
		setInterstitialClick(View.VISIBLE);
		setPrerollVideoClick(View.VISIBLE);
		setPrerollVideoOpenXClick(View.VISIBLE);
		setPrerollVideoSwapClick(View.VISIBLE);
		setPlaylistVideoClick(View.VISIBLE);
		setNativeVideoClick(View.VISIBLE);
		setInterstitialVideoClick(View.VISIBLE);
		setInterstitialVideoFallbackClick(View.VISIBLE);
		setNativeClick(View.VISIBLE);
	}

	private void setNativeClick(int visibility) {

		((RelativeLayout) findViewById(R.id.native_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.native_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								NativeActivity.class);
						startActivity(intent);

					}

				});

	}

	private void setBannerClick(int visibility) {

		((RelativeLayout) findViewById(R.id.banner_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.banner_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								BannerActivity.class);
						startActivity(intent);

					}

				});

	}

	private void setBannerEventsClick(int visibility) {

		((RelativeLayout) findViewById(R.id.banner_events_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.banner_events_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								BannerWithEventsActivity.class);
						startActivity(intent);

					}

				});

	}

	private void setManualBannerEventsClick(int visibility) {

		((RelativeLayout) findViewById(R.id.manual_banner_events_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.manual_banner_events_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								ManualBannerWithEventsActivity.class);
						startActivity(intent);

					}

				});

	}

	private void setMultipleBannerEventsClick(int visibility) {

		((RelativeLayout) findViewById(R.id.multiple_banner_events_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.multiple_banner_events_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								BannerMultipleWithEventsActivity.class);
						startActivity(intent);

					}

				});

	}

	private void setInterstitialClick(int visibility) {

		((RelativeLayout) findViewById(R.id.interstitial_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.interstitial_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								InterstitialActivity.class);
						startActivity(intent);
					}

				});

	}

	private void setPrerollVideoClick(int visibility) {

		((RelativeLayout) findViewById(R.id.preroll_video_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.preroll_video_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								PrerollVideoCustomPlayerActivity.class);
						startActivity(intent);
					}

				});

	}

	private void setPrerollVideoOpenXClick(int visibility) {

		((RelativeLayout) findViewById(R.id.preroll_video_openx_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.preroll_video_openx_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								PrerollVideoOpenXActivity.class);
						startActivity(intent);

					}
				});

	}

	private void setPlaylistVideoClick(int visibility) {

		((RelativeLayout) findViewById(R.id.playlist_video_openx_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.playlist_video_openx_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								PlaylistVideoOpenXActivity.class);
						startActivity(intent);
					}

				});

	}

	private void setPrerollVideoSwapClick(int visibility) {

		((RelativeLayout) findViewById(R.id.preroll_video_swap_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.preroll_video_swap_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								PrerollVideoSwapActivity.class);
						startActivity(intent);
					}

				});

	}		
	
	private void setNativeVideoClick(int visibility) {

		((RelativeLayout) findViewById(R.id.native_video_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.native_video_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								NativeVideoActivity.class);
						startActivity(intent);
					}

				});

	}	
	

	private void setInterstitialVideoClick(int visibility) {

		((RelativeLayout) findViewById(R.id.interstitial_video_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.interstitial_video_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								InterstitialVideoActivity.class);
						startActivity(intent);
					}

				});

	}

	private void setInterstitialVideoFallbackClick(int visibility) {

		((RelativeLayout) findViewById(R.id.interstitial_video_fallback_item))
				.setVisibility(visibility);

		((RelativeLayout) findViewById(R.id.interstitial_video_fallback_item))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ShowcaseActivity.this,
								InterstitialVideoWithFallbackActivity.class);
						startActivity(intent);
					}

				});

	}

}
