//
//  InfeedFeedCollectionViewCell.m
//  OpenXDemoApp
//
//  Created by Jon Flanders on 5/13/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import "InfeedFeedTableViewCell.h"

@implementation InfeedFeedTableViewCell
-(void)setRowIndex:(NSInteger)rowIndex{
    _rowIndex = rowIndex;
    for (UIImageView* imageView in self.imageViews) {
        UIActivityIndicatorView* busyView = self.activityIndicators[[self.imageViews indexOfObject:imageView]];
        [self downloadImageForImageView:imageView withActivityView:busyView];
        
    }
}
-(void)prepareForReuse{
    for (UIImageView* imageView in self.imageViews) {
        imageView.image  = nil;
    }
    for(UIActivityIndicatorView* busyView in self.activityIndicators){
        busyView.hidden = NO;
        [busyView startAnimating];
    }
}
static NSString* imageURL = @"http://www.freedigitalphotos.net/images/gal_images/av-_%@.jpg";
static NSNumber* defaultIndex;
-(void)downloadImageForImageView:(UIImageView*)imageView withActivityView:(UIActivityIndicatorView*)busyView{

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaultIndex  = @100;
    });
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        NSInteger num =arc4random_uniform(100);
        NSNumber* nnumber = [NSNumber numberWithInteger:num+10];
        NSString* finalURL = [NSString stringWithFormat:imageURL,nnumber];
        NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:finalURL]];
        [NSURLConnection sendAsynchronousRequest:request queue:[[NSOperationQueue alloc] init] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
                UIImage* image = [UIImage imageWithData:data];
                dispatch_async(dispatch_get_main_queue(), ^{
                    imageView.image = image;
                    [busyView stopAnimating];
                });
        }];
    });
}
@end
