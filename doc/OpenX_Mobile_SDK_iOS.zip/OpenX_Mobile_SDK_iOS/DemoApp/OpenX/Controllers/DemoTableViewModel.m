//
//  DemoTableViewModel.m
//  OpenXDemoApp
//
//  Created by Jon Flanders on 5/12/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import "DemoTableViewModel.h"

@implementation DemoTableViewModel
+(DemoTableViewModel*)demoTableViewModelWithSegue:(NSString *)segue andName:(NSString *)name{
    DemoTableViewModel* vm = [[DemoTableViewModel alloc] initWithSegue:segue andName:name];
    return vm;
}
-(instancetype)initWithSegue:(NSString *)segue andName:(NSString *)name{
    self = [super init];
    if(self){
        self.demoName = name;
        self.demoSegueName = segue;
    }
    return self;
}
@end
