//
//  AppDelegate.m
//  OpenX
//
//  Created by Lawrence Leach on 7/9/13.
//  Copyright (c) 2013 OpenX Technologies, Inc. All rights reserved.
//


#import "AppDelegate.h"
#import "OpenXMSDK.h"
#import "RootViewController.h"

// ESTABLISH A SHARED DELEGATE (TO GET THE PLATFORM METHOD)
static AppDelegate *sharedInstance;

@implementation AppDelegate


#pragma mark - SHARED APP DELEGATE

-(id)init
{
    if (sharedInstance)
        NSLog(@"\n\nError: You are trying to create a second app delegate");
    
    sharedInstance = self;
    return self;
}

+(AppDelegate *)sharedAppDelegate
{
    return sharedInstance;
}

-(UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleBlackTranslucent;
}


#pragma mark - APPLICATION METHODS

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [[UINavigationBar appearance] setBarStyle:UIBarStyleBlackOpaque];
    [[UIToolbar appearance] setBarStyle:UIBarStyleBlackOpaque];
    //[[UIApplication sharedApplication] setStatusBarHidden:YES];

    // Check to see if the eval site is reachable
	hostReach = [Reachability reachabilityWithHostname:@"http://www.openx.com"];
	[hostReach startNotifier];
	
    internetReach = [Reachability reachabilityForInternetConnection];
	[internetReach startNotifier];
	
    wifiReach = [Reachability reachabilityForLocalWiFi];
	[wifiReach startNotifier];
	
	// update network reachability...
	[self updateReachabilityStatus];
    
    /*
    // USING STORYBOARDS SO THIS CAN BE DISABLED
    NSString *nib = self.isIphone ? @"RootViewController" : @"RootViewController_iPad";
    RootViewController *rc = [[RootViewController alloc] initWithNibName:nib bundle:nil];
    UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:rc];
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.rootViewController = nc;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    */
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void) applicationWillEnterForeground:(UIApplication *)application {
    /*
    for ( UIViewController* controller in [self.navigationController viewControllers] ) {
        if ( [controller isKindOfClass:[VideoExampleViewController class]] ) {
            // when app enter foreground we will restart playing video stream
            [[(VideoExampleViewController*)controller videoPlayer] play];
        }
    }
    */
    if (backgroundTimer) {
        [backgroundTimer invalidate];
        backgroundTimer = nil;
    }
}

// We set up a background task so that the app stays in the 'background' state, ensuring that we test
// that our controllers stop firing ad requests while backgrounded.
- (void)applicationDidEnterBackground:(id)sender
{
    UIBackgroundTaskIdentifier bgTask = 0;
    UIApplication  *app = [UIApplication sharedApplication];
    bgTask = [app beginBackgroundTaskWithExpirationHandler:^{
        [app endBackgroundTask:bgTask];
    }];
    
    backgroundTimer = [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(doNothing) userInfo:nil repeats:YES];
}

- (void) doNothing {
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

-(BOOL)isIphone
{
#ifdef UI_USER_INTERFACE_IDIOM
    return (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone);
#else
    return NO;
#endif
}

-(NSInteger)panelsToShow
{
    return SHOW_CODE_SAMPLES ? 4 : 3;
    
}

#pragma mark - Alert Message Method

- (void)alertWithMessage:(NSString *)msg withTitle:(NSString *)title {
	
	if ([title length] == 0)
		title = @"Error";
	
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
													message:msg
												   delegate:nil
										  cancelButtonTitle:@"OK"
										  otherButtonTitles: nil];
	[alert show];
}


#pragma mark - Reachability Methods

-(BOOL)haveInternetAccess {
	
	BOOL _isInternetConnectivity = YES;
	
	// check if there is internet connectivity
	[self performSelector:@selector(updateReachabilityStatus)];
	
	hostStatus = [hostReach currentReachabilityStatus];
	wifiStatus = [wifiReach currentReachabilityStatus];
	internetStatus = [internetReach currentReachabilityStatus];
	
	if (hostStatus == NotReachable && internetStatus == NotReachable && wifiStatus == NotReachable) {
		
		// alert the user that there is no internet connectivity
		NSString *errorString = @"There is Currently NO Internet Connectivity.\nYou will be unable to use this app effectively\nuntil connectivity has been restored.";
		[self alertWithMessage:errorString withTitle:@"ERROR"];
		
		_isInternetConnectivity = NO;
	}
	
	return _isInternetConnectivity;
}

- (void)updateReachabilityStatus
{
	hostStatus = [hostReach currentReachabilityStatus];
	wifiStatus = [wifiReach currentReachabilityStatus];
	internetStatus = [internetReach currentReachabilityStatus];
	
	if (hostStatus == NotReachable && internetStatus == NotReachable && wifiStatus == NotReachable) {
		
		// alert the user that there is no internet connectivity
		NSString *errorString = @"There is Currently NO Internet Connectivity.\nYou will be unable to use this app effectively\nuntil connectivity has been restored.";
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
														message:errorString
													   delegate:nil
											  cancelButtonTitle:@"OK"
											  otherButtonTitles: nil];
		[alert show];
	}
}

// Called by Reachability whenever status changes.
- (void)reachabilityChanged:(NSNotification* )note
{
	Reachability* curReach = [note object];
	NSParameterAssert([curReach isKindOfClass: [Reachability class]]);
	
	if(curReach == hostReach)
		hostStatus = [curReach currentReachabilityStatus];
	else if (curReach == wifiReach)
		wifiStatus = [curReach currentReachabilityStatus];
	else if (curReach == internetReach)
		internetStatus = [curReach currentReachabilityStatus];
	
	[self updateReachabilityStatus];
}

@end
