//
//  VideoPrerollViewController.h
//  OpenXDemoApp
//
//  Created by Lawrence Leach on 2/11/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface VideoPrerollViewController : UIViewController

@end
