//
//  OXCustomSegue.h
//  OpenX
//
//  Copyright 2013 OpenX Technologies, Inc.
//

#import <UIKit/UIKit.h>

@interface OXCustomSegue : UIStoryboardSegue

@end
