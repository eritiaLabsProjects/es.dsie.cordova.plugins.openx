//
//  MultiAdViewController.m
//  OpenX
//
//  Copyright (c) 2013 OpenX Technologies, Inc. All rights reserved.
//

#import "MultiAdViewController.h"


@interface MultiAdViewController () <UITextFieldDelegate, OXMConsoleDelegate>
@property (nonatomic, strong) NSString *ad_domain;
@property (nonatomic, strong) NSString *ad_unit1_portrait;
@property (nonatomic, strong) NSString *ad_unit2_portrait;
@property (nonatomic, strong) NSString *ad_unit1_landscape;
@property (nonatomic, strong) NSString *ad_unit2_landscape;
@property (nonatomic, strong) AppDelegate *ad;
@property (nonatomic, strong) IBOutlet OXMAdBanner *topAdBanner;
@property (nonatomic, strong) IBOutlet OXMAdBanner *botAdBanner;
@property (nonatomic, strong) UITextView *notesView;
@property (nonatomic, strong) UITextView *introView;
@property (nonatomic, strong) UITextView *consoleView;
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, strong) IBOutlet UITextField *banner1_portrait_field;
@property (nonatomic, strong) IBOutlet UITextField *banner1_landscape_field;
@property (nonatomic, strong) IBOutlet UITextField *banner2_portrait_field;
@property (nonatomic, strong) IBOutlet UITextField *banner2_landscape_field;
@property (nonatomic, strong) IBOutlet UITextField *url_field;
@property (nonatomic, strong) UITableView *theTableView;
@property (nonatomic, strong) UIView *adView;

@property (nonatomic, strong) IBOutlet UILabel *adUnitLabel1;
@property (nonatomic, strong) IBOutlet UILabel *adUnitLabel2;
@property (nonatomic, strong) IBOutlet UILabel *adUrlLabel;

@property (nonatomic, strong) IBOutlet UILabel *codeSample;
@property (nonatomic, strong) IBOutlet UIView *videoView;
@property (nonatomic, strong) IBOutlet UIView *adDetailsView;
@property (nonatomic, strong) IBOutlet UIView *consoleSlideView;
@property (nonatomic, strong) IBOutlet UIView *codeView;
@property (nonatomic, strong) IBOutlet UISegmentedControl *segControl;
@property (nonatomic, strong) IBOutlet UIButton *updateParametersButton;

@end

@implementation MultiAdViewController



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:NO];
    self.title = @"Multiple Banners";
    
    self.ad = [AppDelegate sharedAppDelegate];
    
    [self setupPageViews];
    [self layoutPageViews];
    
    
    // SETUP THE CONSOLE
    [[OXMConsole instance] clear];
    [[OXMConsole instance] enableLog];
    [[OXMConsole instance] setConsoleDelegate:self];
}


-(void)setupPageViews {
    
    CGFloat kMaxPanelWidth = self.scrollView.bounds.size.width;
    CGFloat kMaxPanelHeight = self.scrollView.bounds.size.height;
    
    // SET LABELS
    [self.adUnitLabel1 setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    [self.adUnitLabel2 setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    [self.adUrlLabel setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    
    
    // SET SEGMENT CONTROL
    [self.segControl addTarget:self action:@selector(segmentTapped:) forControlEvents:UIControlEventValueChanged];
    UIFont *font = [UIFont fontWithName:@"OpenSans-Light" size:12.0f];
    NSDictionary *attributes = [NSDictionary dictionaryWithObject:font forKey:UITextAttributeFont];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateDisabled];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateSelected];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateHighlighted];
    
    self.codeView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 58.0f, kMaxPanelWidth, kMaxPanelHeight)];
    [self.codeView setBackgroundColor:[UIColor blackColor]];
    self.codeView.hidden = YES;
    
    
    // SET CODE, CONSOLE AND SCROLL VIEWS
    self.consoleSlideView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 58.0f, kMaxPanelWidth, kMaxPanelHeight)];
    [self.consoleSlideView setBackgroundColor:[UIColor blackColor]];
    self.consoleSlideView.hidden = YES;
    
    self.codeView = [self setupCodeView:self.codeView];
    self.consoleSlideView = [self setupConsoleView:self.consoleSlideView];
    
    [self.scrollView setScrollEnabled:YES];
    [self.scrollView setDirectionalLockEnabled:YES];
    [self.scrollView setPagingEnabled:NO];
    [self.scrollView addSubview:self.codeView];
    [self.scrollView addSubview:self.consoleSlideView];
    
    
    // SET TEXT FIELD FORMATTING
    [self.banner1_portrait_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0]];
    [self.banner1_portrait_field setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.banner1_portrait_field setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.banner1_portrait_field setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.banner2_portrait_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0f]];
    [self.banner2_portrait_field setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.banner2_portrait_field setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.banner2_portrait_field setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.banner1_landscape_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0]];
    [self.banner1_landscape_field setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.banner1_landscape_field setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.banner1_landscape_field setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.banner2_landscape_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0f]];
    [self.banner2_landscape_field setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.banner2_landscape_field setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.banner2_landscape_field setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.url_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0f]];
    [self.url_field setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.url_field setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.url_field setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self setFieldDefaults];
}

-(void)segmentTapped:(UISegmentedControl*)sender {
    NSInteger segment = sender.selectedSegmentIndex;
    
    switch (segment) {
        case 0:
            self.codeView.hidden = YES;
            self.consoleSlideView.hidden = YES;
            self.updateParametersButton.hidden = NO;
            break;
            
        case 1:
            self.codeView.hidden = YES;
            self.consoleSlideView.hidden = NO;
            self.updateParametersButton.hidden = YES;
            break;
            
        case 2:
            self.codeView.hidden = NO;
            self.consoleSlideView.hidden = YES;
            self.updateParametersButton.hidden = YES;
            break;
            
        default:
            break;
    }
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [self getAdDefaults];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self.topAdBanner stopLoading];
    [self.botAdBanner stopLoading];
    
    // KILL THE CONSOLE
    [[OXMConsole instance] setConsoleDelegate:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - DEAL WITH ORIENTATION CHANGE

- (void) didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    [self layoutPageViews];
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}


#pragma mark - LAYOUT

-(void)layoutPageViews
{
    [self setupAdBannerView];
    [self setFieldDefaults];
}


#pragma mark - SETUP FIELDS AND AD BANNER VIEW

-(void)setFieldDefaults {
    self.banner1_portrait_field.text = self.ad_unit1_portrait;
    self.banner2_portrait_field.text = self.ad_unit2_portrait;
    self.banner1_landscape_field.text = self.ad_unit1_landscape;
    self.banner2_landscape_field.text = self.ad_unit2_landscape;
    self.url_field.text = self.ad_domain;
    
}

-(void)setupAdBannerView
{
    
    [self getAdDefaults];
    
    // MRAID SUPPORTS FUNCTIONALITY
    // UNCOMMENT THE FOLLOWING LINE TO DISABLE ADS FROM ACCESSING SPECIFIC DEVICE FUNCIONALITY FOR MRAID V2.0 COMPLIANT ADS
    // CHOICES ARE: OXMMRAIDSupportsFeatureCalendar|OXMMRAIDSupportsFeatureInlineVideo|OXMMRAIDSupportsFeatureSavePicture|OXMMRAIDSupportsFeatureSMS|OXMMRAIDSupportsFeaturePhone
    // OXMDisableMRAIDSupportsFeatures(OXMMRAIDSupportsFeatureCalendar|OXMMRAIDSupportsFeatureInlineVideo);
    
    // CHECK IF AD BANNER OBJECT IS LOADED.
    // IF SO, STOP IT.
    //
    if ([self.topAdBanner isLoaded] || [self.botAdBanner isLoaded])
        [self.topAdBanner stopLoading], [self.botAdBanner stopLoading];
    
    
    // LOAD A NEW TOP BANNER
    [self.topAdBanner setDomain:self.ad_domain
               portraitAdUnitID:self.ad_unit1_portrait
              landscapeAdUnitID:self.ad_unit1_landscape];
    [self.topAdBanner setAdChangeInterval:DEFAULT_AD_CHANGE_INTERVAL];
    
    // UNCOMMENT THE FOLLOWING LINE TO TURN OFF AUTOREFRESH
    //[self.topAdBanner setAdAutoRefresh:YES];
    
    [self.topAdBanner startLoading];
    
    
    // LOAD A NEW BOTTOM BANNER
    [self.botAdBanner setDomain:self.ad_domain
               portraitAdUnitID:self.ad_unit2_portrait
              landscapeAdUnitID:self.ad_unit2_landscape];
    [self.botAdBanner setAdChangeInterval:DEFAULT_AD_CHANGE_INTERVAL];
    
    // UNCOMMENT THE FOLLOWING LINE TO TURN OFF AUTOREFRESH
    //[self.topAdBanner setAdAutoRefresh:YES];
    
    [self.botAdBanner startLoading];
    
}

-(UIView*)setupCodeView:(UIView*)aView
{
    // TITLE
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 0.0f, 200.0, 40.0)];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:14.0];
    titleLabel.text = @"Code Snippet";
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [aView addSubview:titleLabel];
    
    // SAMPLE CODE
    CGRect frame = CGRectMake(20.0f, 40.0f, 305.0f, 100.0f);
    self.codeSample = [[UILabel alloc] initWithFrame:frame];
    [self.codeSample setBackgroundColor:[UIColor clearColor]];
    self.codeSample.numberOfLines = 6;
    [self.codeSample setFont:[UIFont fontWithName:@"CourierNewPSMT" size:11.0]];
    [self.codeSample setTextColor:[UIColor colorWithRed:0.390 green:0.673 blue:0.262 alpha:1.000]];
    self.codeSample.text = @"[self.adBanner setDomain:@\"AD-DELIVERY-URL\"\n\tportraitAdUnitID:@\"160463\"\n\tlandscapeAdUnitID:@\"160463\"];\n[self.adBanner setAdChangeInterval:30.0f];\n[self.adBanner startLoading];";
    [aView addSubview:self.codeSample];
    
    return aView;
}

-(UIView*)setupConsoleView:(UIView*)aView
{
    // TITLE
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 0.0f, 200.0, 40.0)];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:14.0];
    titleLabel.text = @"Console Output";
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [aView addSubview:titleLabel];
    
    // CONSOLE WINDOW
    //CGRect frame = CGRectMake(8, 58, aView.bounds.size.width-10, 350);
    CGRect frame = CGRectMake(20, 40, aView.bounds.size.width-30, 300);
    self.consoleView = [[UITextView alloc] initWithFrame:frame];
    [self.consoleView setEditable:NO];
    [self.consoleView setFont:[UIFont fontWithName:@"CourierNewPSMT" size:11.0]];
    self.consoleView.text = @"";
    [self.consoleView setBackgroundColor:[UIColor clearColor]];
    [self.consoleView setTextColor:[UIColor whiteColor]];
    [aView addSubview:self.consoleView];
    
    return aView;
}

#pragma mark - SETTINGS

-(void)getAdDefaults {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *domain, *adunit1_portrait, *adunit1_landscape, *adunit2_portrait, *adunit2_landscape;
    domain = [defaults valueForKey:@"multi_ad_server_address"];
    if (self.ad.isIphone) {
        adunit1_portrait = [defaults valueForKey:@"multi_top_portrait"], adunit2_portrait = [defaults valueForKey:@"multi_bottom_portrait"];
        adunit1_landscape = [defaults valueForKey:@"multi_top_landscape"], adunit2_landscape = [defaults valueForKey:@"multi_bottom_landscape"];
    } else {
        adunit1_portrait = [defaults valueForKey:@"multi_top_portrait_tablet"], adunit2_portrait = [defaults valueForKey:@"multi_bottom_portrait_tablet"];
        adunit1_landscape = [defaults valueForKey:@"multi_top_landscape_tablet"], adunit2_landscape = [defaults valueForKey:@"multi_bottom_landscape_tablet"];
    }
    
    
    if ([domain isEqualToString:@""] || [domain isKindOfClass:[NSNull class]] || domain == nil)
        domain = @"oxcs-d.openxenterprise.com";
    
    if ([adunit1_portrait isEqualToString:@""] || [adunit1_portrait isKindOfClass:[NSNull class]] || adunit1_portrait == nil)
        adunit1_portrait = self.ad.isIphone ? @"458439" : @"458439";
    
    if ([adunit1_landscape isEqualToString:@""] || [adunit1_landscape isKindOfClass:[NSNull class]] || adunit1_landscape == nil)
        adunit1_landscape = self.ad.isIphone ? @"458439" : @"458439";
    
    if ([adunit2_portrait isEqualToString:@""] || [adunit2_portrait isKindOfClass:[NSNull class]] || adunit2_portrait == nil)
        adunit2_portrait = self.ad.isIphone ? @"458439" : @"458439";
    
    if ([adunit2_landscape isEqualToString:@""] || [adunit2_landscape isKindOfClass:[NSNull class]] || adunit2_landscape == nil)
        adunit2_landscape = self.ad.isIphone ? @"458439" : @"458439";
    
    
    self.ad_domain = domain;
    self.ad_unit1_portrait = adunit1_portrait;
    self.ad_unit2_portrait = adunit2_portrait;
    self.ad_unit1_landscape = adunit1_landscape;
    self.ad_unit2_landscape = adunit2_landscape;
}

-(IBAction)reloadAdUnit:(id)sender
{
    [self saveSettings:nil];
    [self setupAdBannerView];
}

-(IBAction)saveSettings:(id)sender
{
    // SAVE FIELD VALUES TO NSUSERDEFAULTS
    NSString *banner1_landscape = self.banner1_landscape_field.text;
    NSString *banner1_portrait = self.banner1_portrait_field.text;
    NSString *banner2_landscape = self.banner2_landscape_field.text;
    NSString *banner2_portrait = self.banner2_portrait_field.text;
    NSString *ad_server = self.url_field.text;
    NSString *top_key_portrait = self.ad.isIphone ? @"multi_top_portrait" : @"multi_top_portrait_tablet";
    NSString *top_key_landscape = self.ad.isIphone ? @"multi_top_landscape" : @"multi_top_landscape_tablet";
    NSString *bot_key_portrait = self.ad.isIphone ? @"multi_bottom_portrait" : @"multi_bottom_portrait_tablet";
    NSString *bot_key_landscape = self.ad.isIphone ? @"multi_bottom_landscape" : @"multi_bottom_landscape_tablet";
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:banner1_portrait forKey:top_key_portrait];
    [defaults setObject:banner2_portrait forKey:bot_key_portrait];
    [defaults setObject:banner1_landscape forKey:top_key_landscape];
    [defaults setObject:banner2_landscape forKey:bot_key_landscape];
    [defaults setObject:ad_server forKey:@"multi_ad_server_address"];
    [defaults synchronize];
    
    [self.view endEditing:YES];
    //[self.navigationController popToRootViewControllerAnimated:YES];
}



#pragma mark - KEYBOARD METHODS

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField == self.url_field) {
        
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 250, 0)];
        [self.scrollView scrollRectToVisible:CGRectMake(0, self.scrollView.frame.size.height-10, 320, 10) animated:YES];
        
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
    if (textField == self.url_field) {
        
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 0, 0)];
        [textField resignFirstResponder];
    }
}

-(void)animateTextField:(UITextField*)textField up:(BOOL)up andDistance:(NSInteger)movementDistance
{
    //const int movementDistance = 115;
    const float movementDuration = 0.5f;
    
    NSInteger movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations:@"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration:movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark - OXMConsoleDelegate methods

- (void) latestMessage:(NSString*) message {
    NSLog(@"[OpenX SDK] %@", message);
    self.consoleView.text = [self.consoleView.text stringByAppendingFormat:@"\n%@",message];
}

@end
