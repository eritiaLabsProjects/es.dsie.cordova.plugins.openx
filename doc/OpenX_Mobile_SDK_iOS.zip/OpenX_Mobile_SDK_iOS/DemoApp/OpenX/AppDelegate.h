//
//  AppDelegate.h
//  OpenX
//
//  Created by Lawrence Leach on 7/9/13.
//  Copyright (c) 2013 OpenX Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Reachability.h"



@interface AppDelegate : UIResponder <UIApplicationDelegate> {
    NSTimer* backgroundTimer; // A timer to keep the app doing something in the background.

    Reachability *hostReach;
    Reachability *internetReach;
    Reachability *wifiReach;
    
    NetworkStatus hostStatus;
    NetworkStatus internetStatus;
    NetworkStatus wifiStatus;
}

@property (strong, nonatomic) UIWindow *window;

@property NetworkStatus hostStatus;
@property NetworkStatus internetStatus;
@property NetworkStatus wifiStatus;

+(AppDelegate *)sharedAppDelegate;

-(NSInteger)panelsToShow;
-(BOOL)isIphone;
-(void)alertWithMessage:(NSString *)msg withTitle:(NSString *)title;

// Reachability
-(BOOL)haveInternetAccess;
-(void)updateReachabilityStatus;

@end


