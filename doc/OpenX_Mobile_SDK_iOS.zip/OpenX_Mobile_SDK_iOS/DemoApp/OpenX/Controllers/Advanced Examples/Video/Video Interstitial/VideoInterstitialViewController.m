//
//  VideoInterstitialViewController.m
//  OpenX
//
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import "VideoInterstitialViewController.h"
#import "OXMAdRequest.h"
#import "OXMAdInterstitialController.h"
#import "OXMConsole.h"

@interface VideoInterstitialViewController () <UITextFieldDelegate, OXMConsoleDelegate, OXMAdInterstitialControllerDelegate>
@property (nonatomic, strong) AppDelegate *ad;
@property (nonatomic, strong) OXMAdInterstitialController* adController;
@property (nonatomic, strong) IBOutlet UISwitch *useModalSwitch;
@property (nonatomic, strong) NSString *ad_unit_portrait;
@property (nonatomic, strong) NSString *ad_unit_landscape;
@property (nonatomic, strong) NSString *ad_domain;
@property (nonatomic, strong) NSString *vast_tag;
@property (nonatomic, strong) NSString *skip_offset;
@property (nonatomic, strong) IBOutlet UITextView *notesView;
@property (nonatomic, strong) IBOutlet UITextView *consoleView;
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, strong) IBOutlet UITextField *banner_portrait;
@property (nonatomic, strong) IBOutlet UITextField *banner_landscape;
@property (nonatomic, strong) IBOutlet UITextField *url_field;
@property (nonatomic, strong) IBOutlet UITextField *vast_field;
@property (nonatomic, strong) IBOutlet UITextField *offset_field;

@property (nonatomic, strong) IBOutlet UIButton *interstitialButton;
@property (nonatomic, strong) IBOutlet UIButton *updateParamsButton;
@property (nonatomic, strong) IBOutlet UILabel *adVastLabel;
@property (nonatomic, strong) IBOutlet UILabel *adUnitLabel;
@property (nonatomic, strong) IBOutlet UILabel *adUrlLabel;
@property (nonatomic, strong) IBOutlet UILabel *adOverlayLabel;
@property (nonatomic, strong) IBOutlet UILabel* intNoteLabel;
@property (nonatomic, strong) IBOutlet UILabel* intButtonLabel;
@property (nonatomic, strong) IBOutlet UILabel *codeSample;
@property (nonatomic, strong) IBOutlet UIView *videoView;
@property (nonatomic, strong) IBOutlet UIView *adDetailsView;
@property (nonatomic, strong) IBOutlet UIView *consoleSlideView;
@property (nonatomic, strong) IBOutlet UIView *codeView;
@property (nonatomic, strong) IBOutlet UISegmentedControl *segControl;
@end

@implementation VideoInterstitialViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:NO];
    self.title = @"Video Interstitial Example";
    
    self.ad = [AppDelegate sharedAppDelegate];
    
    // SETUP SCREEN
    [self setupPageViews];
    [self layoutPageViews];
    
    // SETUP THE CONSOLE
    [[OXMConsole instance] clear];
    [[OXMConsole instance] enableLog];
    [[OXMConsole instance] setConsoleDelegate:self];
}


-(void)setupPageViews {
    
    CGFloat kMaxPanelWidth = self.scrollView.bounds.size.width;
    CGFloat kMaxPanelHeight = self.scrollView.bounds.size.height;
    
    
    // SET LABELS
    [self.adUnitLabel setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    [self.adUrlLabel setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    
    
    // SET SEGMENT CONTROL
    [self.segControl addTarget:self action:@selector(segmentTapped:) forControlEvents:UIControlEventValueChanged];
    UIFont *font = [UIFont fontWithName:@"OpenSans-Light" size:12.0f];
    NSDictionary *attributes = [NSDictionary dictionaryWithObject:font forKey:UITextAttributeFont];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateDisabled];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateSelected];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateHighlighted];
    
    self.codeView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 50.0f, kMaxPanelWidth, kMaxPanelHeight)];
    [self.codeView setBackgroundColor:[UIColor blackColor]];
    self.codeView.hidden = YES;
    
    
    // SET CODE, CONSOLE AND SCROLL VIEWS
    self.consoleSlideView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 50.0f, kMaxPanelWidth, kMaxPanelHeight)];
    [self.consoleSlideView setBackgroundColor:[UIColor blackColor]];
    self.consoleSlideView.hidden = YES;
    
    self.codeView = [self setupCodeView:self.codeView];
    self.consoleSlideView = [self setupConsoleView:self.consoleSlideView];
    
    [self.scrollView addSubview:self.codeView];
    [self.scrollView addSubview:self.consoleSlideView];
    
    
    // SET TEXT FIELD FORMATTING
    [self.banner_portrait setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0]];
    [self.banner_portrait setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.banner_portrait setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.banner_portrait setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.banner_landscape setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0]];
    [self.banner_landscape setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.banner_landscape setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.banner_landscape setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.url_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0f]];
    [self.url_field setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.url_field setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.url_field setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.vast_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0f]];
    [self.vast_field setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.vast_field setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.vast_field setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.offset_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0f]];
    [self.offset_field setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.offset_field setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.offset_field setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    
    // SET BUTTONS
    self.interstitialButton.titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:18.0f];
    [self.interstitialButton setTitleColor:[UIColor colorWithRed:0.000 green:0.600 blue:0.788 alpha:1.000] forState:UIControlStateNormal];
    [self.interstitialButton setTitleColor:[UIColor colorWithRed:0.000 green:0.600 blue:0.788 alpha:1.000] forState:UIControlStateHighlighted];
    [self.interstitialButton setTitleColor:[UIColor colorWithRed:0.000 green:0.600 blue:0.788 alpha:1.000] forState:UIControlStateSelected];
    [self.interstitialButton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateDisabled];
    [self.interstitialButton setBackgroundImage:[UIImage imageNamed:@"disabled_button"] forState:UIControlStateDisabled];
    [self.interstitialButton setBackgroundImage:[UIImage imageNamed:@"active_button"] forState:UIControlStateNormal];
    [self.interstitialButton setBackgroundImage:[UIImage imageNamed:@"active_button"] forState:UIControlStateHighlighted];
    [self.interstitialButton setBackgroundImage:[UIImage imageNamed:@"active_button"] forState:UIControlStateSelected];
    [self.interstitialButton addTarget:self action:@selector(showInterstitialAd) forControlEvents:UIControlEventTouchUpInside];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.interstitialButton setEnabled:NO];
    });
    
    
    [self setFieldDefaults];
}

-(void)segmentTapped:(UISegmentedControl*)sender {
    NSInteger segment = sender.selectedSegmentIndex;
    
    switch (segment) {
        case 0:
            self.codeView.hidden = YES;
            self.consoleSlideView.hidden = YES;
            break;
            
        case 1:
            self.codeView.hidden = YES;
            self.consoleSlideView.hidden = NO;
            break;
            
        case 2:
            self.codeView.hidden = NO;
            self.consoleSlideView.hidden = YES;
            break;
            
        default:
            break;
    }
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getAdDefaults];
    [self.navigationController setNavigationBarHidden:NO];
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [[OXMConsole instance] setConsoleDelegate:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - LAYOUT

-(void)layoutPageViews
{
    [self setupAdBannerView];
    [self setFieldDefaults];
}


#pragma mark - SETUP FIELDS AND AD BANNER VIEW

-(void)setFieldDefaults {
    self.banner_portrait.text = self.ad_unit_portrait;
    self.banner_landscape.text = self.ad_unit_landscape;
    self.url_field.text = self.ad_domain;
    self.vast_field.text = self.vast_tag;
    self.offset_field.text = self.skip_offset;
    
}

-(void)setupAdBannerView
{
    // LOAD UP DEFAULT AD VALUES
    [self getAdDefaults];
    
    if (_adController.isLoaded)
        _adController = nil;
    
    // INSTANTIATE A NEW VIDEO AD OBJECT
    _adController = [[OXMAdInterstitialController alloc] initWithVastTag:_vast_tag
                                                              fallbackDomain:_ad_domain
                                                            portraitAdUnitID:_ad_unit_portrait
                                                           landscapeAdUnitID:_ad_unit_landscape];
    if (![_skip_offset length]>0)
        _skip_offset = @"";
    
    
    // SET ANY CUSTOM AD PARAMETERS
    [_adController.request setAutodetectLocation:YES];
    [_adController.request setUserGender:OXMGender_Male];
    [_adController.request setUserAge:32];
    [_adController setSkipOffSet:_skip_offset];
    
    // SET SELF TO BE THE DELEGATE
    [_adController setInterstitialDelegate:self];

    // UNCOMMENT THE FOLLOWING LINE TO HAVE VIDEO GO FULL SCREEN UPON LAUNCH
    //[_adController setLaunchVideoToLandscape:YES];
    
    
    // LOAD THE AD
    [_adController loadAd];
}

-(UIView*)setupCodeView:(UIView*)aView
{
    // TITLE
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 0.0f, 200.0, 40.0)];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:14.0];
    titleLabel.text = @"Code Snippet";
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [aView addSubview:titleLabel];
    
    // SAMPLE CODE
    CGRect frame = CGRectMake(20.0f, 40.0f, 305.0f, 100.0f);
    self.codeSample = [[UILabel alloc] initWithFrame:frame];
    [self.codeSample setBackgroundColor:[UIColor clearColor]];
    self.codeSample.numberOfLines = 6;
    [self.codeSample setFont:[UIFont fontWithName:@"CourierNewPSMT" size:11.0]];
    [self.codeSample setTextColor:[UIColor colorWithRed:0.390 green:0.673 blue:0.262 alpha:1.000]];
    self.codeSample.text = @"[self.adBanner setDomain:@\"AD-DELIVERY-URL\"\n\tportraitAdUnitID:@\"160463\"\n\tlandscapeAdUnitID:@\"160463\"];\n[self.adBanner setAdChangeInterval:30.0f];\n[self.adBanner startLoading];";
    [aView addSubview:self.codeSample];
    
    return aView;
}

-(UIView*)setupConsoleView:(UIView*)aView
{
    // TITLE
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 0.0f, 200.0, 40.0)];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:14.0];
    titleLabel.text = @"Console Output";
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [aView addSubview:titleLabel];
    
    // CONSOLE WINDOW
    CGRect frame = CGRectMake(20, 40, aView.bounds.size.width-30, 300);
    self.consoleView = [[UITextView alloc] initWithFrame:frame];
    [self.consoleView setEditable:NO];
    [self.consoleView setFont:[UIFont fontWithName:@"CourierNewPSMT" size:11.0]];
    self.consoleView.text = @"";
    [self.consoleView setBackgroundColor:[UIColor clearColor]];
    [self.consoleView setTextColor:[UIColor whiteColor]];
    [aView addSubview:self.consoleView];
    
    return aView;
}


#pragma mark - LAYOUT METHODS

-(void)layoutSubviews:(UIView*)aView {
    self.interstitialButton.center = CGPointMake(aView.bounds.size.width/2, aView.bounds.size.height/2);
}


#pragma mark - BUTTON ACTIONS

-(IBAction)showInterstitialAd {
    
    NSLog(@"Showing ad");
    if (!self.adController.isLoaded)
        return; // can't show if not loaded
    
    OXMAdInterstitialController* ic = (OXMAdInterstitialController*)self.adController;
    
    // Show the interstitial
    [ic presentLoadedAd];
}

-(IBAction)reloadAdUnit:(id)sender
{
    [self saveSettings:nil];
    [self setupAdBannerView];
}


#pragma mark - DEAL WITH ORIENTATION CHANGE

- (void) didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    //[self layoutPageViews];
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}


#pragma mark - SETTINGS

-(void)getAdDefaults
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *ad_domain, *aunit_portrait , *aunit_landscape, *v_tag, *offset;
    ad_domain = [defaults valueForKey:@"fallback_server_address"];
    v_tag = [defaults valueForKey:@"interstitial_vast_tag"];
    offset = [defaults valueForKey:@"interstitial_vast_offset"];
    if (self.ad.isIphone) {
        aunit_portrait = [defaults valueForKey:@"fallback_ad_unit_portrait"];
        aunit_landscape = [defaults valueForKey:@"fallback_ad_unit_landscape"];
        if ([aunit_portrait isEqualToString:@""] || [aunit_portrait isKindOfClass:[NSNull class]] || aunit_portrait == nil)
            aunit_portrait = @"458763";
        
        if ([aunit_landscape isEqualToString:@""] || [aunit_landscape isKindOfClass:[NSNull class]] || aunit_landscape == nil)
            aunit_landscape = @"458763";
        
    } else {
        aunit_portrait = [defaults valueForKey:@"fallback_ad_unit_tablet"];
        aunit_landscape = [defaults valueForKey:@"fallback_ad_unit_landscape_tablet"];
        if ([aunit_portrait isEqualToString:@""] || [aunit_portrait isKindOfClass:[NSNull class]] || aunit_portrait == nil)
            aunit_portrait = @"458763";
        
        if ([aunit_landscape isEqualToString:@""] || [aunit_landscape isKindOfClass:[NSNull class]] || aunit_landscape == nil)
            aunit_landscape = @"458763";
    }
    
    if ([ad_domain isEqualToString:@""] || [ad_domain isKindOfClass:[NSNull class]] || ad_domain == nil)
        ad_domain = @"oxcs-d.openxenterprise.com";
    
    if ([v_tag isEqualToString:@""] || [v_tag isKindOfClass:[NSNull class]] || v_tag == nil)
        v_tag = @"http://oxv4support-d3.openxenterprise.com/v/1.0/av?auid=536875736";
    
    if ([offset isEqualToString:@""] || [offset isKindOfClass:[NSNull class]] || offset == nil)
        offset = @"00:00:05";
    
    
    self.vast_tag = v_tag;
    self.skip_offset = offset;
    self.ad_domain = ad_domain;
    self.ad_unit_portrait = aunit_portrait;
    self.ad_unit_landscape = aunit_landscape;
    
}

-(IBAction)saveSettings:(id)sender
{
    // SAVE FIELD VALUES TO NSUSERDEFAULTS
    NSString *vast_tag_url = self.vast_field.text;
    NSString *vast_offset = self.offset_field.text;
    NSString *banner_portrait = self.banner_portrait.text;
    NSString *banner_landscape = self.banner_landscape.text;
    NSString *ad_server = self.url_field.text;
    NSString *key_portrait = @"";
    NSString *key_landscape = @"";
    if (self.ad.isIphone) {
        key_portrait = @"fallback_ad_unit_portrait";
        key_landscape = @"fallback_ad_unit_landscape";
    } else {
        key_portrait = @"fallback_ad_unit_portrait_tablet";
        key_landscape = @"fallback_ad_unit_landscape_tablet";
    }
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:banner_portrait forKey:key_portrait];
    [defaults setObject:banner_portrait forKey:key_portrait];
    [defaults setObject:banner_landscape forKey:key_landscape];
    [defaults setObject:ad_server forKey:@"fallback_server_address"];
    [defaults setObject:vast_tag_url forKey:@"interstitial_vast_tag"];
    [defaults setObject:vast_offset forKey:@"interstitial_vast_offset"];
    [defaults synchronize];
    
    [self.view endEditing:YES];
    //[self.navigationController popToRootViewControllerAnimated:YES];
}


#pragma mark - KEYBOARD METHODS

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField == self.url_field) {
        
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 250, 0)];
        [self.scrollView scrollRectToVisible:CGRectMake(0, self.scrollView.frame.size.height-10, 320, 10) animated:YES];
        
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == self.url_field) {
        
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 0, 0)];
        [textField resignFirstResponder];
    }
}

-(void)animateTextField:(UITextField*)textField up:(BOOL)up andDistance:(NSInteger)movementDistance
{
    //const int movementDistance = 115;
    const float movementDuration = 0.5f;
    
    NSInteger movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations:@"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration:movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}


#pragma mark - UITEXTFIELD DELEGATE METHODS

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark - OXMConsoleDelegate methods

- (void) latestMessage:(NSString*) message {
    self.consoleView.text = [self.consoleView.text stringByAppendingFormat:@"\n%@",message];
    NSLog(@"[OpenX SDK] %@", message);
}


#pragma mark - OXMAdInterstitialControllerDelegate METHODS

- (void) interstitialDidLoad:(OXMAdInterstitialController *)adController {
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.interstitialButton setEnabled:YES];
    });
    
    NSLog(@"\n\n--------\nadControllerDidLoadAd Fired!\n--------\n\n");
}

- (void) interstitialDidBegin:(OXMAdInterstitialController*)adController {
    NSLog(@"\n\n--------\ninterstitialDidBegin Fired!\n--------\n\n");
    /*
     In-App browser presented or MRAID ad expanded, so here we can make correct layout if need
     ( aAdController.isActionInProgress == YES )
     */
}

- (void) interstitial:(OXMAdInterstitialController *)adController didFailToReceiveAdWithError:(NSError*)error {
    /*
     If some errors occurs while loading ads, internet connection failed etc. - SDK will inform here about it.
     */
    
    NSLog(@"Error: %@",error);
}
- (void) interstitialWillLeaveApplication:(OXMAdInterstitialController *)adController{
    
}
- (void) interstitialDidFinish:(OXMAdInterstitialController*)aAdController {
    /*
     User leaves Interstitial ad so we can move to next controller.
     */
    NSLog(@"\n\n--------\ninterstitialDidFinish Fired!\n--------\n\n");
}

@end
