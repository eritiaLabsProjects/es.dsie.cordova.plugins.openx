//
//  NativeInfeedCollectionViewController.m
//  OpenXDemoApp
//
//  Created by Jon Flanders on 5/27/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import "NativeInfeedCollectionViewController.h"
#import "InfeedVideoCollectionViewCell.h"
@interface NativeInfeedCollectionViewController ()

@end

@implementation NativeInfeedCollectionViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden=NO;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 1;
}
static NSString* videoCellID = @"VideoCell";
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    InfeedVideoCollectionViewCell* cell = (InfeedVideoCollectionViewCell*)[collectionView dequeueReusableCellWithReuseIdentifier:videoCellID forIndexPath:indexPath];
    cell.vastTag =  @"http://oxv4support-d3.openxenterprise.com/v/1.0/av?auid=536875736";;
    return cell;
}

@end
