//
//  RootViewController.m
//  OpenX
//
//  Copyright (c) 2013 OpenX Technologies, Inc. All rights reserved.
//

#import "RootViewController.h"
#import "AppDelegate.h"
#import "DemoTableViewModel.h"

@interface RootViewController ()
@property (nonatomic, strong) AppDelegate *ad;
@property (nonatomic, strong) UILabel *introText;
@property (nonatomic, strong) UILabel *footerText;
@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic,strong) NSArray *demoTableData;
@end

@implementation RootViewController
-(void)viewDidLoad
{
    [super viewDidLoad];
     self.demoTableData =@[ [DemoTableViewModel demoTableViewModelWithSegue:@"simpleAd"  andName:@"Simple Ad w/Delegate Methods"],[DemoTableViewModel demoTableViewModelWithSegue:@"simpleLocationDetect" andName:@"Simple Ad w/Location Auto-Detection"],[DemoTableViewModel demoTableViewModelWithSegue:@"groupAd" andName:@"Group Ad Unit"],[DemoTableViewModel demoTableViewModelWithSegue:@"multiAd" andName:@"Multiple Banners In A View"],[DemoTableViewModel demoTableViewModelWithSegue:@"mraid" andName:@"MRAID Example"],[DemoTableViewModel demoTableViewModelWithSegue:@"interstitial" andName:@"Interstitial Example"],[DemoTableViewModel demoTableViewModelWithSegue:@"video" andName:@"Video Examples"],[DemoTableViewModel demoTableViewModelWithSegue:@"nativeAd" andName:@"Native O|X Example"]];
	self.title = @"OpenX iOS Mobile Demo";
    
    self.ad = [AppDelegate sharedAppDelegate];
    
    self.navigationController.navigationBar.translucent = NO;
    
    [self setupTableViewHeaderFooter];
    [self tutorialCheck];
    
}





-(void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - TUTORIAL

-(void)tutorialCheck {
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    self.tutorial_run = [defaults boolForKey:@"tutorial_run"];
    
    if (!self.tutorial_run)
        [self runTutorial];
}

-(void)runTutorial {
    
    // SAVE TUTORIAL FLAG
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setBool:YES forKey:@"tutorial_run"];
    [def synchronize];
    self.tutorial_run = YES;
    
    
    // SHOW TUTORIAL
    [self performSegueWithIdentifier:@"tutorialSegue" sender:nil];
}


#pragma mark -

- (void) setViewBounds {
    if ( UIDeviceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation]) )
        self.view.bounds = self.ad.isIphone ? CGRectMake(0.0f, 0.0f, DEVICE_WIDTH, DEVICE_HEIGHT-44.0f) : CGRectMake(0.0f, 0.0f, DEVICE_WIDTH, DEVICE_HEIGHT-44.0f);
    else
        self.view.bounds = self.ad.isIphone ? CGRectMake(0.0f, 0.0f, DEVICE_HEIGHT, DEVICE_WIDTH-32.0f) : CGRectMake(0.0f, 0.0f, DEVICE_HEIGHT, DEVICE_WIDTH-44.0f);
    
    //self.introText.center = CGPointMake(self.view.bounds.size.width/2, 125);
    self.introText.frame = CGRectMake(15, 40, (self.view.bounds.size.width-20), 100);
    self.footerText.frame = CGRectMake((self.view.bounds.size.width/2)-80, 10, self.view.bounds.size.width, 40);
    self.imgView.frame = CGRectMake((self.view.bounds.size.width/2)-50, 5, 94, 37);
}

- (void) didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    [self setViewBounds];
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}


#pragma mark - SETTINGS

-(IBAction)runSettings {
    [self performSegueWithIdentifier:@"settingsSegue" sender:nil];
}


#pragma mark - TABLEVIEW METHODS

-(void)setupTableViewHeaderFooter {
    
    //[self setViewBounds];
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 120)];
    headerView.backgroundColor = [UIColor colorWithRed:0.933 green:0.956 blue:0.972 alpha:1.000];
    UIImage *logoImg = [UIImage imageNamed:@"black_logo"];
    self.imgView = [[UIImageView alloc] initWithImage:logoImg];
    self.imgView.frame = CGRectMake((self.view.bounds.size.width/2)-50, 5, 94, 37);
    [headerView addSubview:self.imgView];
    
    self.introText = [[UILabel alloc] initWithFrame:CGRectMake(15, 40, (self.view.bounds.size.width-20), 100)];
    self.introText.backgroundColor = [UIColor clearColor];
    self.introText.numberOfLines = 5;
    self.introText.text = @"We've provided the following list of sample ads. You can adjust the parameters on each one as well as test your own ads.";
    self.introText.font = [UIFont fontWithName:@"OpenSans-Light" size:14.0];
    [headerView addSubview:self.introText];
    
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 50)];
    CGRect footerFrame;
    if (self.ad.isIphone)
        footerFrame = CGRectMake((self.view.bounds.size.width/2)-80, 10, self.view.bounds.size.width, 40);
    else
        footerFrame = CGRectMake((self.view.bounds.size.width/2)-100, 10, self.view.bounds.size.width, 40);
    self.footerText = [[UILabel alloc] initWithFrame:footerFrame];
    self.footerText.backgroundColor = [UIColor clearColor];
    self.footerText.text = @"\u00A9 2014 OpenX Technologies, Inc.";
    self.footerText.font = [UIFont systemFontOfSize:11.0];
    [footerView addSubview:self.footerText];
    
    self.theTableView.backgroundColor = [UIColor clearColor];
    self.theTableView.backgroundView = nil;
    self.theTableView.tableHeaderView = headerView;
    self.theTableView.tableFooterView = footerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if (section == 0 || section == 1)
        return 0.0f;
    else
        return 25.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 30.0f;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    UIView *theView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 30.0)];
    [theView setBackgroundColor:[UIColor colorWithRed:0.74 green:0.78 blue:0.80 alpha:1.0]];
    UILabel *textLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, self.view.bounds.size.width, 30.0)];
    
    
    NSString *header = @"     Basic Implementation Example";
    if (section == 1)
        header = @"     Advanced Implementation Examples";
    else if (section == 2)
        header = @"     More Information";
    
    textLabel.backgroundColor = [UIColor clearColor];
    textLabel.textColor = [UIColor whiteColor];
    textLabel.text = header;
    [textLabel setFont:[UIFont fontWithName:@"OpenSans-Bold" size:14.0]];
    
    [theView addSubview:textLabel];
    return theView;
}

/*
 -(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
 
 NSString *header = @"Basic Implementation Example";
 if (section == 1)
 header = @"Advanced Implementation Examples";
 return header;
 }
 */

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger rows = 1;
    
    if (section == 1)
    {
        rows = self.demoTableData.count;
    }
    
    return rows;
}
/*
 - (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
 {
 return 50.0;
 }
 */
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    //cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    UIButton *detailButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [detailButton setImage:[UIImage imageNamed:@"disclosure"] forState:UIControlStateNormal];
    [detailButton setImage:[UIImage imageNamed:@"disclosure"] forState:UIControlStateHighlighted];
    [detailButton setImage:[UIImage imageNamed:@"disclosure"] forState:UIControlStateSelected];
    [detailButton setFrame:CGRectMake(0, 0, 25, 25)];
    cell.accessoryView = detailButton;
    
    [cell.textLabel setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0]];
    
    
    if (indexPath.section == 0)
        cell.textLabel.text = @"Simple Ad Banner";
    
    else if (indexPath.section == 1)  {
        DemoTableViewModel *vm = self.demoTableData[indexPath.row];
        cell.textLabel.text = vm.demoName;
    } else if (indexPath.section == 2)
        cell.textLabel.text = @"About OpenX";
    
    return cell;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSUInteger row = indexPath.row;
    NSUInteger section = indexPath.section;
    
    if (!self.ad.haveInternetAccess)
        [self.ad alertWithMessage:@"Internet access is not currently available.\nPlease try again when connectivity has been restored." withTitle:@"OpenX"];
    
    else {
        if (section == 0) {
            
            [self performSegueWithIdentifier:@"singleAdSegue" sender:nil];
            
        } else if (section == 1) {
            DemoTableViewModel *vm = self.demoTableData[row];
            NSString* segue =   vm.demoSegueName;          [self performSegueWithIdentifier:[NSString stringWithFormat:@"%@Segue",segue] sender:nil];
            
        } else if (section == 2)
            [self performSegueWithIdentifier:@"tutorialSegue" sender:nil]; // SHOW TUTORIAL
        
        
    }
    [self.theTableView deselectRowAtIndexPath:indexPath animated:YES];
}



@end
