//
//  CustomPlayerView.h
//  OpenXDemoApp
//
//  Created by Lawrence Leach on 5/22/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomPlayerView : UIView
@property (nonatomic, retain) AVPlayer* player;

- (void)setPlayer:(AVPlayer*)player;
- (void)setVideoFillMode:(NSString *)fillMode;

@end
