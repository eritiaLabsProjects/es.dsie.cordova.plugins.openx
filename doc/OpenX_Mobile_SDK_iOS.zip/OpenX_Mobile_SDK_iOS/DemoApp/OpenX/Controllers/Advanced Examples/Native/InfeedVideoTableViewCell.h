//
//  InfeedVideoTableViewCell.h
//  OpenXDemoApp
//
//  Created by Jon Flanders on 5/13/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfeedVideoTableViewCell : UITableViewCell
@property (nonatomic,strong) NSString* vastTag;
@property (nonatomic,strong) NSDictionary* adParams;
@end
