/** Automatically generated file. DO NOT MODIFY */
package com.openx.android_sdk_openx;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}