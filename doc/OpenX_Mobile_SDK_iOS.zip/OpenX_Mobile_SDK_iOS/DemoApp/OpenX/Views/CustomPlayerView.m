//
//  CustomPlayerView.m
//  OpenXDemoApp
//
//  Created by Lawrence Leach on 5/22/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import "CustomPlayerView.h"

@implementation CustomPlayerView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

+ (Class)layerClass
{
	return [AVPlayerLayer class];
}

- (AVPlayer*)player
{
    AVPlayer *thePlayer = [(AVPlayerLayer*)[self layer] player];
	
    return thePlayer;
}

- (void)setPlayer:(AVPlayer*)player
{
    if(player!=nil){
        [(AVPlayerLayer*)[self layer] setPlayer:player];
        
    }
}

/* Specifies how the video is displayed within a player layer’s bounds.
 (AVLayerVideoGravityResizeAspect is default) */
- (void)setVideoFillMode:(NSString *)fillMode
{
	AVPlayerLayer *playerLayer = (AVPlayerLayer*)[self layer];
	playerLayer.videoGravity = fillMode;
}


@end
