package com.openx.openx_appstore_demo;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ScrollView;

public class CustomScrollView extends ScrollView{
	
	private int childId;    

    public CustomScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }   

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
//        if (childId > 0) {
//            View scroll = findViewById(childId);
//            if (scroll != null) {
//                Rect rect = new Rect();
//                scroll.getHitRect(rect);
//                if (rect.contains((int) event.getX(), (int) event.getY())) {
//                    return false;
//               }
//            }
//        }
    	
    	if (childId > 0) {          
            ScrollView sv = (ScrollView)findViewById(childId);

            if (sv != null) {           
            	sv.requestDisallowInterceptTouchEvent(true);
            }

        }
    	
        return super.onInterceptTouchEvent(event);
    }

    public void setChildId(int id) {
        this.childId = id;
    }

}
