package com.openx.openx_appstore_demo;

import java.io.InputStream;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.openx.ad.mobile.sdk.entity.AdBrowser;
import com.openx.ad.mobile.sdk.interfaces.NativeAdEventsListener;
import com.openx.errors.AdError;
import com.openx.view.AdNative;
import com.openx.view.NativeAdManager;

public class NativeActivity extends Activity {

	boolean canScroll = true;
	NativeAdManager manager;
	AdNative adNative;
	NativeAdEventsListener listener;
	String EXTRA_URL = "EXTRA_URL";

	TextView title, storeURL, actorName;
	ImageView image, icon;

	String DOMAIN = "oxcs-d.openxenterprise.com";
	String AUID = "562190";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Remove title bar
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.activity_native);

		title = (TextView) findViewById(R.id.title);
		storeURL = (TextView) findViewById(R.id.store_url);
		actorName = (TextView) findViewById(R.id.actor_name);

		image = (ImageView) findViewById(R.id.image);
		icon = (ImageView) findViewById(R.id.icon);

		storeURL.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				String url = storeURL.getText().toString();
				if (url != null && !url.contentEquals("")) {
					Intent intent = new Intent(NativeActivity.this,
							AdBrowser.class);
					intent.putExtra(EXTRA_URL, url);
					startActivity(intent);
				}
			}
		});

		listener = new NativeAdEventsListener() {

			@Override
			public void onNativeAdLoadError(AdError error) {
			}

			@Override
			public void onNativeAdDidLoad(AdNative ad) {

				updateUI(ad);

				ad.logEvent("action", "heart");
			}
		};

		manager = new NativeAdManager(this, DOMAIN, AUID, listener);

		getAd();

	}

	private void updateUI(final AdNative ad) {

		new DownloadImageTask(image).execute(ad.getR_imageURL());

		new DownloadImageTask(icon).execute(ad.getR_actorImage());

		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				title.setText(ad.getR_title());
				storeURL.setText(ad.getR_objectStoreURL());
				actorName.setText(ad.getR_actorName());
			}
		});
	}

	private void getAd() {

		manager.loadAd();

	}

	public void changeParameters(View target) {

		EditText editAUID = (EditText) findViewById(R.id.edit_auid);
		EditText editDomain = (EditText) findViewById(R.id.edit_domain);

		String auid = editAUID.getText().toString();
		String dom = editDomain.getText().toString();

		if (!auid.contentEquals("") && !dom.contentEquals("")) {
			manager = new NativeAdManager(this, dom, auid, listener);
		}

		getAd();

	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
		ImageView bmImage;

		public DownloadImageTask(ImageView bmImage) {
			this.bmImage = bmImage;
		}

		protected Bitmap doInBackground(String... urls) {
			String urldisplay = urls[0];
			Bitmap mIcon11 = null;
			try {
				InputStream in = new java.net.URL(urldisplay).openStream();
				mIcon11 = BitmapFactory.decodeStream(in);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return mIcon11;
		}

		protected void onPostExecute(Bitmap result) {
			bmImage.setImageBitmap(result);
		}
	}
}
