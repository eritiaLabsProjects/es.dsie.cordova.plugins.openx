package com.openx.widgets;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.util.AttributeSet;
import android.widget.MediaController;
import android.widget.VideoView;

import com.openx.model.VideoAdEvent;
import com.openx.model.VideoAdEventListener;
import com.openx.model.vast.VASTInterface;
import com.openx.model.vast.VASTPlayer;
import com.openx.model.vast.VideoCompletionListener;
import com.openx.model.vast.VideoErrorListener;
import com.openx.model.vast.VideoPreparedListener;

public class CustomVideoView extends VideoView implements VASTPlayer, OnPreparedListener, OnCompletionListener, OnErrorListener{
	
	private VASTInterface vastInterface;
	private VideoCompletionListener videoCompletionListener;
	private VideoPreparedListener videoPreparedListener;
	private VideoErrorListener videoErrorListener;
	private VideoAdEventListener videoAdEventListener;
	private Context context;
	private MediaController mc;

	public CustomVideoView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.context = context;
		
		init();
	}

	public CustomVideoView(Context context) {
		super(context);
		
		init();
		
	}
	
	private void init(){
		setOnCompletionListener(this);

		setOnPreparedListener(this);
		setOnErrorListener(this);
		

		mc = new MediaController(context);
		mc.setAnchorView(this);
		
		this.setMediaController(mc);
	}
	
	public MediaController getMediaController(){
		return mc;
	}
	
	@Override
	public void pause() {
		
		super.pause();
		vastInterface.pause();
	}
	
	@Override
	public void setVASTInterface(VASTInterface vastInterface) {
		this.vastInterface = vastInterface;
		
	}

	@Override
	public void setVideoCompletionListener(VideoCompletionListener videoCompletionListener) {
		this.videoCompletionListener = videoCompletionListener;
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		videoCompletionListener.onCompletion(mp);
		
	}

	@Override
	public void setVideoPreparedListener(VideoPreparedListener videoPreparedListener) {
		this.videoPreparedListener = videoPreparedListener;
		
	}

	@Override
	public void setVideoErrorListener(VideoErrorListener videoErrorListener) {
		this.videoErrorListener = videoErrorListener;
		
	}

	@Override
	public boolean onError(MediaPlayer mp, int what, int extra) {
		videoErrorListener.onError(mp, what, extra);
		return false;
	}

	@Override
	public void onPrepared(MediaPlayer mp) {
		videoPreparedListener.onPrepared(mp);
		
		

		
	}
	
}
