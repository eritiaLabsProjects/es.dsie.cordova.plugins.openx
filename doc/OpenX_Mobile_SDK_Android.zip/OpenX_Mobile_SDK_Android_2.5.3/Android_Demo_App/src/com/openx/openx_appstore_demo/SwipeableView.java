package com.openx.openx_appstore_demo;

import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class SwipeableView extends LinearLayout implements OnTouchListener {

	private ViewGroup contentLayout;
	private Context context;
	private ImageView drag;
	private int initialHeight = -1;
	private int lastY = -1;
	private boolean isClosed = false;
	private float threshold = 0.2f;
	private int dragHeight;

	public SwipeableView(Context context) {
		super(context);
		this.context = context;
		init();
	}

	public SwipeableView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.context = context;
		init();
	}

	@SuppressLint("NewApi")
	public SwipeableView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		this.context = context;
		init();
	}

	public void setThreshold(float threshold) {

		if (threshold >= 0 && threshold <= 1)
			this.threshold = threshold;
	}

	public boolean isClosed() {
		return isClosed;
	}

	public void setContent(ViewGroup content) {

		contentLayout = content;

		ScrollView sv = new ScrollView(context);

		LinearLayout.LayoutParams params = new LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);

		sv.setLayoutParams(params);

		sv.addView(contentLayout);

		addView(sv);
	}

	private void init() {

		setOrientation(LinearLayout.VERTICAL);
		drag = new ImageView(context);
		drag.setImageResource(R.drawable.drag);
		drag.setScaleType(ScaleType.CENTER_INSIDE);
		drag.setOnTouchListener(this);
		drag.setPadding(0, 0, 0, 30);
		LinearLayout.LayoutParams dragParams = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.WRAP_CONTENT);

		dragParams.gravity = Gravity.CENTER_HORIZONTAL;
		dragParams.bottomMargin = 20;
		drag.setLayoutParams(dragParams);

		addView(drag);

	}

	public void setDragImageResource(int resId) {

		drag.setImageResource(resId);
	}

	private void close() {

		Timer timer = new Timer();
		TimerTask task = new TimerTask() {

			@Override
			public void run() {

				final ViewGroup.LayoutParams params = getLayoutParams();

				if (getHeight() >= (dragHeight + 10)) {

					params.height -= 10;
				} else {

					params.height = dragHeight;

					int loc[] = new int[2];
					getLocationOnScreen(loc);
					lastY = loc[1];
					cancel();
					isClosed = true;
				}

				applyParams(params);

			}
		};
		timer.scheduleAtFixedRate(task, 0, 5);
	}

	private void open() {
		Timer timer = new Timer();
		TimerTask task = new TimerTask() {

			@Override
			public void run() {

				final ViewGroup.LayoutParams params = getLayoutParams();

				if (getHeight() < (initialHeight - 10)
						&& getHeight() * 1.4 > params.height) {

					params.height += 10;

				} else {
					params.height = initialHeight;
					int loc[] = new int[2];
					getLocationOnScreen(loc);
					lastY = loc[1];

					cancel();
					isClosed = false;

				}
				applyParams(params);

			}
		};

		timer.scheduleAtFixedRate(task, 0, 5);
	}

	private void applyParams(final ViewGroup.LayoutParams params) {
		((Activity) context).runOnUiThread(new Runnable() {

			@Override
			public void run() {

				setLayoutParams(params);
				invalidate();

			}
		});
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {

		if (lastY == -1) {
			dragHeight = drag.getHeight() + 20;
			initialHeight = getHeight();
			int loc[] = new int[2];
			getLocationOnScreen(loc);
			lastY = loc[1];
			ViewGroup.LayoutParams params = getLayoutParams();
			params.height = initialHeight;
			applyParams(params);
		}

		if (event.getAction() == MotionEvent.ACTION_MOVE) {

			ViewGroup.LayoutParams params = getLayoutParams();

			int newY = (int) event.getRawY();
			int diffY = lastY - newY;
			int currentHeight = params.height;

			if ((currentHeight + diffY) >= dragHeight
					&& (currentHeight + diffY) < initialHeight) {

				params.height += diffY;

				lastY = newY;

				applyParams(params);
			}

		} else if (event.getAction() == MotionEvent.ACTION_UP) {

			if (isClosed) {
				if (getHeight() >= (initialHeight * threshold))
					open();
				else
					close();
			} else {

				if (getHeight() <= (initialHeight * (1 - threshold)))
					close();
				else
					open();
			}

		}

		return true;
	}

}
