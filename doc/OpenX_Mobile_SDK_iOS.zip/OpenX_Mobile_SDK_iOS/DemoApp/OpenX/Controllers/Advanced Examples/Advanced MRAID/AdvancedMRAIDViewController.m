//
//  AdvancedMRAIDViewController.m
//  OpenX
//
//  Copyright (c) 2013 OpenX Technologies, Inc. All rights reserved.
//

#import "AdvancedMRAIDViewController.h"
#import "AppDelegate.h"

@interface AdvancedMRAIDViewController () <OXMAdBannerControllerDelegate, OXMConsoleDelegate, UITextFieldDelegate>
@property (nonatomic, strong) AppDelegate *ad;
@property (nonatomic, strong) OXMAdBannerController* adController;
@property (nonatomic, strong) IBOutlet UIView *bodyView;
@property (nonatomic, strong) IBOutlet UITextView *consoleView;
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) NSString *ad_domain;
@property (nonatomic, strong) NSString *ad_unit_portrait;
@property (nonatomic, strong) NSString *ad_unit_landscape;
@property (nonatomic, strong) UIButton *loadButton;
@property (nonatomic, strong) IBOutlet UITextView *notesView;
@property (nonatomic, strong) IBOutlet UITextView *introView;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, strong) IBOutlet UITextField *banner_portrait;
@property (nonatomic, strong) IBOutlet UITextField *banner_landscape;
@property (nonatomic, strong) IBOutlet UITextField *url_field;

@property (nonatomic, strong) IBOutlet UILabel *adUnitLabel;
@property (nonatomic, strong) IBOutlet UILabel *adUrlLabel;

@property (nonatomic, strong) IBOutlet UILabel *codeSample;
@property (nonatomic, strong) IBOutlet UIView *videoView;
@property (nonatomic, strong) IBOutlet UIView *adDetailsView;
@property (nonatomic, strong) IBOutlet UIView *consoleSlideView;
@property (nonatomic, strong) IBOutlet UIView *codeView;
@property (nonatomic, strong) IBOutlet UISegmentedControl *segControl;

@end

@implementation AdvancedMRAIDViewController
@synthesize adController=_adController, consoleView=_consoleView, scrollView=_scrollView;
@synthesize ad_domain=_ad_domain, ad_unit_portrait=_ad_unit_portrait, ad_unit_landscape=_ad_unit_landscape, ad=_ad, bodyView=_bodyView;
@synthesize codeSample=_codeSample, notesView=_notesView, introView=_introView, pageControl=_pageControl, banner_portrait=_banner_portrait, banner_landscape=_banner_landscape, url_field=_url_field;
@synthesize loadButton=_loadButton;
@synthesize adUnitLabel=_adUnitLabel, adUrlLabel=_adUrlLabel, videoView=_videoView, adDetailsView=_adDetailsView;
@synthesize consoleSlideView=_consoleSlideView, codeView=_codeView,segControl=_segControl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"MRAID Ad";
    
    self.ad = [AppDelegate sharedAppDelegate];
    
    // SETUP SCREEN
    [self setupPageViews];
    [self layoutPageViews];
    
    
    // SETUP THE CONSOLE
    [[OXMConsole instance] clear];
    [[OXMConsole instance] enableLog];
    [[OXMConsole instance] setConsoleDelegate:self];
    
}


-(void)setupPageViews {
    
    CGFloat kMaxPanelWidth = self.scrollView.bounds.size.width;
    CGFloat kMaxPanelHeight = self.scrollView.bounds.size.height;
    
    // SET LABELS
    [self.adUnitLabel setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    [self.adUrlLabel setFont:[UIFont fontWithName:@"OpenSans-Bold" size:12.0f]];
    
    
    // SET SEGMENT CONTROL
    [self.segControl addTarget:self action:@selector(segmentTapped:) forControlEvents:UIControlEventValueChanged];
    UIFont *font = [UIFont fontWithName:@"OpenSans-Light" size:12.0f];
    NSDictionary *attributes = [NSDictionary dictionaryWithObject:font forKey:UITextAttributeFont];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateDisabled];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateSelected];
    [self.segControl setTitleTextAttributes:attributes forState:UIControlStateHighlighted];
    
    self.codeView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 58.0f, kMaxPanelWidth, kMaxPanelHeight)];
    [self.codeView setBackgroundColor:[UIColor blackColor]];
    self.codeView.hidden = YES;
    
    
    // SET CODE, CONSOLE AND SCROLL VIEWS
    self.consoleSlideView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 58.0f, kMaxPanelWidth, kMaxPanelHeight)];
    [self.consoleSlideView setBackgroundColor:[UIColor blackColor]];
    self.consoleSlideView.hidden = YES;
    
    self.codeView = [self setupCodeView:self.codeView];
    self.consoleSlideView = [self setupConsoleView:self.consoleSlideView];
    
    [self.scrollView addSubview:self.codeView];
    [self.scrollView addSubview:self.consoleSlideView];
    
    
    // SET TEXT FIELD FORMATTING
    [self.banner_portrait setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0]];
    [self.banner_portrait setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.banner_portrait setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.banner_portrait setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.banner_landscape setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0]];
    [self.banner_landscape setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.banner_landscape setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.banner_landscape setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self.url_field setFont:[UIFont fontWithName:@"OpenSans-Light" size:14.0f]];
    [self.url_field setSpellCheckingType:UITextSpellCheckingTypeNo];
    [self.url_field setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.url_field setAutocorrectionType:UITextAutocorrectionTypeNo];
    
    [self setFieldDefaults];
}

-(void)segmentTapped:(UISegmentedControl*)sender {
    NSInteger segment = sender.selectedSegmentIndex;
    
    switch (segment) {
        case 0:
            self.codeView.hidden = YES;
            self.consoleSlideView.hidden = YES;
            break;
            
        case 1:
            self.codeView.hidden = YES;
            self.consoleSlideView.hidden = NO;
            break;
            
        case 2:
            self.codeView.hidden = NO;
            self.consoleSlideView.hidden = YES;
            break;
            
        default:
            break;
    }
    
}

-(void)viewDidDisappear:(BOOL)animated
{
    NSLog(@"adController has stopped!");
    
    
    [[OXMConsole instance] setConsoleDelegate:nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:NO];
    [self getAdDefaults];
    
    //[self layoutSubviews];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
}


-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    //[self layoutSubviews];
    //[self setupAdBanner];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - LAYOUT

-(void)layoutPageViews
{
    [self setupAdBannerView];
    [self setFieldDefaults];
}


#pragma mark - SETUP FIELDS AND AD BANNER VIEW

-(void)setFieldDefaults {
    self.banner_portrait.text = self.ad_unit_portrait;
    self.banner_landscape.text = self.ad_unit_landscape;
    self.url_field.text = self.ad_domain;
    
}

-(void)setupAdBannerView
{
    
    [self getAdDefaults];
    
    // MRAID SUPPORTS FUNCTIONALITY
    // UNCOMMENT THE FOLLOWING LINE TO DISABLE ADS FROM ACCESSING SPECIFIC DEVICE FUNCIONALITY FOR MRAID V2.0 COMPLIANT ADS
    // CHOICES ARE: OXMMRAIDSupportsFeatureCalendar|OXMMRAIDSupportsFeatureInlineVideo|OXMMRAIDSupportsFeatureSavePicture|OXMMRAIDSupportsFeatureSMS|OXMMRAIDSupportsFeaturePhone
    // OXMDisableMRAIDSupportsFeatures(OXMMRAIDSupportsFeatureCalendar|OXMMRAIDSupportsFeatureInlineVideo);
    
    // CHECK IF AD BANNER OBJECT IS LOADED.
    // IF SO, STOP IT.
    if ([self.adController isLoaded])
        [self.adController stopLoading];
    
    
    // LOAD A NEW TOP BANNER
    self.adController = [[OXMAdBannerController alloc] initWithDomain:self.ad_domain portraitAdUnitID:self.ad_unit_portrait landscapeAdUnitID:self.ad_unit_landscape];
    [self.adController setAdControllerDelegate:self];
    [self.adController setAdChangeInterval:DEFAULT_AD_CHANGE_INTERVAL];
    [self.adController startLoading];
}

-(UIView*)setupCodeView:(UIView*)aView
{
    // TITLE
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 0.0f, 200.0, 40.0)];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:14.0];
    titleLabel.text = @"Code Snippet";
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [aView addSubview:titleLabel];
    
    // SAMPLE CODE
    CGRect frame = CGRectMake(20.0f, 40.0f, 305.0f, 100.0f);
    self.codeSample = [[UILabel alloc] initWithFrame:frame];
    [self.codeSample setBackgroundColor:[UIColor clearColor]];
    self.codeSample.numberOfLines = 6;
    [self.codeSample setFont:[UIFont fontWithName:@"CourierNewPSMT" size:11.0]];
    [self.codeSample setTextColor:[UIColor colorWithRed:0.390 green:0.673 blue:0.262 alpha:1.000]];
    self.codeSample.text = @"[self.adBanner setDomain:@\"AD-DELIVERY-URL\"\n\tportraitAdUnitID:@\"160463\"\n\tlandscapeAdUnitID:@\"160463\"];\n[self.adBanner setAdChangeInterval:30.0f];\n[self.adBanner startLoading];";
    [aView addSubview:self.codeSample];
    
    return aView;
}

-(UIView*)setupConsoleView:(UIView*)aView
{
    // TITLE
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 0.0f, 200.0, 40.0)];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Bold" size:14.0];
    titleLabel.text = @"Console Output";
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [aView addSubview:titleLabel];
    
    // CONSOLE WINDOW
    //CGRect frame = CGRectMake(8, 58, aView.bounds.size.width-10, 350);
    CGRect frame = CGRectMake(20, 40, aView.bounds.size.width-30, 300);
    self.consoleView = [[UITextView alloc] initWithFrame:frame];
    [self.consoleView setEditable:NO];
    [self.consoleView setFont:[UIFont fontWithName:@"CourierNewPSMT" size:11.0]];
    self.consoleView.text = @"";
    [self.consoleView setBackgroundColor:[UIColor clearColor]];
    [self.consoleView setTextColor:[UIColor whiteColor]];
    [aView addSubview:self.consoleView];
    
    return aView;
}


#pragma mark - SETTINGS

-(void)getAdDefaults
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *ad_domain, *aunit_portrait , *aunit_landscape;
    ad_domain = [defaults valueForKey:@"mraid_server_address"];
    if (self.ad.isIphone) {
        aunit_portrait = [defaults valueForKey:@"mraid_ad_unit_portrait"];
        aunit_landscape = [defaults valueForKey:@"mraid_ad_unit_landscape"];
        if ([aunit_portrait isEqualToString:@""] || [aunit_portrait isKindOfClass:[NSNull class]] || aunit_portrait == nil)
            aunit_portrait = @"439256";
        
        if ([aunit_landscape isEqualToString:@""] || [aunit_landscape isKindOfClass:[NSNull class]] || aunit_landscape == nil)
            aunit_landscape = @"439256";
        
    } else {
        aunit_portrait = [defaults valueForKey:@"mraid_ad_unit_portrait_tablet"];
        aunit_landscape = [defaults valueForKey:@"mraid_ad_unit_landscape_tablet"];
        if ([aunit_portrait isEqualToString:@""] || [aunit_portrait isKindOfClass:[NSNull class]] || aunit_portrait == nil)
            aunit_portrait = @"439256";
        
        if ([aunit_landscape isEqualToString:@""] || [aunit_landscape isKindOfClass:[NSNull class]] || aunit_landscape == nil)
            aunit_landscape = @"439256";
    }
    
    if ([ad_domain isEqualToString:@""] || [ad_domain isKindOfClass:[NSNull class]] || ad_domain == nil)
        ad_domain = @"oxcs-d.openxenterprise.com";
    
    
    self.ad_domain = ad_domain;
    self.ad_unit_portrait = aunit_portrait;
    self.ad_unit_landscape = aunit_landscape;
}


-(IBAction)reloadAdUnit:(id)sender
{
    [self saveSettings:nil];
    [self setupAdBannerView];
}

-(IBAction)saveSettings:(id)sender
{
    // SAVE FIELD VALUES TO NSUSERDEFAULTS
    NSString *banner_portrait = self.banner_portrait.text;
    NSString *banner_landscape = self.banner_landscape.text;
    NSString *ad_server = self.url_field.text;
    NSString *key_portrait = @"";
    NSString *key_landscape = @"";
    if (self.ad.isIphone) {
        key_portrait = @"mraid_ad_unit_portrait";
        key_landscape = @"mraid_ad_unit_landscape";
    } else {
        key_portrait = @"mraid_ad_unit_portrait_tablet";
        key_landscape = @"mraid_ad_unit_landscape_tablet";
    }
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:banner_portrait forKey:key_portrait];
    [defaults setObject:banner_landscape forKey:key_landscape];
    [defaults setObject:ad_server forKey:@"mraid_server_address"];
    [defaults synchronize];
    
    [self.view endEditing:YES];
    //[self.navigationController popToRootViewControllerAnimated:YES];
}


#pragma mark - DEAL WITH ORIENTATION CHANGE

- (void) didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    [self layoutPageViews];
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}


#pragma mark - KEYBOARD METHODS

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField == self.url_field) {
        
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 250, 0)];
        [self.scrollView scrollRectToVisible:CGRectMake(0, self.scrollView.frame.size.height-10, 320, 10) animated:YES];
        
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
    if (textField == self.url_field) {
        
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 0, 0)];
        [textField resignFirstResponder];
    }
}

-(void)animateTextField:(UITextField*)textField up:(BOOL)up andDistance:(NSInteger)movementDistance
{
    //const int movementDistance = 115;
    const float movementDuration = 0.5f;
    
    NSInteger movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations:@"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration:movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}


#pragma mark - UITEXTFIELD DELEGATE METHODS

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark - OXMConsoleDelegate methods

- (void) latestMessage:(NSString*) message {
    NSLog(@"[OpenX SDK] %@", message);
    self.consoleView.text = [self.consoleView.text stringByAppendingFormat:@"\n%@",message];
}


#pragma mark - OXMAdBannerControllerDelegate methods

- (void) adControllerWillLoadAd:(OXMAdBannerController*)aAdController {
    /*
     Here we get response from server, so we can see what data do we got,
     and get empty ad banner views which soon be loaded.
     The ad banner view will also start load after device rotation, so here is the best place to make correct layout for them.
     ( aAdController.isLoaded = YES )
     */
    NSLog(@"\nadControllerWillLoadAd Fired");
    
}

- (void) adControllerDidLoadAd:(OXMAdBannerController*)aAdController {
    for (OXMAdBannerView* adBannerView in [aAdController adBannerViews] ) {
        
        // SET THE POSITION ON THE VIEW FOR THE AD
        CGFloat width=adBannerView.bounds.size.width, height=adBannerView.bounds.size.height;
        adBannerView.frame = CGRectMake(0, 0, width, height);
        
        [self.view addSubview:adBannerView];
    }
    
    //[self layoutSubviews];
    
    NSLog(@"\nadControllerDidLoadAd Fired");
}

- (BOOL) adControllerActionShouldBegin:(OXMAdBannerController*)aAdController willLeaveApplication:(BOOL)willLeave {
    /*
     User clicks on ad - SDK sends "click" tracking to OpenX server,
     and then developer decides - does user needs to leave this controller or let SDK works with this action
     and show modal In-App browser if it is not native link (mails, phones etc.) otherwise it will open it in Safari
     also it can be a case with MRAID standard commands (expand, close, open etc.).
     */
    
    NSLog(@"\nadControllerActionShouldBegin Fired");
    return YES;
}

- (void) adControllerActionDidStart:(OXMAdBannerController*)adController {
    /*
     In-App browser presented or MRAID ad expanded, so here we can make correct layout if need
     ( aAdController.isActionInProgress == YES )
     */
    
    NSLog(@"\nadControllerActionDidStart Fired");
}

- (void) adControllerActionDidFinish:(OXMAdBannerController*)aAdController {
    /*
     In-App browser closed or MRAID ad closed, so we can resume playing video.
     ( aAdController.isActionInProgress == NO )
     */
    NSLog(@"\nadControllerActionDidFinish Fired");
}

- (void) adControllerActionUnableToBegin:(OXMAdBannerController*)aAdController {
    /*
     This method is invoked when the user triggered action can not be executed,
     it can be some brocken link or etc.
     ( aAdController.isActionInProgress == NO )
     */
    NSLog(@"\nadControllerActionUnableToBegin Fired");
}

- (void) adController:(OXMAdBannerController*)aAdController didFailToReceiveAdWithError:(NSError*)error {
    /*
     If some errors occurs while loading ads, internet connection failed etc. - SDK will inform here about it.
     */
    
    NSLog(@"Error: %@",error);
}

#pragma mark - OXMAdInterstitialControllerDelegate method

- (void) interstitialDidFinish:(OXMAdInterstitialController*)aAdController {
    /*
     User leaves Interstitial ad so we can move to next controller.
     */
    
    // show next view controller (if not using overlay)
    /*
     if (!self.useModalSwitch.isOn) {
     ExampleNextViewController* nextController = [[ExampleNextViewController alloc] init];
     [self.navigationController pushViewController:nextController animated:YES];
     [nextController release];
     [self layoutSubviews];
     }
     */
    NSLog(@"\ninterstitialDidFinish Fired");
    
}

@end
