package com.openx.openx_appstore_demo;

import java.sql.Timestamp;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.openx.ad.mobile.sdk.entity.OXMEvent;
import com.openx.ad.mobile.sdk.entity.OXMEvent.OXMEventType;
import com.openx.ad.mobile.sdk.interfaces.AdEventsListener;
import com.openx.ad.mobile.sdk.interfaces.OXMEventListener;
import com.openx.ad.mobile.sdk.interfaces.OXMEventsManager;
import com.openx.ad.mobile.sdk.managers.OXMManagersResolver;
import com.openx.errors.AdError;
import com.openx.model.MRAIDAction;
import com.openx.utilities.Utils;
import com.openx.view.AdBanner;

public class BannerMultipleWithEventsActivity extends Activity {

	boolean canScroll = true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Remove title bar
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.activity_new_multiple_banner_events);

		AdBanner adBanner = (AdBanner) findViewById(R.id.adBanner);
		adBanner.setTag("adBanner");

		adBanner.setAdEventsListener(getNewAdEventsListener(adBanner));

		AdBanner adBannerBottom = (AdBanner) findViewById(R.id.adBannerBottom);
		adBannerBottom.setTag("adBannerBottom");

		adBannerBottom
				.setAdEventsListener(getNewAdEventsListener(adBannerBottom));

		renderNonEssentialDisplayData();
	}

	public void tabSelected(View v) {

		clearTabButtons();
		if (v.getId() == R.id.code_btn) {
			((Button) findViewById(R.id.code_btn))
					.setBackgroundResource(R.drawable.code_selector_on);
			findViewById(R.id.content_pane_code).setVisibility(View.VISIBLE);
		} else if (v.getId() == R.id.console_btn) {
			((Button) findViewById(R.id.console_btn))
					.setBackgroundResource(R.drawable.console_selector_on);
			findViewById(R.id.content_pane_console).setVisibility(View.VISIBLE);
		} else if (v.getId() == R.id.params_btn) {
			((Button) findViewById(R.id.params_btn))
					.setBackgroundResource(R.drawable.params_selector_on);
			findViewById(R.id.content_pane_params).setVisibility(View.VISIBLE);
		}
	}

	private void clearTabButtons() {

		((Button) findViewById(R.id.code_btn))
				.setBackgroundResource(R.drawable.code_selector_off);
		((Button) findViewById(R.id.console_btn))
				.setBackgroundResource(R.drawable.console_selector_off);
		((Button) findViewById(R.id.params_btn))
				.setBackgroundResource(R.drawable.params_selector_off);

		hideAllPanes();
	}

	private void hideAllPanes() {
		findViewById(R.id.content_pane_params).setVisibility(View.GONE);
		findViewById(R.id.content_pane_console).setVisibility(View.GONE);
		findViewById(R.id.content_pane_code).setVisibility(View.GONE);
	}

	private void renderSwipeView() {

		SwipeableView swipeView = new SwipeableView(this);

		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
				RelativeLayout.LayoutParams.MATCH_PARENT,
				RelativeLayout.LayoutParams.MATCH_PARENT);
		params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);

		swipeView.setLayoutParams(params);
		swipeView.setBackgroundColor(0xFFEFF4F8);

		LayoutInflater inflater = LayoutInflater.from(this);
		RelativeLayout content = (RelativeLayout) inflater.inflate(
				R.layout.swipey_layout, null);

		LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);

		content.setLayoutParams(contentParams);

		swipeView.setContent(content);

		RelativeLayout parent = (RelativeLayout) findViewById(R.id.content_pane);

		parent.addView(swipeView);
	}

	private void renderNonEssentialDisplayData() {

		renderExample();
		renderEventsExample();
		renderConsole();
		renderSwipeView();
	}

	private AdEventsListener getNewAdEventsListener(final AdBanner adBanner) {
		return new AdEventsListener() {

			@Override
			public void onActionDenied() {

			}

			@Override
			public void onActionDidBegin(MRAIDAction arg0) {
				Toast.makeText(
						BannerMultipleWithEventsActivity.this,
						"MRAID Ad event: onActionDidBegin: "
								+ adBanner.getTag().toString(),
						Toast.LENGTH_LONG).show();
				com.openx.utilities.Utils.log(this, "");

			}

			@Override
			public void onActionDidFinish(MRAIDAction arg0) {
				Toast.makeText(
						BannerMultipleWithEventsActivity.this,
						"MRAID Ad event: onActionDidFinish: "
								+ adBanner.getTag().toString(),
						Toast.LENGTH_LONG).show();

			}

			@Override
			public void onActionWillBegin(MRAIDAction arg0) {
				Toast.makeText(
						BannerMultipleWithEventsActivity.this,
						"MRAID Ad event: onActionWillBegin: "
								+ adBanner.getTag().toString(),
						Toast.LENGTH_LONG).show();

			}

			@Override
			public void onAdClose() {
				Toast.makeText(BannerMultipleWithEventsActivity.this,
						"Ad event: onAdClose: " + adBanner.getTag().toString(),
						Toast.LENGTH_LONG).show();

			}

			@Override
			public void onAdDidLoad() {
				Toast.makeText(
						BannerMultipleWithEventsActivity.this,
						"Ad event: onAdDidLoad: "
								+ adBanner.getTag().toString(),
						Toast.LENGTH_LONG).show();
				Utils.log(this, "Ad event: onAdDidLoad: "
						+ adBanner.getTag().toString());

			}

			@Override
			public void onAdFailedToLoad(AdError arg0) {
				Toast.makeText(
						BannerMultipleWithEventsActivity.this,
						"Ad event: onAdFailedToLoad: "
								+ adBanner.getTag().toString(),
						Toast.LENGTH_LONG).show();

			}

		};
	}

	public void changeParameters(View target) {

		AdBanner adBanner = (AdBanner) findViewById(R.id.adBanner);
		AdBanner adBannerBottom = (AdBanner) findViewById(R.id.adBannerBottom);

		EditText editPortrait = (EditText) findViewById(R.id.edit_portrait);
		EditText editLandscape = (EditText) findViewById(R.id.edit_landscape);
		EditText editDomain = (EditText) findViewById(R.id.edit_domain);

		EditText editPortraitBottom = (EditText) findViewById(R.id.edit_portrait_bottom);
		EditText editLandscapeBottom = (EditText) findViewById(R.id.edit_landscape_bottom);
		EditText editDomainBottom = (EditText) findViewById(R.id.edit_domain_bottom);

		adBanner.setPuid(editPortrait.getText().toString());
		adBanner.setLuid(editLandscape.getText().toString());
		adBanner.setDomain(editDomain.getText().toString());

		adBannerBottom.setPuid(editPortraitBottom.getText().toString());
		adBannerBottom.setLuid(editLandscapeBottom.getText().toString());
		adBannerBottom.setDomain(editDomainBottom.getText().toString());

	}

	public void toggleAutoScroll(View target) {

		canScroll = !canScroll;

		if (canScroll) {
			((Button) target).setText("Auto Scroll On");
			((Button) target)
					.setBackgroundResource(R.drawable.auto_scroll_selector_on);
			ScrollView svConsole = (ScrollView) findViewById(R.id.sv_console);
			svConsole.fullScroll(View.FOCUS_DOWN);

			svConsole.computeScroll();
		} else {
			((Button) target).setText("Auto Scroll Off");
			((Button) target)
					.setBackgroundResource(R.drawable.auto_scroll_selector_off);
		}

	}

	private void renderConsole() {

		final TextView console = (TextView) findViewById(R.id.console);
		console.setMovementMethod(new ScrollingMovementMethod());
		console.setFocusable(false);

		final ScrollView svConsole = (ScrollView) findViewById(R.id.sv_console);
		svConsole.setFocusable(false);

		OXMEventsManager eventsManager = OXMManagersResolver.getInstance()
				.getEventsManager();
		eventsManager.registerEventListener(OXMEventType.LOG,
				new OXMEventListener() {

					@Override
					public void onPerform(OXMEvent event) {
						final String msg = (String) event.getArgs();
						BannerMultipleWithEventsActivity.this
								.runOnUiThread(new Runnable() {

									@Override
									public void run() {

										int time = (int) (System
												.currentTimeMillis());
										Timestamp timeStampObj = new Timestamp(
												time);
										String timeStamp = String
												.valueOf(android.text.format.DateFormat
														.format("h:mm:ss",
																timeStampObj));
										console.append("> [" + timeStamp + "] "
												+ msg + "\n");

										console.post(new Runnable() {

											@Override
											public void run() {

												if (canScroll) {

													svConsole
															.fullScroll(View.FOCUS_DOWN);

													svConsole.computeScroll();

												}

											}

										});

									}
								});
					}
				});
	}

	private void renderExample() {
		TextView example = (TextView) findViewById(R.id.example);

		SpannableString tag = new SpannableString("<com.openx.view.AdBanner");
		tag.setSpan(new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				tag.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString id = new SpannableString("        android:id=");
		id.setSpan(new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				id.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString id_value = new SpannableString("\"@+id/adBannerTop\"");
		id_value.setSpan(new ForegroundColorSpan(Color.parseColor("#6699ff")),
				0, id_value.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString width = new SpannableString(
				"        android:layout_width=");
		width.setSpan(new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				width.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);

		SpannableString width_value = new SpannableString("\"match_parent\"");
		width_value.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				width_value.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString height = new SpannableString(
				"        android:layout_height=");
		height.setSpan(new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				height.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString height_value = new SpannableString("\"wrap_content\"");
		height_value.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0, 14,
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString align = new SpannableString(
				"        android:layout_alignParentTop=");
		align.setSpan(new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				align.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString align_value = new SpannableString("\"true\"");
		align_value.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				align_value.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strCenterHorizontal = new SpannableString(
				"        android:layout_centerHorizontal=");
		strCenterHorizontal.setSpan(
				new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				strCenterHorizontal.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString centerHorizontal_value = new SpannableString("\"true\"");
		centerHorizontal_value.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				centerHorizontal_value.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString domain = new SpannableString("        domain=");
		domain.setSpan(new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				domain.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString domain_value = new SpannableString(
				"\"oxdemo-d.openxenterprise.com\"");
		domain_value.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				domain_value.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString portrait = new SpannableString("        portrait_id=");
		portrait.setSpan(new ForegroundColorSpan(Color.parseColor("#993399")),
				0, portrait.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString portrait_value = new SpannableString("\"137298\"");
		portrait_value.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				portrait_value.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString landscape = new SpannableString("        landscape_id=");
		landscape.setSpan(new ForegroundColorSpan(Color.parseColor("#993399")),
				0, landscape.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString landscape_value = new SpannableString("\"138660\"");
		landscape_value.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				landscape_value.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString interval = new SpannableString(
				"        change_interval=");
		interval.setSpan(new ForegroundColorSpan(Color.parseColor("#993399")),
				0, interval.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString interval_value = new SpannableString("\"30000\"");
		interval_value.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				interval_value.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString close_tag = new SpannableString("    />");
		close_tag.setSpan(new ForegroundColorSpan(Color.parseColor("#009999")),
				0, close_tag.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString id_bottom_value = new SpannableString(
				"\"@+id/adBannerBottom\"");
		id_bottom_value.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				id_bottom_value.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString tagBottom = new SpannableString(
				"<com.openx.view.AdBanner");
		tagBottom.setSpan(new ForegroundColorSpan(Color.parseColor("#009999")),
				0, tagBottom.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString idBottom = new SpannableString("        android:id=");
		idBottom.setSpan(new ForegroundColorSpan(Color.parseColor("#993399")),
				0, idBottom.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString id_value_bottom = new SpannableString(
				"\"@+id/adBannerBottom\"");
		id_value_bottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				id_value_bottom.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString widthBottom = new SpannableString(
				"        android:layout_width=");
		widthBottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				widthBottom.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);

		SpannableString width_value_bottom = new SpannableString(
				"\"match_parent\"");
		width_value_bottom
				.setSpan(new ForegroundColorSpan(Color.parseColor("#6699ff")),
						0, width_value_bottom.length(),
						Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString heightBottom = new SpannableString(
				"        android:layout_height=");
		heightBottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				heightBottom.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString height_value_bottom = new SpannableString(
				"\"wrap_content\"");
		height_value_bottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				height_value_bottom.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString alignBottom = new SpannableString(
				"        android:layout_alignParentBottom=");
		alignBottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				alignBottom.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString align_value_bottom = new SpannableString("\"true\"");
		align_value_bottom
				.setSpan(new ForegroundColorSpan(Color.parseColor("#6699ff")),
						0, align_value_bottom.length(),
						Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strCenterHorizontalBottom = new SpannableString(
				"        android:layout_centerHorizontal=");
		strCenterHorizontalBottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				strCenterHorizontalBottom.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString centerHorizontal_value_bottom = new SpannableString(
				"\"true\"");
		centerHorizontal_value_bottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				centerHorizontal_value_bottom.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString domainBottom = new SpannableString("        domain=");
		domainBottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				domainBottom.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString domain_value_bottom = new SpannableString(
				"\"oxdemo-d.openxenterprise.com\"");
		domain_value_bottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				domain_value_bottom.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString portraitBottom = new SpannableString(
				"        portrait_id=");
		portraitBottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				portraitBottom.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString portrait_value_bottom = new SpannableString(
				"\"137298\"");
		portrait_value_bottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				portrait_value_bottom.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString landscapeBottom = new SpannableString(
				"        landscape_id=");
		landscapeBottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				landscapeBottom.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString landscape_value_bottom = new SpannableString(
				"\"138660\"");
		landscape_value_bottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				landscape_value_bottom.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString intervalBottom = new SpannableString(
				"        change_interval=");
		intervalBottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#993399")), 0,
				intervalBottom.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString interval_value_bottom = new SpannableString("\"30000\"");
		interval_value_bottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#6699ff")), 0,
				interval_value_bottom.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString close_tag_bottom = new SpannableString("    />");
		close_tag_bottom.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				close_tag_bottom.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableStringBuilder ssb = new SpannableStringBuilder();

		ssb.append(tag).append("\r\n").append(id).append(id_value)
				.append("\r\n").append(width).append(width_value)
				.append("\r\n").append(height).append(height_value)
				.append("\r\n").append(align).append(align_value)
				.append("\r\n").append(strCenterHorizontal)
				.append(centerHorizontal_value).append("\r\n").append(domain)
				.append(domain_value).append("\r\n").append(portrait)
				.append(portrait_value).append("\r\n").append(landscape)
				.append(landscape_value).append("\r\n").append(interval)
				.append(interval_value).append(close_tag).append("\r\n")
				.append("\r\n").append(tagBottom).append("\r\n").append(id)
				.append(id_value_bottom).append("\r\n").append(widthBottom)
				.append(width_value_bottom).append("\r\n").append(heightBottom)
				.append(height_value_bottom).append("\r\n").append(alignBottom)
				.append(align_value_bottom).append("\r\n")
				.append(strCenterHorizontalBottom)
				.append(centerHorizontal_value_bottom).append("\r\n")
				.append(domainBottom).append(domain_value_bottom)
				.append("\r\n").append(portraitBottom)
				.append(portrait_value_bottom).append("\r\n")
				.append(landscapeBottom).append(landscape_value_bottom)
				.append("\r\n").append(intervalBottom)
				.append(interval_value_bottom).append(close_tag_bottom)
				.append("\r\n");

		example.setText(ssb);
	}

	private void renderEventsExample() {
		TextView events = (TextView) findViewById(R.id.events);
		events.setTextColor(Color.WHITE);

		SpannableString comment = new SpannableString(
				"// in onCreate, get references to your multiple banners, and assign listeners via a utility method passing in the banner reference...");
		comment.setSpan(new ForegroundColorSpan(Color.parseColor("#009999")),
				0, comment.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strAdBanner = new SpannableString(
				"AdBanner adBanner = (AdBanner) findViewById(R.id.adBanner);");

		SpannableString strAdEventsListener = new SpannableString(
				"adBanner.setAdEventsListener(getNewAdEventsListener(adBanner));");

		SpannableString strAdBannerBottom = new SpannableString(
				"AdBanner adBannerBottom = (AdBanner) findViewById(R.id.adBannerBottom);");

		SpannableString strAdEventsListenerBottom = new SpannableString(
				"adBannerBottom.setAdEventsListener(getNewAdEventsListener(adBannerBottom));");

		SpannableString strEllipsis = new SpannableString(". . .");

		SpannableString nextComment = new SpannableString(
				"// in global body of Activity, create a utility method that will generate an AdEventListener for the passed in banner reference...");
		nextComment.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				nextComment.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strGetAdEventsListener = new SpannableString(
				"private AdEventsListener getNewAdEventsListener(final AdBanner adBanner){");

		SpannableString strAdEventsListenerConstruction = new SpannableString(
				"return new AdEventsListener(){");

		SpannableString strOverride = new SpannableString("@Override");

		SpannableString strActionDidBegin = new SpannableString(
				"public void onActionDidBegin(MRAIDAction arg0) {");

		SpannableString strToast = new SpannableString(
				"Toast.makeText(BannerWithEventsActivity.this, \"MRAID Ad event: onActionDidBegin\", Toast.LENGTH_LONG).show();");

		SpannableString strBrace = new SpannableString("}");

		SpannableString strAnd = new SpannableString(
				"// also implement the following:");
		strAnd.setSpan(new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strAnd.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOnActionWillBegin = new SpannableString(
				"// ... onActionWillBegin(MRAIDAction arg0) ...");
		strOnActionWillBegin.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strOnActionWillBegin.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOnActionDidFinish = new SpannableString(
				"// ... onActionDidFinish(MRAIDAction arg0) ...");
		strOnActionDidFinish.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strOnActionDidFinish.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOnAdClose = new SpannableString(
				"// ... onAdClose() ...");
		strOnAdClose.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strOnAdClose.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOnAdDidLoad = new SpannableString(
				"// ... onAdDidLoad() ...");
		strOnAdDidLoad.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strOnAdDidLoad.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOnAdFailedToLoad = new SpannableString(
				"// ... onAdFailedToLoad(AdError arg0) ...");
		strOnAdFailedToLoad.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strOnAdFailedToLoad.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableStringBuilder ssb = new SpannableStringBuilder();

		ssb.append("        ").append(comment).append("\r\n").append("\r\n")
				.append("        ").append(strAdBanner).append("\r\n")
				.append("        ").append("        ")
				.append(strAdEventsListener).append("\r\n").append("\r\n")
				.append("        ").append(strAdBannerBottom).append("\r\n")
				.append("        ").append("        ")
				.append(strAdEventsListenerBottom).append("\r\n")
				.append("        ").append(strEllipsis).append("\r\n")
				.append("\r\n").append("        ").append(nextComment)
				.append("\r\n").append("\r\n").append(strGetAdEventsListener)
				.append("\r\n").append("        ")
				.append(strAdEventsListenerConstruction).append("\r\n")
				.append("\r\n").append("        ").append("        ")
				.append(strOverride).append("\r\n").append("        ")
				.append("        ").append(strActionDidBegin).append("\r\n")
				.append("        ").append("        ").append("        ")
				.append(strToast).append("\r\n").append("        ")
				.append("        ").append(strBrace).append("\r\n")
				.append("\r\n").append("        ").append("        ")
				.append(strAnd).append("\r\n").append("        ")
				.append("        ").append(strOnActionWillBegin).append("\r\n")
				.append("        ").append("        ")
				.append(strOnActionDidFinish).append("\r\n").append("        ")
				.append("        ").append(strOnAdClose).append("\r\n")
				.append("        ").append("        ").append(strOnAdDidLoad)
				.append("\r\n").append("        ").append("        ")
				.append(strOnAdFailedToLoad).append("\r\n").append("        ")
				.append(strBrace).append(";").append("\r\n").append(strBrace);

		events.setText(ssb);
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

}
