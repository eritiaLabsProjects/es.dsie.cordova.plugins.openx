package com.openx.openx_appstore_demo;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.widget.RelativeLayout;

import com.openx.model.AdCallParams;
import com.openx.model.AdCallParams.OXMGender;
import com.openx.model.Offset;
import com.openx.model.VideoAdManager;
import com.openx.model.VideoAdManager.ContentCompletionListener;
import com.openx.widgets.CustomVideoView;

public class PrerollVideoSwapActivity extends Activity {
	
	private VideoAdManager videoAdManager;
	private CustomVideoView customVideoView;	
	private RelativeLayout contentVideoContainer; 

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_video_preroll_swap);

		createPrerollAd();

	}

	private void createPrerollAd(){
		
		//Required: get a reference to the RelativeLayout container for the video in which your custom content video player already sits.  Note, that this could be a complex View that inherits from RelativeLayout and implements the VAST Player Interface.
	    contentVideoContainer = (RelativeLayout) findViewById(R.id.videoContainer);
	 
	    //Required: get a reference to the custom VideoView instance that is available from your custom video player
	    //This object must extend from the VideoView class.  See the instructions on how to implement your custom video player
	    customVideoView = (CustomVideoView) findViewById(R.id.customvideoview);
	 
	    //Required: instantiate the VideoAdManager
	    videoAdManager = new VideoAdManager(this);
	 
	    //Required: set the ContentVideoContainer by passing in the reference
	    videoAdManager.setContentVideoContainer(contentVideoContainer);
	 
	    //Required: set the Custom Video View
	    videoAdManager.setContentVideoView(customVideoView);
	 
	    //Required: set the Url of the main video content that will be played. 
	    //Note, you can alternatively set a video playlist of multiple content videos by using the setVideoContentPlaylist(..) method.
	    videoAdManager.setVideoContentUrl("http://i.cdn.openx.com/videos/mobile/OpenX_NYC_Tim3_2_Audio.mp4");
	     
	    //Optionally set the Skip Offset time for the video ad.  This will force a user to watch an ad for a set duration of time.
	    //Not setting this will allow the user to fast forward through the ad.  Setting the value to -1 dissallows skipping.
	    videoAdManager.setSkipOffset("00:00:05.000");
	     
	    //Required: set the Url of the assigned VAST tag from the OpenX Ad Server
	    videoAdManager.setVASTTag("http://oxv4support-d3.openxenterprise.com/v/1.0/av?auid=537074373");   
	     
	    //Optionally set the boolean for allowing or disallowing fullscreen (default is true)
	    videoAdManager.setAllowFullscreen(false);
	 
	    //Required: set the pre-roll ad break (start of the content video)
	    //videoAdManager.addTimeOffset(Offset.start());
	 
	    //Below are examples of other ad break types for mid-rolls and post-rolls to the content video.
	    //See the OpenX SDK documentation for the full JavaDoc description of these Time Offsets in the Offset class.
	     
	    //videoAdManager.addTimeOffset(Offset.time("00:02:20.000"));
	    videoAdManager.addTimeOffset(Offset.percentage(5));
	    //videoAdManager.addTimeOffset(Offset.firstQuartile());
	    //videoAdManager.addTimeOffset(Offset.midpoint());
	    //videoAdManager.addTimeOffset(Offset.thirdQuartile());
	    videoAdManager.addTimeOffset(Offset.end());
	 
	    //optionally set a callback for the notification for the completion of the content video
	    videoAdManager.setContentCompletionListener(new ContentCompletionListener(){
	 
	        @Override
	        public void onContentCompletion(String url, boolean isEndOfPlaylist) {

	            //videoAdManager.addTimeOffset(Offset.percentage(5));
	 
	        }   
	    });
	    
	    //Optionally set custom target parameters, see developer integration documentation for more detail:
	    //http://docs.openx.com/sdk/#android_sdk_advanced_banner_integration.html
	    AdCallParams params = new AdCallParams();
	    params.setUserGender(OXMGender.MALE); 
	    params.setUserAge(30);
	    params.setUserAnnualIncomeInUs(60000);     
	    videoAdManager.setAdCallParams(params);
	 
	    //Required: finally, start the video sequence  
	    videoAdManager.start();
 		
	}

}
