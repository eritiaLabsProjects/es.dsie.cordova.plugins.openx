//
//  VideoInterstitialViewController.h
//  OpenXDemoApp
//
//  Created by Lawrence Leach on 1/13/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface VideoInterstitialViewController : UIViewController

@end
