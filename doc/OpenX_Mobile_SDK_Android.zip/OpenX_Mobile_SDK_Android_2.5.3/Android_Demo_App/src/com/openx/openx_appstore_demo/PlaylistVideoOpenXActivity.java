package com.openx.openx_appstore_demo;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.RelativeLayout;

import com.openx.model.AdCallParams;
import com.openx.model.AdCallParams.OXMGender;
import com.openx.model.Offset;
import com.openx.model.VideoAdEvent;
import com.openx.model.VideoAdEventListener;
import com.openx.model.VideoAdManager;
import com.openx.model.VideoAdManager.ContentCompletionListener;

public class PlaylistVideoOpenXActivity extends Activity implements VideoAdEventListener{


	private String VAST_TAG = "http://oxv4support-d3.openxenterprise.com/v/1.0/av?auid=537074373";

	RelativeLayout videoContainer; 

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		// Remove title bar
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_video_preroll_openx);

		createPrerollAd();

	}

	private String videoUrl = "http://i.cdn.openx.com/videos/mobile/OpenX_NYC_Tim3_2_Audio.mp4";
	private String videoUrl1 = "http://i.cdn.openx.com/videos/mobile/Tim_Miami_Edit_1.mp4";
	private String videoUrl2 = "http://i.cdn.openx.com/videos/mobile/Sell_Side_Discussion_Tim3.mp4";
	 
	ArrayList<String> contentPlaylist;
	
	private void createPrerollAd(){
		
		videoContainer = (RelativeLayout) findViewById(R.id.videoContainer);

		contentPlaylist = new ArrayList<String>();
		contentPlaylist.add(videoUrl);	
		contentPlaylist.add(videoUrl1);
		contentPlaylist.add(videoUrl2);
	
		final VideoAdManager videoAdManager = new VideoAdManager(this);

		videoAdManager.setVideoContainer(videoContainer);

		videoAdManager.setVideoContentPlaylist(contentPlaylist);

		videoAdManager.setSkipOffset("00:00:05.000");
		
		videoAdManager.setVASTTag(VAST_TAG);

		videoAdManager.addTimeOffset(Offset.start());

		videoAdManager.setContentCompletionListener(new ContentCompletionListener(){

			@Override
			public void onContentCompletion(String url, boolean isEndOfPlaylist) {
				
				//A callback implementation at the completion of a content video
				//videoAdManager.addTimeOffset(Offset.percentage(5));
			}

			
		});
		
	    //Optionally set custom target parameters, see developer integration documentation for more detail:
	    //http://docs.openx.com/sdk/#android_sdk_advanced_banner_integration.html
	    AdCallParams params = new AdCallParams();
	    params.setUserGender(OXMGender.MALE); 
	    params.setUserAge(30);
	    params.setUserAnnualIncomeInUs(60000);     
	    videoAdManager.setAdCallParams(params);
	    
	    //Optional to receive ad related event callbacks for any video, or content related callbacks for content video
	    videoAdManager.addVideoAdEventListener(this);

	    
		videoAdManager.start();
 		
	}
	
	@Override
	public void onVideoAdEvent(VideoAdEvent.Event event) {
		
		Log.i("VIDEO_AD_EVENT", "Event: " + event);
		
		switch(event){

				case AD_IMPRESSION :
					break;					
				case AD_CREATIVEVIEW :
					break;
				case AD_START :
					break;
				case AD_FIRSTQUARTILE :
					break;
				case AD_MIDPOINT :
					break;
				case AD_THIRDQUARTILE :
					break;
				case AD_COMPLETE :
					break;
				case AD_MUTE :
					break;
				case AD_UNMUTE :
					break;
				case AD_PAUSE :
					break;
				case AD_REWIND :
					break;
				case AD_RESUME :
					break;
				case AD_FULLSCREEN :
					break;
				case AD_EXITFULLSCREEN :
					break;
				case AD_EXPAND :
					break;
				case AD_COLLAPSE :
					break;
				case AD_ACCEPTINVITATION :
					break;
				case AD_ACCEPTINVITATIONLINEAR :
					break;
				case AD_CLOSELINEAR :
					break;
				case AD_CLOSE :
					break;
				case AD_SKIP :
					break;
				case AD_PROGRESS :
					break;
		
		}
		
	}
		
}
