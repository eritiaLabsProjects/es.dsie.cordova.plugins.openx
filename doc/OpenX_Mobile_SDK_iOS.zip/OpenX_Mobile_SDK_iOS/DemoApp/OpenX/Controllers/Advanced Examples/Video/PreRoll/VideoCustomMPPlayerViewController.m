//
//  VideoCustomMPPlayerViewController.m
//  OpenXDemoApp
//
//  Created by Lawrence Leach on 5/19/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import "AppDelegate.h"
#import "VideoCustomMPPlayerViewController.h"

@interface VideoCustomMPPlayerViewController () <OXMVideoAdManagerDelegate>
@property (nonatomic, strong) AppDelegate *ad;
@property (nonatomic, weak) OXMVideoAdManager *adManager;
@property (nonatomic, weak) IBOutlet OXMMediaPlaybackView *playerView; // For content playback using the OpenX player
@property (nonatomic, weak) IBOutlet UIView *contentContainerView;     // UIView for holding video content

@property (nonatomic, weak) UIView *customAdView;                      // UIView for holding a custom ad player
@property (nonatomic, weak) UIView *customPlayerView;

@property (nonatomic, strong) NSString *vast_tag;
@property (nonatomic, strong) NSString *video_one;
@property (nonatomic, strong) NSString *video_two;
@property (nonatomic, strong) NSString *video_three;
@property (nonatomic, strong) NSString *video_four;
@property (nonatomic, strong) NSString *video_five;
@property (nonatomic, strong) NSString *video_six;
@end

@implementation VideoCustomMPPlayerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)videoAdManagerDidLoad:(OXMVideoAdManager *)adManager
{
    
}

- (void)videoAdManager:(OXMVideoAdManager *)adManager didFailToReceiveAdWithError:(NSError *)error
{
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
