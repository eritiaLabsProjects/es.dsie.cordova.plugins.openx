OpenX iOS SDK release notes are located at the following URL:
 http://docs.openx.com/sdk/#rn_ios_sdk_main.html
OpenX iOS SDK documentation is located at the following URL:
 http://docs.openx.com/sdk/#ios_sdk.html

View the SDK appledocs by opening 'appledocs/index.html' relative to this file.