package com.openx.openx_appstore_demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;

import com.openx.widgets.GalleryImageAdapter;

public class LandingActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_landing);

		ViewPager pager = (ViewPager) findViewById(R.id.pager);
		GalleryImageAdapter adapter = new GalleryImageAdapter(this, 0);
		pager.setAdapter(adapter);

	}

	public void getStarted(View v) {

		startActivity(new Intent(LandingActivity.this, ShowcaseActivity.class));
		finish();
	}

}
