package com.openx.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.openx.openx_appstore_demo.R;

public class ScreenPercentImageView extends ImageView {

	private float mWidthPercent = 100;
	private double mDrawableScalePercent;

	public ScreenPercentImageView(Context context) {
		super(context);
	}

	public ScreenPercentImageView(Context context, AttributeSet attrs,
			int defStyle) {
		super(context, attrs, defStyle);
		setup(context, attrs);
	}

	public ScreenPercentImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setup(context, attrs);
	}

	private void setup(Context context, AttributeSet attrs) {
		TypedArray a = context.getTheme().obtainStyledAttributes(attrs,
				R.styleable.ScreenPercentImageView, 0, 0);
		try {
			mWidthPercent = a.getFloat(
					R.styleable.ScreenPercentImageView_widthPercentIV, 50);
		} finally {
			a.recycle();
		}
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

		int parentWidth = getResources().getDisplayMetrics().widthPixels;
		int parentHeight = getResources().getDisplayMetrics().heightPixels;

		int width;

		if (parentHeight > parentWidth)
			width = (int) (parentWidth * mWidthPercent / 100);
		else
			width = (int) (parentHeight * mWidthPercent / 100);

		mDrawableScalePercent = (double) width / parentWidth;
		int height = getDrawable().getIntrinsicHeight() * width
				/ getDrawable().getIntrinsicWidth();
		setMeasuredDimension(width, height);

	}

	public double getDrawableScalePercent() {
		return mDrawableScalePercent;
	}

}
