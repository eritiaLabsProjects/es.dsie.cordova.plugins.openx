//
//  DemoTableViewModel.h
//  OpenXDemoApp
//
//  Created by Jon Flanders on 5/12/14.
//  Copyright (c) 2014 OpenX Technologies, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DemoTableViewModel : NSObject
+(DemoTableViewModel*) demoTableViewModelWithSegue:(NSString*)segue andName:(NSString*)name;
-(instancetype)initWithSegue:(NSString*)segue andName:(NSString*)name;
@property (nonatomic,strong) NSString   *demoSegueName;
@property (nonatomic,strong)NSString *demoName;
@end
