package com.openx.openx_appstore_demo;

import java.sql.Timestamp;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.openx.ad.mobile.sdk.entity.OXMEvent;
import com.openx.ad.mobile.sdk.entity.OXMEvent.OXMEventType;
import com.openx.ad.mobile.sdk.interfaces.AdEventsListener;
import com.openx.ad.mobile.sdk.interfaces.OXMEventListener;
import com.openx.ad.mobile.sdk.interfaces.OXMEventsManager;
import com.openx.ad.mobile.sdk.managers.OXMManagersResolver;
import com.openx.errors.AdError;
import com.openx.model.MRAIDAction;
import com.openx.utilities.Constants;
import com.openx.view.AdInterstitial;

public class InterstitialVideoActivity extends Activity {

	private String DOMAIN_INTERSTITIAL = "oxcs-d.openxenterprise.com";
	
	private String VAST_TAG = "http://oxv4support-d3.openxenterprise.com/v/1.0/av?auid=537074373";

	private String SKIP_OFFSET = "00:00:05.000";	

	Button btnShowInterstitial;

	AdInterstitial adInterstitial;

	boolean canScroll = true;

	AdEventsListener adEventsListener = new AdEventsListener() {

		@Override
		public void onAdFailedToLoad(AdError e) {

		}

		@Override
		public void onAdDidLoad() {

			Log.e("ED InterstitialVideoActivity:onAdDidLoad", "Ad did load");
			btnShowInterstitial.setEnabled(true);

			btnShowInterstitial.setText("Show Video Interstitial");
			btnShowInterstitial.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					adInterstitial.show();
				}
			});

		}

		@Override
		public void onActionWillBegin(MRAIDAction action) {
		}

		@Override
		public void onActionDidFinish(MRAIDAction action) {
		}

		@Override
		public void onActionDidBegin(MRAIDAction action) {
		}

		@Override
		public void onAdClose() {
			btnShowInterstitial.setEnabled(false);

			/*
			 * For the purposes of the demo, we reload another Interstitial ad
			 * and present a button when it's available;
			 */
			createInterstitialAD();
		}

		@Override
		public void onActionDenied() {

			Log.e("ED InterstitialActivity :onActionDenied", "Action Denied!!");
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		// Remove title bar
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_video_interstitial);

		btnShowInterstitial = (Button) findViewById(R.id.show_interstitial);

		createInterstitialAD();

		renderNonEssentialDisplayData();

	}

	public void tabSelected(View v) {

		clearTabButtons();
		if (v.getId() == R.id.code_btn) {
			((Button) findViewById(R.id.code_btn))
					.setBackgroundResource(R.drawable.code_selector_on);
			findViewById(R.id.content_pane_code).setVisibility(View.VISIBLE);
		} else if (v.getId() == R.id.console_btn) {
			((Button) findViewById(R.id.console_btn))
					.setBackgroundResource(R.drawable.console_selector_on);
			findViewById(R.id.content_pane_console).setVisibility(View.VISIBLE);
		} else if (v.getId() == R.id.params_btn) {
			((Button) findViewById(R.id.params_btn))
					.setBackgroundResource(R.drawable.params_selector_on);
			findViewById(R.id.content_pane_params).setVisibility(View.VISIBLE);
		}
	}

	private void clearTabButtons() {

		((Button) findViewById(R.id.code_btn))
				.setBackgroundResource(R.drawable.code_selector_off);
		((Button) findViewById(R.id.console_btn))
				.setBackgroundResource(R.drawable.console_selector_off);
		((Button) findViewById(R.id.params_btn))
				.setBackgroundResource(R.drawable.params_selector_off);

		hideAllPanes();
	}

	private void hideAllPanes() {
		findViewById(R.id.content_pane_params).setVisibility(View.GONE);
		findViewById(R.id.content_pane_console).setVisibility(View.GONE);
		findViewById(R.id.content_pane_code).setVisibility(View.GONE);
	}

	private void renderSwipeView() {

		SwipeableView swipeView = new SwipeableView(this);

		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
				RelativeLayout.LayoutParams.MATCH_PARENT,
				RelativeLayout.LayoutParams.MATCH_PARENT);
		params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);

		swipeView.setLayoutParams(params);
		swipeView.setBackgroundColor(0xFFEFF4F8);

		LayoutInflater inflater = LayoutInflater.from(this);
		RelativeLayout content = (RelativeLayout) inflater.inflate(
				R.layout.swipey_layout, null);

		LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT);

		content.setLayoutParams(contentParams);

		swipeView.setContent(content);

		RelativeLayout parent = (RelativeLayout) findViewById(R.id.content_pane);

		parent.addView(swipeView);
	}

	private void renderNonEssentialDisplayData() {

		renderEventsExample();
		renderConsole();
		renderSwipeView();

	}

	private void createInterstitialAD() {

		int millis = (int) (System.currentTimeMillis() / 1000);

		String vastTag = "http://a.collective-media.net/pfadx/cm.test/mob_broad;test=broad;sz=1x2;ord="
				+ millis + ";dcmt=text/xml;cmu=com.openx.android_demo_app";

		// videoAdManager.setVASTTag(VAST_TAG);
		// videoAdManager.setVASTTag(vastTag);
		// adInterstitial = new AdInterstitial(this, vastTag);
		adInterstitial = new AdInterstitial(this, VAST_TAG);

		adInterstitial.setPreloadAdVideos(true);

		adInterstitial.setPlayFullscreen(false);

		adInterstitial.setSkipOffset(SKIP_OFFSET);

		adInterstitial.setAdEventsListener(adEventsListener);

		adInterstitial.startLoading();

		// For demo purpose only, not for use in standard implementation
		if (adInterstitial.getIsPreloadedVideo()) {
			btnShowInterstitial.setText("Preloading Video...");
		}

	}

	public void changeParameters(View target) {

		EditText editVASTTag = (EditText) findViewById(R.id.edit_vast_tag);
		EditText editSkipOffset = (EditText) findViewById(R.id.edit_skip_offset);

		String vastTag = editVASTTag.getText().toString();
		String skipOffset = editSkipOffset.getText().toString();

		if (!vastTag.contentEquals("")) {

			VAST_TAG = vastTag;
			SKIP_OFFSET = skipOffset;

			btnShowInterstitial.setEnabled(false);
			createInterstitialAD();
		}

	}

	public void toggleAutoScroll(View target) {

		canScroll = !canScroll;

		if (canScroll) {
			((Button) target).setText("Auto Scroll On");
			((Button) target)
					.setBackgroundResource(R.drawable.auto_scroll_selector_on);
			ScrollView svConsole = (ScrollView) findViewById(R.id.sv_console);
			svConsole.fullScroll(View.FOCUS_DOWN);

			svConsole.computeScroll();
		} else {
			((Button) target).setText("Auto Scroll Off");
			((Button) target)
					.setBackgroundResource(R.drawable.auto_scroll_selector_off);
		}

	}

	private void renderConsole() {

		final TextView console = (TextView) findViewById(R.id.console);
		console.setMovementMethod(new ScrollingMovementMethod());
		console.setFocusable(false);

		final ScrollView svConsole = (ScrollView) findViewById(R.id.sv_console);
		svConsole.setFocusable(false);

		OXMEventsManager eventsManager = OXMManagersResolver.getInstance()
				.getEventsManager();
		eventsManager.registerEventListener(OXMEventType.LOG,
				new OXMEventListener() {

					@Override
					public void onPerform(OXMEvent event) {
						final String msg = (String) event.getArgs();
						Log.i(Constants.OXM_TAG, msg);
						InterstitialVideoActivity.this
								.runOnUiThread(new Runnable() {

									@Override
									public void run() {

										int time = (int) (System
												.currentTimeMillis());
										Timestamp timeStampObj = new Timestamp(
												time);
										String timeStamp = String
												.valueOf(android.text.format.DateFormat
														.format("h:mm:ss",
																timeStampObj));
										console.append("> [" + timeStamp + "] "
												+ msg + "\n");

										console.post(new Runnable() {

											@Override
											public void run() {

												if (canScroll) {

													svConsole
															.fullScroll(View.FOCUS_DOWN);

													svConsole.computeScroll();

												}

											}

										});

									}
								});
					}
				});
	}

	private void renderEventsExample() {
		TextView events = (TextView) findViewById(R.id.events);
		events.setTextColor(Color.WHITE);

		SpannableString comment = new SpannableString(
				"// in onCreate or other user-based event, call the utility method...");
		comment.setSpan(new ForegroundColorSpan(Color.parseColor("#009999")),
				0, comment.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strCreateInterstitialAdCreate = new SpannableString(
				"createInterstitialAd();");
		strCreateInterstitialAdCreate.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strCreateInterstitialAdCreate.length(),
				Spannable.SPAN_INCLUSIVE_INCLUSIVE);

		SpannableString strEllipsis = new SpannableString(". . .");

		SpannableString commentCreateInterstitialAd = new SpannableString(
				"// in global body of Activity, define a utility method that will create the interstitial...");
		commentCreateInterstitialAd.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				commentCreateInterstitialAd.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strCreateInterstitialAD = new SpannableString(
				"private void createInterstitialAd() {");
		strCreateInterstitialAD.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strCreateInterstitialAD.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strNewAdInterstitial = new SpannableString(
				"adInterstitial = new AdInterstitial(this, VAST_TAG);");
		strNewAdInterstitial.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strNewAdInterstitial.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strSetPreloadAdVideos = new SpannableString(
				"adInterstitial.setPreloadAdVideos(true);");
		strSetPreloadAdVideos.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strSetPreloadAdVideos.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strSetPlayFullscreen = new SpannableString(
				"adInterstitial.setPlayFullscreen(false);");
		strSetPlayFullscreen.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strSetPlayFullscreen.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strSetSkipOffset = new SpannableString(
				"adInterstitial.setSkipOffset(\"00:00:05.000\");");
		strSetSkipOffset.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strSetSkipOffset.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		// SpannableString strSetClosePosition = new SpannableString(
		// "adInterstitial.setClosePosition(AdInterstitial.ClosePosition.AD_TOP_LEFT);");
		// strSetClosePosition.setSpan(
		// new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
		// strSetClosePosition.length(),
		// Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strSetAdEventsListener = new SpannableString(
				"adInterstitial.setAdEventsListener(adEventsListener);");
		strSetAdEventsListener.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strSetAdEventsListener.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		// SpannableString strSetDimAmount = new SpannableString(
		// "adInterstitial.setDimAmount(1.0f);");
		// strSetDimAmount.setSpan(
		// new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
		// strSetDimAmount.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strStartLoading = new SpannableString(
				"adInterstitial.startLoading();");
		strStartLoading.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strStartLoading.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString nextComment = new SpannableString(
				"// in global body of Activity...create the AdEventListener");
		nextComment.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				nextComment.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strAdEventsListenerConstruction = new SpannableString(
				"AdEventsListener adEventsListener = new AdEventsListener(){");
		strAdEventsListenerConstruction.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strAdEventsListenerConstruction.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOverride = new SpannableString("@Override");
		strOverride.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strOverride.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strAdDidLoad = new SpannableString(
				"public void onAdDidLoad() {");
		strAdDidLoad.setSpan(
				new ForegroundColorSpan(Color.parseColor("#ffffff")), 0,
				strAdDidLoad.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strCommentAdDidLoad = new SpannableString(
				"// here, the ad is ready for display, either programmatically or by user-event, i.e., a button as shown in this example above... ");
		strCommentAdDidLoad.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strCommentAdDidLoad.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strToast = new SpannableString(
				"Toast.makeText(BannerWithEventsActivity.this, \"Ad Did Load \", Toast.LENGTH_LONG).show();");
		strToast.setSpan(new ForegroundColorSpan(Color.parseColor("#ffffff")),
				0, strToast.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strShow = new SpannableString(
				"btnShowInterstitial.setVisibility(View.VISIBLE);");
		strShow.setSpan(new ForegroundColorSpan(Color.parseColor("#ffffff")),
				0, strShow.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strBrace = new SpannableString("}");
		strBrace.setSpan(new ForegroundColorSpan(Color.parseColor("#ffffff")),
				0, strBrace.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);

		SpannableString strAnd = new SpannableString(
				"// you may also implement the following:");
		strAnd.setSpan(new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strAnd.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOnActionWillBegin = new SpannableString(
				"// ... onActionWillBegin(MRAIDAction arg0) ...");
		strOnActionWillBegin.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strOnActionWillBegin.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOnActionDidFinish = new SpannableString(
				"// ... onActionDidFinish(MRAIDAction arg0) ...");
		strOnActionDidFinish.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strOnActionDidFinish.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOnAdClose = new SpannableString(
				"// ... onAdClose() ...");
		strOnAdClose.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strOnAdClose.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOnActionDidBegin = new SpannableString(
				"// ... onActionDidBegin() ...");
		strOnActionDidBegin.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strOnActionDidBegin.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableString strOnAdFailedToLoad = new SpannableString(
				"// ... onAdFailedToLoad(AdError arg0) ...");
		strOnAdFailedToLoad.setSpan(
				new ForegroundColorSpan(Color.parseColor("#009999")), 0,
				strOnAdFailedToLoad.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		SpannableStringBuilder ssb = new SpannableStringBuilder();

		ssb.append("\r\n")
				.append("        ")
				.append(commentCreateInterstitialAd)
				.append("\r\n")
				.append("\r\n")
				.append("        ")
				.append(strCreateInterstitialAD)
				.append("\r\n")
				.append("        ")
				.append("        ")
				.append(strNewAdInterstitial)
				.append("\r\n")
				.append("        ")
				.append("        ")
				.append("        ")
				// .append(strSetClosePosition).append("\r\n").append("        ")
				// .append("        ").append("        ")
				.append(strSetPreloadAdVideos).append("\r\n")
				.append("        ").append("        ").append("        ")
				.append(strSetPlayFullscreen).append("\r\n").append("        ")
				.append("        ").append("        ").append(strSetSkipOffset)
				.append("\r\n").append("        ").append("        ")
				.append("        ").append(strSetAdEventsListener)
				.append("\r\n").append("        ").append(strStartLoading)
				.append("\r\n").append("        ").append(strBrace)
				.append("\r\n").append("\r\n").append("        ")
				.append(comment).append("\r\n").append("\r\n")
				.append("        ").append(strCreateInterstitialAdCreate)
				.append("\r\n").append("        ").append(strEllipsis)
				.append("\r\n").append("\r\n").append("        ")
				.append(nextComment).append("\r\n").append("\r\n")
				.append(strAdEventsListenerConstruction).append("\r\n")
				.append("\r\n").append("        ").append(strOverride)
				.append("\r\n").append("        ").append(strAdDidLoad)
				.append("\r\n").append("\r\n").append("        ")
				.append("        ").append(strCommentAdDidLoad).append("\r\n")
				.append("\r\n").append("        ").append("        ")
				.append(strToast).append("\r\n").append("        ")
				.append("        ").append(strShow).append("\r\n")
				.append("        ").append(strBrace).append("\r\n")
				.append("\r\n").append("        ").append(strAnd)
				.append("\r\n").append("\r\n").append("        ")
				.append(strOnActionWillBegin).append("\r\n").append("        ")
				.append(strOnActionDidFinish).append("\r\n").append("        ")
				.append(strOnAdClose).append("\r\n").append("        ")
				.append(strOnActionDidBegin).append("\r\n").append("        ")
				.append(strOnAdFailedToLoad).append("\r\n").append(strBrace);

		events.setText(ssb);
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

}
